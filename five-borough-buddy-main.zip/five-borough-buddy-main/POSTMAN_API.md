# Admin Panel API Documentation

## Admin Registration API

### Create Admin User

**Endpoint:** `POST https://jiegopvbwpyfohhfvmwo.supabase.co/auth/v1/admin/users`

**Headers:**
```
Content-Type: application/json
Authorization: Bearer YOUR_SERVICE_ROLE_KEY
apikey: YOUR_SERVICE_ROLE_KEY
```

**Body:**
```json
{
  "email": "admin@example.com",
  "password": "securePassword123!",
  "email_confirm": true,
  "user_metadata": {
    "role": "admin"
  }
}
```

**Response:**
```json
{
  "id": "uuid",
  "email": "admin@example.com",
  "created_at": "2024-01-01T00:00:00Z",
  "email_confirmed_at": "2024-01-01T00:00:00Z",
  "user_metadata": {
    "role": "admin"
  }
}
```

### Create Admin Profile

**Endpoint:** `POST https://jiegopvbwpyfohhfvmwo.supabase.co/rest/v1/profiles`

**Headers:**
```
Content-Type: application/json
Authorization: Bearer YOUR_SERVICE_ROLE_KEY
apikey: YOUR_SERVICE_ROLE_KEY
```

**Body:**
```json
{
  "id": "USER_ID_FROM_PREVIOUS_RESPONSE",
  "role": "admin",
  "status": "approved",
  "approved_at": "2024-01-01T00:00:00Z"
}
```

## Postman Collection

### Environment Variables
Create a new environment in Postman with these variables:
- `supabase_url`: `https://jiegopvbwpyfohhfvmwo.supabase.co`
- `service_role_key`: `YOUR_SERVICE_ROLE_KEY` (get this from Supabase dashboard)

### Collection Structure

1. **Create Admin User**
   - Method: POST
   - URL: `{{supabase_url}}/auth/v1/admin/users`
   - Headers:
     - `Content-Type`: `application/json`
     - `Authorization`: `Bearer {{service_role_key}}`
     - `apikey`: `{{service_role_key}}`
   - Body: JSON with admin user data

2. **Create Admin Profile**
   - Method: POST
   - URL: `{{supabase_url}}/rest/v1/profiles`
   - Headers:
     - `Content-Type`: `application/json`
     - `Authorization`: `Bearer {{service_role_key}}`
     - `apikey`: `{{service_role_key}}`
   - Body: JSON with profile data

3. **Test Admin Login**
   - Method: POST
   - URL: `{{supabase_url}}/auth/v1/token?grant_type=password`
   - Headers:
     - `Content-Type`: `application/json`
     - `apikey`: `YOUR_ANON_KEY`
   - Body: JSON with email and password

## Security Notes

1. **Service Role Key**: This key has full access to your database. Keep it secure and never expose it in client-side code.

2. **Admin Creation**: Only use the service role key for admin user creation. Regular users should register through the normal signup flow.

3. **Profile Creation**: After creating the admin user, you must create a corresponding profile record with `role: "admin"` and `status: "approved"`.

## Testing the Admin Panel

1. Use the Postman collection to create an admin user
2. Start the admin panel: `npm run dev`
3. Navigate to `http://localhost:5173`
4. Login with the admin credentials you created
5. You should be redirected to the dashboard

## Troubleshooting

- **401 Unauthorized**: Check that you're using the correct service role key
- **Admin access denied**: Ensure the profile record has `role: "admin"` and `status: "approved"`
- **Database connection issues**: Verify the Supabase URL and keys are correct

