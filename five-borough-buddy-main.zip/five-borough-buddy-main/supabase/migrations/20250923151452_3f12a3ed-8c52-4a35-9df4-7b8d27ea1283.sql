-- Create characteristics table for predefined characteristics
CREATE TABLE IF NOT EXISTS public.characteristics (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  category TEXT DEFAULT 'general',
  is_active BOOLEAN NOT NULL DEFAULT true,
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.characteristics ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Characteristics are viewable by everyone" 
ON public.characteristics 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage characteristics" 
ON public.characteristics 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.profiles 
  WHERE id = auth.uid() AND role = 'admin'
));

-- Insert existing characteristics from models table
INSERT INTO public.characteristics (name, category, order_index) VALUES
('Bisexual', 'orientation', 1),
('Blonde', 'appearance', 2),
('Brazilian', 'nationality', 3),
('Brunette', 'appearance', 4),
('Couples', 'service', 5),
('Dinner Date', 'service', 6),
('Domination / Fetish', 'service', 7),
('European', 'nationality', 8),
('Exclusive', 'service', 9),
('GFE (Girlfriend Experience)', 'service', 10),
('High-Class', 'level', 11),
('International', 'nationality', 12),
('Latina', 'nationality', 13),
('Natural', 'appearance', 14),
('Open-Minded', 'personality', 15),
('Outcalls', 'service', 16),
('Party', 'service', 17),
('Petite', 'appearance', 18),
('Russian', 'nationality', 19),
('Slim', 'appearance', 20),
('Tall', 'appearance', 21),
('VIP / Elite', 'level', 22),
('Young', 'appearance', 23)
ON CONFLICT (name) DO NOTHING;

-- Create trigger to update updated_at
CREATE OR REPLACE FUNCTION update_characteristics_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER update_characteristics_updated_at_trigger
  BEFORE UPDATE ON public.characteristics
  FOR EACH ROW
  EXECUTE FUNCTION update_characteristics_updated_at();