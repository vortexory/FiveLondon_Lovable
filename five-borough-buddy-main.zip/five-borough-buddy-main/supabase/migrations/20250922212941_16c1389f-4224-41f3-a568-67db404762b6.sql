-- Fix the admin deletion issue by updating the policy to be more explicit
DROP POLICY IF EXISTS "Admin users can delete models" ON public.models;
DROP POLICY IF EXISTS "Admin users can manage models" ON public.models;

-- Create separate, more explicit policies
CREATE POLICY "Admin users can delete models"
ON public.models
FOR DELETE
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role = 'admin'
  )
);

CREATE POLICY "Admin users can insert models"
ON public.models
FOR INSERT
WITH CHECK (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role = 'admin'
  )
);

CREATE POLICY "Admin users can update models"
ON public.models
FOR UPDATE
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role = 'admin'
  )
)
WITH CHECK (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role = 'admin'
  )
);