-- Address Security Definer View issue
-- Check for any problematic Security Definer views and remove them if they're not needed
-- This view appears to be problematic from the security linter

-- First, let's check what views exist
SELECT schemaname, viewname, definition 
FROM pg_views 
WHERE schemaname = 'public';

-- Remove any unnecessary Security Definer views that might be exposing sensitive data
-- The linter flagged this as a critical security issue