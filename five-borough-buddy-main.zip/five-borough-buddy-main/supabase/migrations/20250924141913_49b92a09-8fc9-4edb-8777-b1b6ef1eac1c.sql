-- Update the is_admin function to recognize super_admin role as well
CREATE OR REPLACE FUNCTION public.is_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT CASE 
    WHEN auth.uid() IS NULL THEN false
    ELSE EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
    )
  END;
$function$;

-- Also update the storage policies to be more explicit
DO $$
BEGIN
    -- Drop and recreate the blog-images policies with better error handling
    DROP POLICY IF EXISTS "Admin users can upload blog images" ON storage.objects;
    
    CREATE POLICY "Admin users can upload blog images" 
    ON storage.objects 
    FOR INSERT 
    WITH CHECK (
        bucket_id = 'blog-images' 
        AND auth.uid() IS NOT NULL 
        AND (
            SELECT role FROM public.profiles 
            WHERE id = auth.uid() 
            AND role IN ('admin', 'super_admin')
        ) IS NOT NULL
    );
END $$;