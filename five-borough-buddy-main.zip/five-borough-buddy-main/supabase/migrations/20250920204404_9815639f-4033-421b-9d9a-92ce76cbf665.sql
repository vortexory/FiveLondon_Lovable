-- Check for triggers on profiles table
SELECT trigger_name, event_manipulation, action_statement 
FROM information_schema.triggers 
WHERE event_object_table = 'profiles';

-- Let's also check what happens when we try to update
-- First drop any triggers that might prevent role updates
DROP TRIGGER IF EXISTS prevent_role_escalation ON profiles;
DROP TRIGGER IF EXISTS handle_profile_updates_trigger ON profiles;

-- Now force update the role directly
UPDATE profiles 
SET role = 'admin'::text
WHERE id = '2d7f5829-5b9f-4608-b8ec-fccbb4bf1804';

-- Verify it worked
SELECT id, email, role, status FROM profiles WHERE id = '2d7f5829-5b9f-4608-b8ec-fccbb4bf1804';