-- Create edge function for updating user roles
CREATE OR REPLACE FUNCTION public.update_user_role_secure(
  target_user_id UUID,
  new_role TEXT
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_user_role TEXT;
  target_user_current_role TEXT;
  existing_super_admin UUID;
BEGIN
  -- Get current user's role
  SELECT role INTO current_user_role 
  FROM profiles 
  WHERE id = auth.uid();
  
  -- Only admins and super_admins can update roles
  IF current_user_role NOT IN ('admin', 'super_admin') THEN
    RETURN jsonb_build_object('error', 'Insufficient permissions to update user roles');
  END IF;
  
  -- Get target user's current role
  SELECT role INTO target_user_current_role 
  FROM profiles 
  WHERE id = target_user_id;
  
  -- Prevent regular admins from editing other admins or super_admins
  IF current_user_role = 'admin' AND target_user_current_role IN ('admin', 'super_admin') THEN
    RETURN jsonb_build_object('error', 'Admin users cannot modify other admin or super admin accounts');
  END IF;
  
  -- Prevent creating multiple super_admins
  IF new_role = 'super_admin' THEN
    SELECT id INTO existing_super_admin 
    FROM profiles 
    WHERE role = 'super_admin' AND id != target_user_id 
    LIMIT 1;
    
    IF existing_super_admin IS NOT NULL THEN
      RETURN jsonb_build_object('error', 'Only one super admin can exist in the system');
    END IF;
  END IF;
  
  -- Update the role
  UPDATE profiles 
  SET role = new_role, updated_at = now()
  WHERE id = target_user_id;
  
  -- Log the action
  INSERT INTO admin_audit_log (
    admin_user_id, action_type, resource_type, resource_id,
    old_values, new_values, risk_level
  ) VALUES (
    auth.uid(), 'role_updated', 'profiles', target_user_id,
    jsonb_build_object('old_role', target_user_current_role),
    jsonb_build_object('new_role', new_role),
    CASE WHEN new_role = 'super_admin' THEN 'critical' 
         WHEN new_role = 'admin' THEN 'high' 
         ELSE 'medium' END
  );
  
  RETURN jsonb_build_object('success', true, 'message', 'Role updated successfully');
END;
$$;