-- Create a simple storage bucket for banners if it doesn't exist
INSERT INTO storage.buckets (id, name, public) 
VALUES ('banners', 'banners', true)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for banner uploads
CREATE POLICY "Anyone can view banner images" ON storage.objects 
FOR SELECT USING (bucket_id = 'banners');

CREATE POLICY "Authenticated users can upload banner images" ON storage.objects 
FOR INSERT WITH CHECK (
  bucket_id = 'banners' AND 
  auth.uid() IS NOT NULL AND
  (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'super_admin')))
);

CREATE POLICY "Admins can update banner images" ON storage.objects 
FOR UPDATE USING (
  bucket_id = 'banners' AND 
  auth.uid() IS NOT NULL AND
  (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'super_admin')))
);

CREATE POLICY "Admins can delete banner images" ON storage.objects 
FOR DELETE USING (
  bucket_id = 'banners' AND 
  auth.uid() IS NOT NULL AND
  (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin', 'super_admin')))
);