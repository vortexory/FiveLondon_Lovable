-- Create design_settings table for customizing website colors and styling
CREATE TABLE public.design_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  primary_color TEXT NOT NULL DEFAULT '#1a365d',
  secondary_color TEXT NOT NULL DEFAULT '#2d3748',
  accent_color TEXT NOT NULL DEFAULT '#e53e3e',
  text_color TEXT NOT NULL DEFAULT '#2d3748',
  background_color TEXT NOT NULL DEFAULT '#ffffff',
  button_primary_bg TEXT NOT NULL DEFAULT '#1a365d',
  button_primary_text TEXT NOT NULL DEFAULT '#ffffff',
  button_secondary_bg TEXT NOT NULL DEFAULT '#e2e8f0',
  button_secondary_text TEXT NOT NULL DEFAULT '#2d3748',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create button_texts table for customizing button labels
CREATE TABLE public.button_texts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  cta_primary TEXT NOT NULL DEFAULT 'Get Started',
  cta_secondary TEXT NOT NULL DEFAULT 'Learn More',
  learn_more TEXT NOT NULL DEFAULT 'Learn More',
  contact_us TEXT NOT NULL DEFAULT 'Contact Us',
  view_models TEXT NOT NULL DEFAULT 'View Our Models',
  book_now TEXT NOT NULL DEFAULT 'Book Now',
  get_started TEXT NOT NULL DEFAULT 'Get Started',
  read_more TEXT NOT NULL DEFAULT 'Read More',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add RLS policies for design_settings
ALTER TABLE public.design_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage design settings"
ON public.design_settings
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

CREATE POLICY "Design settings are viewable by everyone"
ON public.design_settings
FOR SELECT
USING (true);

-- Add RLS policies for button_texts
ALTER TABLE public.button_texts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage button texts"
ON public.button_texts
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() AND role = 'admin'
  )
);

CREATE POLICY "Button texts are viewable by everyone"
ON public.button_texts
FOR SELECT
USING (true);

-- Create triggers for updated_at timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_design_settings_updated_at
  BEFORE UPDATE ON public.design_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_button_texts_updated_at
  BEFORE UPDATE ON public.button_texts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default settings
INSERT INTO public.design_settings (id) VALUES (gen_random_uuid());
INSERT INTO public.button_texts (id) VALUES (gen_random_uuid());