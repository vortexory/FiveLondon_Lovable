-- Add encrypted columns and create secure access functions
-- (Skip trigger recreation for now since it already exists)

-- 1. Add encrypted columns for all sensitive data that doesn't already have them
ALTER TABLE model_applications 
ADD COLUMN IF NOT EXISTS measurements_encrypted text,
ADD COLUMN IF NOT EXISTS date_of_birth_encrypted text,
ADD COLUMN IF NOT EXISTS photos_encrypted text,
ADD COLUMN IF NOT EXISTS videos_encrypted text,
ADD COLUMN IF NOT EXISTS height_encrypted text,
ADD COLUMN IF NOT EXISTS tattoos_encrypted text,
ADD COLUMN IF NOT EXISTS piercings_encrypted text,
ADD COLUMN IF NOT EXISTS instagram_handle_encrypted text,
ADD COLUMN IF NOT EXISTS escort_experience_encrypted text;

-- 2. Create secure data access function with audit logging
CREATE OR REPLACE FUNCTION get_secure_model_application(application_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result jsonb;
  is_admin_user boolean;
BEGIN
  -- Check admin status
  is_admin_user := is_admin();
  
  -- Log the access attempt
  PERFORM log_security_event(
    'access_model_application',
    'model_applications',
    application_id,
    NULL,
    jsonb_build_object(
      'is_admin', is_admin_user,
      'timestamp', now()
    )
  );
  
  -- Return data based on access level
  IF is_admin_user THEN
    -- Admin gets full decrypted access
    SELECT jsonb_build_object(
      'id', id,
      'full_name', decrypt_pii_data(full_name_encrypted, 'contact'),
      'email', decrypt_pii_data(email_encrypted, 'contact'),
      'phone', decrypt_pii_data(phone_encrypted, 'contact'),
      'measurements', decrypt_pii_data(measurements_encrypted, 'measurements'),
      'photos', CASE WHEN photos_encrypted IS NOT NULL 
                THEN string_to_array(decrypt_pii_data(photos_encrypted, 'photos'), '|')
                ELSE photos END,
      'status', status,
      'created_at', created_at,
      'admin_notes', admin_notes
    ) INTO result
    FROM model_applications 
    WHERE id = application_id;
  ELSE
    -- Non-admin gets masked data only
    SELECT jsonb_build_object(
      'id', id,
      'full_name', mask_sensitive_application_data(full_name, 'name'),
      'email', mask_sensitive_application_data(email, 'email'),
      'phone', '***PROTECTED***',
      'measurements', '***PROTECTED***',
      'photos', '***PROTECTED***',
      'status', status,
      'created_at', created_at
    ) INTO result
    FROM model_applications 
    WHERE id = application_id;
  END IF;
  
  RETURN result;
END;
$$;