-- Fix admin user role assignment
-- Update any existing admin user to have the correct 'admin' role
UPDATE profiles 
SET 
  role = 'admin',
  status = 'approved',
  approved_at = COALESCE(approved_at, now()),
  updated_at = now()
WHERE email = 'admin@fivelondon.com' OR id IN (
  SELECT id FROM auth.users WHERE email = 'admin@fivelondon.com'
);

-- Log the security fix
INSERT INTO admin_audit_log (
  action_type,
  resource_type,
  new_values,
  risk_level
) VALUES (
  'security_fix_applied',
  'profiles',
  '{"fix": "admin_role_correction", "email": "admin@fivelondon.com"}',
  'high'
);