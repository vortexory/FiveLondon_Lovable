-- Temporarily disable problematic role update triggers to fix edge function role updates
-- These triggers were preventing legitimate role updates from edge functions

-- Drop the problematic triggers
DROP TRIGGER IF EXISTS prevent_role_update_trigger ON profiles;
DROP TRIGGER IF EXISTS handle_profile_updates_trigger ON profiles;

-- Create a simplified role validation trigger that works with edge functions
CREATE OR REPLACE FUNCTION public.validate_role_updates()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Allow all operations during INSERT (profile creation)
  IF TG_OP = 'INSERT' THEN
    RETURN NEW;
  END IF;
  
  -- During UPDATE, only validate role changes that matter
  IF TG_OP = 'UPDATE' AND OLD.role != NEW.role THEN
    -- Prevent multiple super_admins (only one allowed)
    IF NEW.role = 'super_admin' THEN
      -- Check if another super_admin already exists (excluding current user)
      IF EXISTS (
        SELECT 1 FROM profiles 
        WHERE role = 'super_admin' 
        AND id != NEW.id
      ) THEN
        RAISE EXCEPTION 'Only one super admin can exist in the system';
      END IF;
    END IF;
    
    -- Prevent changing FROM super_admin role (protect existing super admin)
    IF OLD.role = 'super_admin' AND NEW.role != 'super_admin' THEN
      RAISE EXCEPTION 'Super admin role cannot be changed';
    END IF;
  END IF;
  
  -- Update timestamp
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Create the new simplified trigger
CREATE TRIGGER validate_role_updates_trigger
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION validate_role_updates();

-- Also create a trigger for profile creation validation
CREATE OR REPLACE FUNCTION public.validate_profile_creation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Ensure only one super_admin can exist
  IF NEW.role = 'super_admin' THEN
    IF EXISTS (SELECT 1 FROM profiles WHERE role = 'super_admin') THEN
      RAISE EXCEPTION 'Only one super admin can exist in the system';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER validate_profile_creation_trigger
  BEFORE INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION validate_profile_creation();