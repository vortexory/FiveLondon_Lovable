-- Clear invalid image URLs from existing blog posts
UPDATE blog_posts 
SET 
  image = NULL,
  image_url_local = NULL,
  image_local = NULL
WHERE image LIKE '/images/%' OR image LIKE '/src/%';