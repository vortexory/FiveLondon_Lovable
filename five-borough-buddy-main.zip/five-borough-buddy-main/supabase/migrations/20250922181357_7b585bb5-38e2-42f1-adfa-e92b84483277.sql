-- Update FAQ RLS policy to allow both admin and super_admin roles to manage FAQs

-- Drop the existing policy
DROP POLICY IF EXISTS "Admin users can manage FAQs" ON public.faqs;

-- Create new policy that allows both admin and super_admin
CREATE POLICY "Admin and super admin users can manage FAQs" 
ON public.faqs 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role IN ('admin', 'super_admin')
  )
);