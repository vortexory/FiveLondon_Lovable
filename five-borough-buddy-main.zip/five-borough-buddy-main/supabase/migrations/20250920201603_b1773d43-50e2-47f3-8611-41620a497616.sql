-- 7. Create secure data access function for model applications
CREATE OR REPLACE FUNCTION get_secure_model_applications(include_sensitive boolean DEFAULT false)
RETURNS TABLE(
  id uuid,
  masked_full_name text,
  masked_email text,
  masked_phone text,
  age integer,
  nationality text,
  languages text[],
  status text,
  created_at timestamp with time zone,
  updated_at timestamp with time zone,
  -- Sensitive fields only for admins
  measurements text,
  photos text[],
  videos text[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Log the access attempt
  PERFORM log_sensitive_data_access('model_applications', NULL::uuid, 'bulk_access');
  
  -- Only admins can access sensitive data
  IF include_sensitive AND NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Sensitive data requires admin privileges';
  END IF;
  
  RETURN QUERY
  SELECT 
    ma.id,
    mask_sensitive_application_data(ma.full_name, 'name') as masked_full_name,
    mask_sensitive_application_data(ma.email, 'email') as masked_email,
    mask_sensitive_application_data(ma.phone, 'phone') as masked_phone,
    ma.age,
    ma.nationality,
    ma.languages,
    ma.status,
    ma.created_at,
    ma.updated_at,
    -- Sensitive fields (only for admins)
    CASE WHEN include_sensitive AND is_admin() THEN ma.measurements ELSE '***RESTRICTED***' END,
    CASE WHEN include_sensitive AND is_admin() THEN ma.photos ELSE ARRAY['***RESTRICTED***'] END,
    CASE WHEN include_sensitive AND is_admin() THEN ma.videos ELSE ARRAY['***RESTRICTED***'] END
  FROM model_applications ma
  WHERE is_admin(); -- Base RLS policy enforcement
END;
$$;

-- 8. Create function to encrypt existing data (for data migration)
CREATE OR REPLACE FUNCTION encrypt_existing_application_data()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  record_count integer := 0;
BEGIN
  -- Only admins can run this
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Only administrators can encrypt existing data';
  END IF;
  
  -- Encrypt existing data where encrypted columns are null
  UPDATE model_applications 
  SET 
    measurements_encrypted = CASE 
      WHEN measurements IS NOT NULL AND measurements_encrypted IS NULL 
      THEN encrypt_pii_data(measurements, 'measurements') 
      ELSE measurements_encrypted 
    END,
    date_of_birth_encrypted = CASE 
      WHEN date_of_birth IS NOT NULL AND date_of_birth_encrypted IS NULL 
      THEN encrypt_pii_data(date_of_birth::text, 'general') 
      ELSE date_of_birth_encrypted 
    END,
    photos_encrypted = CASE 
      WHEN photos IS NOT NULL AND photos_encrypted IS NULL 
      THEN encrypt_pii_data(array_to_string(photos, '|'), 'photos') 
      ELSE photos_encrypted 
    END,
    videos_encrypted = CASE 
      WHEN videos IS NOT NULL AND videos_encrypted IS NULL 
      THEN encrypt_pii_data(array_to_string(videos, '|'), 'photos') 
      ELSE videos_encrypted 
    END,
    height_encrypted = CASE 
      WHEN height IS NOT NULL AND height_encrypted IS NULL 
      THEN encrypt_pii_data(height, 'measurements') 
      ELSE height_encrypted 
    END;
    
  GET DIAGNOSTICS record_count = ROW_COUNT;
  
  -- Log the encryption operation
  INSERT INTO admin_audit_log (
    admin_user_id,
    action_type,
    resource_type,
    new_values,
    risk_level
  ) VALUES (
    auth.uid(),
    'bulk_data_encryption',
    'model_applications',
    jsonb_build_object('records_processed', record_count),
    'high'
  );
  
  RETURN 'Successfully encrypted ' || record_count || ' records';
END;
$$;