-- Fix RLS policy for preference categories to allow super_admin access
DROP POLICY IF EXISTS "Admin users can manage preference categories" ON public.preference_categories;

CREATE POLICY "Admin and super admin users can manage preference categories" 
ON public.preference_categories 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Also update the viewable policy to be consistent
DROP POLICY IF EXISTS "Preference categories are viewable by everyone" ON public.preference_categories;

CREATE POLICY "Preference categories are viewable by everyone" 
ON public.preference_categories 
FOR SELECT 
USING (is_active = true);