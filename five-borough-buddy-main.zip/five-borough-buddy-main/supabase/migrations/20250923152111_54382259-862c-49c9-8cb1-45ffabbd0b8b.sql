-- Add URL path field to characteristics table for SEO linking
ALTER TABLE public.characteristics 
ADD COLUMN IF NOT EXISTS seo_path TEXT;

-- Update characteristics with SEO paths based on preference_categories mapping
UPDATE public.characteristics 
SET seo_path = CASE 
  WHEN LOWER(name) = 'blonde' THEN '/characteristics/blonde-escorts'
  WHEN LOWER(name) = 'brunette' THEN '/characteristics/brunette-escorts'
  WHEN LOWER(name) = 'english' THEN '/characteristics/english-escorts'
  WHEN LOWER(name) = 'international' THEN '/characteristics/international-escorts'
  WHEN LOWER(name) LIKE '%vip%' OR LOWER(name) LIKE '%elite%' THEN '/characteristics/vip-escorts'
  WHEN LOWER(name) = 'brazilian' THEN '/characteristics/brazilian-escorts'
  WHEN LOWER(name) = 'russian' THEN '/characteristics/russian-escorts'
  WHEN LOWER(name) = 'european' THEN '/characteristics/european-escorts'
  WHEN LOWER(name) = 'latina' THEN '/characteristics/latina-escorts'
  WHEN LOWER(name) = 'young' THEN '/characteristics/young-escorts'
  WHEN LOWER(name) = 'petite' THEN '/characteristics/petite-escorts'
  WHEN LOWER(name) = 'slim' THEN '/characteristics/slim-escorts'
  WHEN LOWER(name) = 'tall' THEN '/characteristics/tall-escorts'
  WHEN LOWER(name) = 'natural' THEN '/characteristics/natural-escorts'
  WHEN LOWER(name) = 'high-class' THEN '/characteristics/high-class-escorts'
  WHEN LOWER(name) LIKE '%gfe%' OR LOWER(name) LIKE '%girlfriend%' THEN '/characteristics/gfe-escorts'
  WHEN LOWER(name) LIKE '%dinner%' THEN '/characteristics/dinner-date-escorts'
  WHEN LOWER(name) LIKE '%couples%' THEN '/characteristics/couples-escorts'
  WHEN LOWER(name) LIKE '%domination%' OR LOWER(name) LIKE '%fetish%' THEN '/characteristics/fetish-escorts'
  WHEN LOWER(name) LIKE '%outcall%' THEN '/characteristics/outcall-escorts'
  WHEN LOWER(name) LIKE '%party%' THEN '/characteristics/party-escorts'
  WHEN LOWER(name) LIKE '%bisexual%' THEN '/characteristics/bisexual-escorts'
  WHEN LOWER(name) LIKE '%exclusive%' THEN '/characteristics/exclusive-escorts'
  WHEN LOWER(name) LIKE '%open%' THEN '/characteristics/open-minded-escorts'
  ELSE CONCAT('/characteristics/', LOWER(REPLACE(REPLACE(name, ' ', '-'), '/', '-')), '-escorts')
END
WHERE seo_path IS NULL;