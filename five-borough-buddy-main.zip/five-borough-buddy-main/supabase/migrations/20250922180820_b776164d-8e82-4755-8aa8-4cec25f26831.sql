-- Test if we can update blog posts with image data
DO $$
DECLARE
    test_result record;
BEGIN
    -- Try to update the blog post with image data
    UPDATE blog_posts 
    SET 
        image = 'https://jiegopvbwpyfohhfvmwo.supabase.co/storage/v1/object/public/blog-images/1758564288601-zybfk1mu22.jpeg',
        image_url_local = 'https://jiegopvbwpyfohhfvmwo.supabase.co/storage/v1/object/public/blog-images/1758564288601-zybfk1mu22.jpeg',
        image_local = '1758564288601-zybfk1mu22.jpeg',
        updated_at = now()
    WHERE id = '55403dae-0c40-483e-8877-fad43b27c304';
    
    -- Check if the update worked
    SELECT image, image_url_local, image_local INTO test_result
    FROM blog_posts 
    WHERE id = '55403dae-0c40-483e-8877-fad43b27c304';
    
    -- Log the result
    RAISE NOTICE 'Update test - Image: %, Image URL Local: %, Image Local: %', 
        test_result.image, test_result.image_url_local, test_result.image_local;
        
    IF test_result.image IS NOT NULL THEN
        RAISE NOTICE 'SUCCESS: Blog post image fields can be updated';
    ELSE
        RAISE NOTICE 'FAILED: Blog post image fields are still null after update';
    END IF;
END $$;