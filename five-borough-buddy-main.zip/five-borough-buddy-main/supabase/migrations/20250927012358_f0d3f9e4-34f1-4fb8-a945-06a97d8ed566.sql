-- Insert hero banners into site_banners table to match frontend expectations
INSERT INTO site_banners (section, image_url, caption, alt_text, device_type, visibility, is_active, order_index) VALUES
  ('hero', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=1920&q=80', 'Welcome to Premium Elegance', 'Sophisticated woman in elegant attire', 'desktop', 'public', true, 0),
  ('hero', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=768&q=80', 'Welcome to Premium Elegance', 'Sophisticated woman in elegant attire', 'mobile', 'public', true, 0),
  ('hero', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1920&q=80', 'Elite Luxury Companionship', 'Professional portrait showcasing elegance', 'desktop', 'public', true, 1),
  ('hero', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=768&q=80', 'Elite Luxury Companionship', 'Professional portrait showcasing elegance', 'mobile', 'public', true, 1),
  ('hero', 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=1920&q=80', 'Discover Exceptional Service', 'Premium lifestyle and sophistication', 'all', 'public', true, 2);