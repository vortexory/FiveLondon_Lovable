-- Add blocks column to blog_posts table to support structured content
ALTER TABLE blog_posts ADD COLUMN IF NOT EXISTS blocks JSONB DEFAULT '[]'::jsonb;

-- Add a comment to describe the blocks structure
COMMENT ON COLUMN blog_posts.blocks IS 'Array of content blocks with structure: [{"id": "uuid", "type": "text|image", "content": "...", "order": 1}]';