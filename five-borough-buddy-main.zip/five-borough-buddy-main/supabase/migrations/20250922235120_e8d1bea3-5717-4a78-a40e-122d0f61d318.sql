-- Fix security warning by setting search_path immutable
CREATE OR REPLACE FUNCTION public.sync_model_photo_visibility(
  model_id_param UUID,
  visibility_type_param TEXT,
  photo_visibilities_param JSONB DEFAULT NULL
) RETURNS JSONB AS $$
DECLARE
  result JSONB;
  photos_updated INTEGER := 0;
  photo_record RECORD;
BEGIN
  -- Validate visibility_type parameter
  IF visibility_type_param NOT IN ('public', 'members_only', 'mixed') THEN
    RAISE EXCEPTION 'Invalid visibility_type. Must be public, members_only, or mixed';
  END IF;

  -- Update model visibility settings first
  UPDATE public.models 
  SET 
    visibility_type = visibility_type_param,
    members_only = CASE 
      WHEN visibility_type_param = 'members_only' THEN true 
      ELSE false 
    END,
    all_photos_public = CASE 
      WHEN visibility_type_param = 'public' THEN true 
      ELSE false 
    END,
    face_visible = CASE 
      WHEN visibility_type_param = 'mixed' THEN false 
      ELSE true 
    END,
    updated_at = now()
  WHERE id = model_id_param;

  -- Update photo visibilities based on type
  IF visibility_type_param = 'public' THEN
    -- All photos public
    UPDATE public.model_gallery 
    SET visibility = 'public' 
    WHERE model_id = model_id_param;
    
    GET DIAGNOSTICS photos_updated = ROW_COUNT;
    
  ELSIF visibility_type_param = 'members_only' THEN
    -- All photos members only
    UPDATE public.model_gallery 
    SET visibility = 'members_only' 
    WHERE model_id = model_id_param;
    
    GET DIAGNOSTICS photos_updated = ROW_COUNT;
    
  ELSIF visibility_type_param = 'mixed' AND photo_visibilities_param IS NOT NULL THEN
    -- Update individual photos based on provided visibilities
    FOR photo_record IN 
      SELECT id, visibility FROM public.model_gallery WHERE model_id = model_id_param
    LOOP
      DECLARE
        new_visibility TEXT;
      BEGIN
        new_visibility := photo_visibilities_param ->> photo_record.id::text;
        
        IF new_visibility IS NOT NULL AND new_visibility IN ('public', 'members_only') THEN
          UPDATE public.model_gallery 
          SET visibility = new_visibility::TEXT 
          WHERE id = photo_record.id;
          photos_updated := photos_updated + 1;
        END IF;
      END;
    END LOOP;
  END IF;

  -- Return success result
  result := jsonb_build_object(
    'success', true,
    'model_id', model_id_param,
    'visibility_type', visibility_type_param,
    'photos_updated', photos_updated,
    'timestamp', now()
  );

  RETURN result;
  
EXCEPTION
  WHEN OTHERS THEN
    -- Return error result
    result := jsonb_build_object(
      'success', false,
      'error', SQLERRM,
      'timestamp', now()
    );
    RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;