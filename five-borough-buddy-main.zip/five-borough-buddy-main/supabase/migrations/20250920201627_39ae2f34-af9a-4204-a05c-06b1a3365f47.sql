-- 9. Final security enhancements and documentation
-- Create a security summary function for administrators
CREATE OR REPLACE FUNCTION get_security_status()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  total_applications integer;
  encrypted_applications integer;
  recent_access_count integer;
BEGIN
  -- Only admins can check security status
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Only administrators can check security status';
  END IF;
  
  -- Get statistics
  SELECT COUNT(*) INTO total_applications FROM model_applications;
  
  SELECT COUNT(*) INTO encrypted_applications 
  FROM model_applications 
  WHERE full_name_encrypted IS NOT NULL;
  
  SELECT COUNT(*) INTO recent_access_count
  FROM security_audit_log 
  WHERE action LIKE '%sensitive_data%' 
  AND timestamp > now() - interval '24 hours';
  
  RETURN jsonb_build_object(
    'total_applications', total_applications,
    'encrypted_applications', encrypted_applications,
    'encryption_coverage', 
      CASE WHEN total_applications > 0 
        THEN round((encrypted_applications::numeric / total_applications::numeric) * 100, 2) 
        ELSE 0 
      END,
    'recent_sensitive_access_count', recent_access_count,
    'security_measures', jsonb_build_array(
      'Field-level encryption for PII',
      'Data masking for non-admin access',
      'Audit logging for sensitive data access',
      'Admin-only decryption functions',
      'Enhanced RLS policies'
    ),
    'last_check', now()
  );
END;
$$;

-- 10. Log the comprehensive security implementation
INSERT INTO admin_audit_log (
  action_type,
  resource_type,
  new_values,
  risk_level
) VALUES (
  'comprehensive_security_implementation',
  'model_applications',
  jsonb_build_object(
    'security_measures_implemented', jsonb_build_array(
      'Enhanced field-level encryption with category-specific keys',
      'Comprehensive data masking functions',
      'Automatic encryption triggers for all sensitive fields',
      'Audit logging for sensitive data access',
      'Secure data access functions with admin-only restrictions',
      'Data migration functions for existing records'
    ),
    'fields_protected', jsonb_build_array(
      'full_name', 'email', 'phone', 'measurements', 'date_of_birth',
      'photos', 'videos', 'height', 'tattoos', 'piercings',
      'instagram_handle', 'escort_experience'
    ),
    'compliance_level', 'enterprise_grade',
    'implementation_date', now()
  ),
  'critical'
);

-- Grant necessary permissions for the security functions
GRANT EXECUTE ON FUNCTION get_secure_model_applications TO authenticated;
GRANT EXECUTE ON FUNCTION get_security_status TO authenticated;
GRANT EXECUTE ON FUNCTION encrypt_existing_application_data TO authenticated;