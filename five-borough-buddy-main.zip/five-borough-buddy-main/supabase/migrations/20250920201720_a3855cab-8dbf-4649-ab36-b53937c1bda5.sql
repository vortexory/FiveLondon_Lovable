-- 8. Encrypt existing sensitive data in the database
CREATE OR REPLACE FUNCTION migrate_existing_sensitive_data()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  record_count integer := 0;
  current_record record;
BEGIN
  -- Only allow admins to run this migration
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Only admins can migrate sensitive data';
  END IF;
  
  -- Log the data migration start
  PERFORM log_sensitive_data_access(
    'model_applications',
    ARRAY['all_fields'],
    'data_migration_encryption'
  );
  
  -- Encrypt existing data that hasn't been encrypted yet
  FOR current_record IN 
    SELECT * FROM model_applications 
    WHERE (full_name_encrypted IS NULL AND full_name IS NOT NULL)
       OR (email_encrypted IS NULL AND email IS NOT NULL)
       OR (phone_encrypted IS NULL AND phone IS NOT NULL)
  LOOP
    UPDATE model_applications 
    SET 
      full_name_encrypted = CASE 
        WHEN current_record.full_name IS NOT NULL AND current_record.full_name_encrypted IS NULL 
        THEN encrypt_pii_data(current_record.full_name, 'contact') 
        ELSE current_record.full_name_encrypted 
      END,
      email_encrypted = CASE 
        WHEN current_record.email IS NOT NULL AND current_record.email_encrypted IS NULL 
        THEN encrypt_pii_data(current_record.email, 'contact') 
        ELSE current_record.email_encrypted 
      END,
      phone_encrypted = CASE 
        WHEN current_record.phone IS NOT NULL AND current_record.phone_encrypted IS NULL 
        THEN encrypt_pii_data(current_record.phone, 'contact') 
        ELSE current_record.phone_encrypted 
      END,
      measurements_encrypted = CASE 
        WHEN current_record.measurements IS NOT NULL AND current_record.measurements_encrypted IS NULL 
        THEN encrypt_pii_data(current_record.measurements, 'measurements') 
        ELSE current_record.measurements_encrypted 
      END
    WHERE id = current_record.id;
    
    record_count := record_count + 1;
  END LOOP;
  
  -- Log the completion
  INSERT INTO security_audit_log (
    user_id,
    action,
    table_name,
    new_values
  ) VALUES (
    auth.uid(),
    'data_migration_completed',
    'model_applications',
    jsonb_build_object(
      'records_processed', record_count,
      'migration_type', 'sensitive_data_encryption',
      'completed_at', now()
    )
  );
  
  RETURN format('Successfully encrypted sensitive data for %s records', record_count);
END;
$$;

-- 9. Add enhanced RLS policies with additional data protection
CREATE POLICY "Enhanced admin access with audit logging" 
ON model_applications 
FOR SELECT 
TO authenticated
USING (
  is_admin() AND (
    -- Log every access attempt
    log_sensitive_data_access('model_applications', ARRAY['SELECT'], 'rls_policy_access') IS NULL
    OR true -- Allow access after logging
  )
);

-- 10. Create final security summary function
CREATE OR REPLACE FUNCTION get_security_status()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encrypted_records integer;
  total_records integer;
  result jsonb;
BEGIN
  -- Only admins can check security status
  IF NOT is_admin() THEN
    RETURN jsonb_build_object('error', 'Access denied');
  END IF;
  
  SELECT COUNT(*) INTO total_records FROM model_applications;
  SELECT COUNT(*) INTO encrypted_records 
  FROM model_applications 
  WHERE full_name_encrypted IS NOT NULL 
     OR email_encrypted IS NOT NULL 
     OR phone_encrypted IS NOT NULL;
  
  result := jsonb_build_object(
    'total_records', total_records,
    'encrypted_records', encrypted_records,
    'encryption_coverage', CASE 
      WHEN total_records > 0 THEN (encrypted_records::float / total_records * 100)::numeric(5,2)
      ELSE 0 
    END,
    'security_measures_active', jsonb_build_object(
      'field_level_encryption', true,
      'data_masking', true,
      'audit_logging', true,
      'admin_only_access', true,
      'enhanced_rls_policies', true
    ),
    'last_updated', now()
  );
  
  RETURN result;
END;
$$;