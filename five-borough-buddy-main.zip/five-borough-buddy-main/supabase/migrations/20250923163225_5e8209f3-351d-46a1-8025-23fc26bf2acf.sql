-- Create RLS policy to allow authenticated users to upload images to model-images bucket
CREATE POLICY "Authenticated users can upload model images" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'model-images'
  AND auth.uid() IS NOT NULL
);

-- Create RLS policy to allow users to view model images (public bucket)
CREATE POLICY "Anyone can view model images" ON storage.objects
FOR SELECT USING (
  bucket_id = 'model-images'
);

-- Create RLS policy to allow users to delete their own uploaded images
CREATE POLICY "Users can delete their own model images" ON storage.objects
FOR DELETE USING (
  bucket_id = 'model-images'
  AND auth.uid() IS NOT NULL
);

-- Create RLS policy to allow users to update their own uploaded images
CREATE POLICY "Users can update their own model images" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'model-images'
  AND auth.uid() IS NOT NULL
);