-- Check if blog-images bucket exists and create it if not
INSERT INTO storage.buckets (id, name, public) 
VALUES ('blog-images', 'blog-images', true)
ON CONFLICT (id) DO NOTHING;

-- Ensure proper RLS policies for blog-images bucket
DO $$
BEGIN
    -- Drop existing policies if they exist
    DROP POLICY IF EXISTS "Blog images are publicly accessible" ON storage.objects;
    DROP POLICY IF EXISTS "Authenticated users can upload blog images" ON storage.objects;
    DROP POLICY IF EXISTS "Authenticated users can update blog images" ON storage.objects;
    DROP POLICY IF EXISTS "Authenticated users can delete blog images" ON storage.objects;
    
    -- Create new policies
    CREATE POLICY "Blog images are publicly accessible" 
    ON storage.objects 
    FOR SELECT 
    USING (bucket_id = 'blog-images');

    CREATE POLICY "Admin users can upload blog images" 
    ON storage.objects 
    FOR INSERT 
    WITH CHECK (bucket_id = 'blog-images' AND (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE id = auth.uid() AND role = 'admin'
        )
    ));

    CREATE POLICY "Admin users can update blog images" 
    ON storage.objects 
    FOR UPDATE 
    USING (bucket_id = 'blog-images' AND (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE id = auth.uid() AND role = 'admin'
        )
    ));

    CREATE POLICY "Admin users can delete blog images" 
    ON storage.objects 
    FOR DELETE 
    USING (bucket_id = 'blog-images' AND (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE id = auth.uid() AND role = 'admin'
        )
    ));
END $$;