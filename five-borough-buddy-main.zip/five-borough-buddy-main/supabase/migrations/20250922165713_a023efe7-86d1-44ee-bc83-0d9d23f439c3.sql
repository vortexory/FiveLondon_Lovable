-- Add super_admin role and update admin@fivelondon.com to super_admin
-- Update the admin user to super_admin
UPDATE profiles 
SET role = 'super_admin' 
WHERE email = 'admin@fivelondon.com';

-- Create function to check if user is super admin
CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT CASE 
    WHEN auth.uid() IS NULL THEN false
    ELSE EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'super_admin'
    )
  END;
$function$;

-- Update get_current_user_role function to handle super_admin
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS text
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT COALESCE(role, 'user') FROM public.profiles WHERE id = auth.uid();
$function$;

-- Update profile update trigger to prevent role escalation
CREATE OR REPLACE FUNCTION public.handle_profile_updates()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Only super admins can change admin/super_admin roles
  IF TG_OP = 'UPDATE' AND OLD.role != NEW.role THEN
    -- Prevent admins from changing other admin/super_admin roles
    IF OLD.role IN ('admin', 'super_admin') AND NOT is_super_admin() THEN
      NEW.role = OLD.role;
    END IF;
    
    -- Prevent regular users from changing their role (unless no admins exist - bootstrap case)
    IF NOT (
      is_super_admin() OR 
      is_admin() OR
      NOT EXISTS (SELECT 1 FROM profiles WHERE role IN ('admin', 'super_admin'))
    ) THEN
      NEW.role = OLD.role;
    END IF;
  END IF;
  
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;