UPDATE profiles 
SET role = 'admin', 
    status = 'approved',
    approved_at = now(),
    updated_at = now()
WHERE id = '2d7f5829-5b9f-4608-b8ec-fccbb4bf1804';