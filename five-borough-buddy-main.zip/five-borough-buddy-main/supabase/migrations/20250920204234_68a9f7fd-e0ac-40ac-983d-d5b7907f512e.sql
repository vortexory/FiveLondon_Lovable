-- Force update the specific user to admin role
UPDATE profiles 
SET 
    role = 'admin',
    status = 'approved',
    approved_at = COALESCE(approved_at, now()),
    updated_at = now()
WHERE email = 'admin@fivelondon.com' OR id = '2d7f5829-5b9f-4608-b8ec-fccbb4bf1804';

-- Verify the update worked
SELECT id, email, role, status, updated_at FROM profiles WHERE email = 'admin@fivelondon.com';