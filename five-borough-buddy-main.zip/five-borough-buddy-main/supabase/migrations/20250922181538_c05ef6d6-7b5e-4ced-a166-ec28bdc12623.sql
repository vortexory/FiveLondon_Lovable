-- Fix FAQ RLS policy to allow super_admin users
-- We need to drop and recreate because PostgreSQL doesn't support CREATE OR REPLACE for policies

BEGIN;

-- Drop the old policy
DROP POLICY "Admin users can manage FAQs" ON public.faqs;

-- Create new policy that allows both admin and super_admin
CREATE POLICY "Admins and super admins can manage FAQs" 
ON public.faqs 
FOR ALL 
TO public
USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role IN ('admin', 'super_admin')
  )
);

COMMIT;