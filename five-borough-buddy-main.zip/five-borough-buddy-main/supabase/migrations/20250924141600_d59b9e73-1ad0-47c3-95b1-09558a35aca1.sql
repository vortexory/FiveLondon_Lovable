-- Fix the RLS policies for blog-images bucket
DO $$
BEGIN
    -- Drop existing policies
    DROP POLICY IF EXISTS "Blog images are publicly accessible" ON storage.objects;
    DROP POLICY IF EXISTS "Admin users can upload blog images" ON storage.objects;
    DROP POLICY IF EXISTS "Admin users can update blog images" ON storage.objects;
    DROP POLICY IF EXISTS "Admin users can delete blog images" ON storage.objects;
    
    -- Create new corrected policies
    CREATE POLICY "Blog images are publicly accessible" 
    ON storage.objects 
    FOR SELECT 
    USING (bucket_id = 'blog-images');

    CREATE POLICY "Admin users can upload blog images" 
    ON storage.objects 
    FOR INSERT 
    WITH CHECK (
        bucket_id = 'blog-images' 
        AND auth.uid() IS NOT NULL 
        AND is_admin()
    );

    CREATE POLICY "Admin users can update blog images" 
    ON storage.objects 
    FOR UPDATE 
    USING (
        bucket_id = 'blog-images' 
        AND auth.uid() IS NOT NULL 
        AND is_admin()
    );

    CREATE POLICY "Admin users can delete blog images" 
    ON storage.objects 
    FOR DELETE 
    USING (
        bucket_id = 'blog-images' 
        AND auth.uid() IS NOT NULL 
        AND is_admin()
    );
END $$;