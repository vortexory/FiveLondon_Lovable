-- Create model-images storage bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public) 
VALUES ('model-images', 'model-images', true)
ON CONFLICT (id) DO NOTHING;

-- Create RLS policies for model-images bucket
CREATE POLICY "Admin and super admin can upload to model-images"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'model-images' 
  AND EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admin and super admin can view model-images"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'model-images' 
  AND EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admin and super admin can update model-images"
ON storage.objects
FOR UPDATE
USING (
  bucket_id = 'model-images' 
  AND EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admin and super admin can delete model-images"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'model-images' 
  AND EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role IN ('admin', 'super_admin')
  )
);

-- Allow public access to view images (since bucket is public)
CREATE POLICY "Public can view model-images"
ON storage.objects
FOR SELECT
USING (bucket_id = 'model-images');