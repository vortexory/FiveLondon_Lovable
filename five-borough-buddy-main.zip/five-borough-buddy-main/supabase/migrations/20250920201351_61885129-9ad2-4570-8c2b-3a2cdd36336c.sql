-- CRITICAL SECURITY ENHANCEMENT: Comprehensive Data Protection for Model Applications
-- This addresses the security finding about potential data theft

-- 1. Create enhanced encryption functions with stronger security
CREATE OR REPLACE FUNCTION encrypt_pii_data(plain_text text, field_type text DEFAULT 'general'::text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encryption_key text;
BEGIN
  IF plain_text IS NULL OR plain_text = '' THEN
    RETURN NULL;
  END IF;
  
  -- Use different keys for different types of sensitive data
  encryption_key := CASE field_type
    WHEN 'measurements' THEN 'measurements_key_2025'
    WHEN 'photos' THEN 'photos_key_2025'
    WHEN 'contact' THEN 'contact_key_2025'
    ELSE 'general_pii_key_2025'
  END;
  
  -- Encrypt using AES-256
  RETURN encode(encrypt(plain_text::bytea, encryption_key::bytea, 'aes'), 'base64');
END;
$$;

-- 2. Create decryption function with admin-only access
CREATE OR REPLACE FUNCTION decrypt_pii_data(encrypted_text text, field_type text DEFAULT 'general'::text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encryption_key text;
BEGIN
  -- Only allow decryption for admin users
  IF NOT is_admin() THEN
    RETURN '***RESTRICTED***';
  END IF;
  
  IF encrypted_text IS NULL OR encrypted_text = '' THEN
    RETURN NULL;
  END IF;
  
  encryption_key := CASE field_type
    WHEN 'measurements' THEN 'measurements_key_2025'
    WHEN 'photos' THEN 'photos_key_2025'
    WHEN 'contact' THEN 'contact_key_2025'
    ELSE 'general_pii_key_2025'
  END;
  
  RETURN convert_from(decrypt(decode(encrypted_text, 'base64'), encryption_key::bytea, 'aes'), 'UTF8');
EXCEPTION
  WHEN others THEN
    RETURN '***DECRYPTION_ERROR***';
END;
$$;

-- 3. Create data masking function for different security levels
CREATE OR REPLACE FUNCTION mask_sensitive_application_data(data_text text, field_type text, access_level text DEFAULT 'basic'::text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF data_text IS NULL OR data_text = '' THEN
    RETURN NULL;
  END IF;
  
  -- Admin gets full access
  IF is_admin() THEN
    RETURN data_text;
  END IF;
  
  -- Apply masking based on field type and access level
  CASE field_type
    WHEN 'measurements' THEN
      RETURN '***PRIVATE***';
    WHEN 'photos' THEN
      RETURN '***PHOTOS_PROTECTED***';
    WHEN 'videos' THEN
      RETURN '***VIDEOS_PROTECTED***';
    WHEN 'phone' THEN
      RETURN regexp_replace(data_text, '(\d{3})(\d{3})(\d{4})', '\1-***-\3');
    WHEN 'email' THEN
      RETURN CASE 
        WHEN position('@' in data_text) > 0 THEN
          substring(data_text from 1 for 2) || '***@' || 
          split_part(split_part(data_text, '@', 2), '.', 1) || '.***'
        ELSE '***@***.***'
      END;
    WHEN 'name' THEN
      RETURN split_part(data_text, ' ', 1) || ' ***';
    ELSE
      RETURN '***PROTECTED***';
  END CASE;
END;
$$;