-- 6. Create comprehensive audit logging for sensitive data access
CREATE OR REPLACE FUNCTION log_sensitive_data_access(
  accessed_table text,
  accessed_fields text[],
  access_reason text DEFAULT 'data_access'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO security_audit_log (
    user_id,
    action,
    table_name,
    new_values,
    user_agent,
    ip_address
  ) VALUES (
    auth.uid(),
    'sensitive_data_access',
    accessed_table,
    jsonb_build_object(
      'accessed_fields', accessed_fields,
      'access_reason', access_reason,
      'timestamp', now(),
      'security_level', 'high'
    ),
    'database_function',
    inet '127.0.0.1' -- Will be updated by application layer if available
  );
END;
$$;

-- 7. Create secure data access function for model applications with full audit logging
CREATE OR REPLACE FUNCTION get_model_applications_secure(include_encrypted boolean DEFAULT false)
RETURNS TABLE(
  id uuid,
  full_name text,
  email text,
  phone text,
  age integer,
  status text,
  created_at timestamp with time zone,
  admin_notes text,
  measurements text,
  photos text[],
  videos text[]
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only admins can access this function
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required for sensitive data access';
  END IF;
  
  -- Log the sensitive data access
  PERFORM log_sensitive_data_access(
    'model_applications',
    ARRAY['full_name', 'email', 'phone', 'measurements', 'photos', 'videos'],
    CASE WHEN include_encrypted THEN 'full_admin_access' ELSE 'standard_admin_access' END
  );
  
  -- Return data with appropriate decryption based on access level
  IF include_encrypted THEN
    RETURN QUERY
    SELECT 
      ma.id,
      COALESCE(decrypt_pii_data(ma.full_name_encrypted, 'contact'), ma.full_name) as full_name,
      COALESCE(decrypt_pii_data(ma.email_encrypted, 'contact'), ma.email) as email,
      COALESCE(decrypt_pii_data(ma.phone_encrypted, 'contact'), ma.phone) as phone,
      ma.age,
      ma.status,
      ma.created_at,
      ma.admin_notes,
      COALESCE(decrypt_pii_data(ma.measurements_encrypted, 'measurements'), ma.measurements) as measurements,
      CASE 
        WHEN ma.photos_encrypted IS NOT NULL THEN 
          string_to_array(decrypt_pii_data(ma.photos_encrypted, 'photos'), '|')
        ELSE ma.photos 
      END as photos,
      CASE 
        WHEN ma.videos_encrypted IS NOT NULL THEN 
          string_to_array(decrypt_pii_data(ma.videos_encrypted, 'photos'), '|')
        ELSE ma.videos 
      END as videos
    FROM model_applications ma;
  ELSE
    -- Return masked data for standard admin access
    RETURN QUERY
    SELECT 
      ma.id,
      mask_sensitive_application_data(ma.full_name, 'name') as full_name,
      mask_sensitive_application_data(ma.email, 'email') as email,
      mask_sensitive_application_data(ma.phone, 'phone') as phone,
      ma.age,
      ma.status,
      ma.created_at,
      ma.admin_notes,
      mask_sensitive_application_data(ma.measurements, 'measurements') as measurements,
      ARRAY['***PHOTOS_PROTECTED***'] as photos,
      ARRAY['***VIDEOS_PROTECTED***'] as videos
    FROM model_applications ma;
  END IF;
END;
$$;