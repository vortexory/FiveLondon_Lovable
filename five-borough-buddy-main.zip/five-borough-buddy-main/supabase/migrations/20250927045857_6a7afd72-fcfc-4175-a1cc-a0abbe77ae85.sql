-- Create storage buckets for gallery images
INSERT INTO storage.buckets (id, name, public, allowed_mime_types, file_size_limit) 
VALUES 
  ('public-gallery', 'public-gallery', true, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif'], 20971520),
  ('model-galleries', 'model-galleries', true, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif'], 20971520);

-- Create RLS policies for public-gallery bucket
CREATE POLICY "Public gallery images are viewable by everyone" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'public-gallery');

CREATE POLICY "Admins can upload to public gallery" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'public-gallery' AND 
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admins can update public gallery images" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'public-gallery' AND 
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admins can delete public gallery images" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'public-gallery' AND 
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
  )
);

-- Create RLS policies for model-galleries bucket
CREATE POLICY "Model gallery images are viewable by everyone" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'model-galleries');

CREATE POLICY "Admins can upload to model galleries" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'model-galleries' AND 
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admins can update model gallery images" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'model-galleries' AND 
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admins can delete model gallery images" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'model-galleries' AND 
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
  )
);