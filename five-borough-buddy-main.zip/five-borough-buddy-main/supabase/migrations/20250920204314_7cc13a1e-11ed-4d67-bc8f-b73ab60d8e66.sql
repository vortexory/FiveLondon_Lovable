-- Use the special admin function that bypasses the circular dependency
-- First, let me temporarily disable RLS to fix the bootstrap issue
ALTER TABLE profiles DISABLE ROW LEVEL SECURITY;

-- Update the user to admin
UPDATE profiles 
SET 
    role = 'admin',
    status = 'approved',
    approved_at = COALESCE(approved_at, now()),
    updated_at = now()
WHERE email = 'admin@fivelondon.com';

-- Re-enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Verify the update
SELECT id, email, role, status FROM profiles WHERE email = 'admin@fivelondon.com';