-- Remove extra hero banners, keep only mobile and desktop versions
DELETE FROM site_banners WHERE section = 'hero';

-- Insert only two hero banners - one for desktop and one for mobile
INSERT INTO site_banners (section, image_url, caption, alt_text, device_type, visibility, is_active, order_index) VALUES
  ('hero', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=1920&q=80', 'Welcome to Premium Elegance', 'Sophisticated woman in elegant attire', 'desktop', 'public', true, 0),
  ('hero', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=768&q=80', 'Welcome to Premium Elegance', 'Sophisticated woman in elegant attire', 'mobile', 'public', true, 0);