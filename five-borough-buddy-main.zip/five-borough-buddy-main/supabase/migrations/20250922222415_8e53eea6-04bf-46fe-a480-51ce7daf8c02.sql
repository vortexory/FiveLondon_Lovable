-- Add visibility_type field to models table to support public, mixed, and members_only states
ALTER TABLE public.models ADD COLUMN visibility_type text DEFAULT 'public';

-- Add check constraint to ensure valid visibility types
ALTER TABLE public.models ADD CONSTRAINT check_visibility_type 
CHECK (visibility_type IN ('public', 'mixed', 'members_only'));

-- Update existing models based on their members_only status
UPDATE public.models 
SET visibility_type = CASE 
  WHEN members_only = true THEN 'members_only'
  WHEN members_only = false THEN 'public'
  ELSE 'public'
END;

-- We'll keep the members_only field for backward compatibility for now
-- but we'll primarily use visibility_type going forward