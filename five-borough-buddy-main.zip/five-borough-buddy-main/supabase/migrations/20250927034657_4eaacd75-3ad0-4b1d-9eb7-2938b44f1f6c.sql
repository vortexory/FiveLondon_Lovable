-- Fix the RLS policy to allow both admin and super_admin roles
DROP POLICY IF EXISTS "Admin users can manage site banners" ON public.site_banners;

CREATE POLICY "Admin and super admin users can manage site banners" 
ON public.site_banners 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role IN ('admin', 'super_admin')
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role IN ('admin', 'super_admin')
  )
);