-- Create storage bucket for category images
INSERT INTO storage.buckets (id, name, public, allowed_mime_types, file_size_limit) 
VALUES 
  ('preference-categories', 'preference-categories', true, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif'], 20971520);

-- Create RLS policies for preference-categories bucket
CREATE POLICY "Category images are viewable by everyone" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'preference-categories');

CREATE POLICY "Admins can upload to category images" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'preference-categories' AND 
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admins can update category images" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'preference-categories' AND 
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admins can delete category images" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'preference-categories' AND 
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND role IN ('admin', 'super_admin')
  )
);