-- CRITICAL SECURITY FIX: Remove the problematic Security Definer view
-- This view bypasses RLS policies and exposes sensitive personal data

DROP VIEW IF EXISTS public.model_applications_secure;

-- Log this critical security fix
INSERT INTO admin_audit_log (
  action_type,
  resource_type,
  new_values,
  risk_level
) VALUES (
  'critical_security_fix',
  'view',
  '{"action": "removed_security_definer_view", "view_name": "model_applications_secure", "reason": "bypassed_rls_exposed_sensitive_data"}',
  'critical'
);

-- Create a proper function for admins to access model applications data if needed
-- This function respects RLS and requires admin privileges
CREATE OR REPLACE FUNCTION get_model_applications_admin()
RETURNS TABLE(
  id uuid,
  email text,
  status text,
  created_at timestamp with time zone,
  reviewed_at timestamp with time zone
)
LANGUAGE SQL
SECURITY DEFINER
SET search_path = public
AS $$
  -- Only admins can access this function
  SELECT 
    ma.id,
    ma.email,
    ma.status,
    ma.created_at,
    ma.reviewed_at
  FROM model_applications ma
  WHERE is_admin();
$$;