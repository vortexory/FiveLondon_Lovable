-- Fix RLS policies to prevent infinite recursion
-- Drop existing problematic policies
DROP POLICY IF EXISTS "Admin users can manage blog posts" ON public.blog_posts;
DROP POLICY IF EXISTS "Admin users can manage models" ON public.models;

-- Create or update security definer functions (these might already exist)
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT CASE 
    WHEN auth.uid() IS NULL THEN false
    ELSE EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  END;
$$;

CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS text
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT COALESCE(role, 'user') FROM public.profiles WHERE id = auth.uid();
$$;

-- Create new policies using security definer functions
CREATE POLICY "Admin users can manage blog posts" 
ON public.blog_posts 
FOR ALL 
USING (public.is_admin());

CREATE POLICY "Admin users can manage models" 
ON public.models 
FOR ALL 
USING (public.is_admin());

-- Ensure proper permissions for delete operations
GRANT DELETE ON public.blog_posts TO authenticated;
GRANT DELETE ON public.models TO authenticated;