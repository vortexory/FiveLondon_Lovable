-- Ensure super admin role is unique and protected
-- Add constraint to ensure only one super admin exists
ALTER TABLE profiles ADD CONSTRAINT unique_super_admin 
EXCLUDE (role WITH =) WHERE (role = 'super_admin');

-- Update profile update trigger to prevent super admin role changes
CREATE OR REPLACE FUNCTION public.handle_profile_updates()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Prevent changing super_admin role (must remain unique and protected)
  IF TG_OP = 'UPDATE' AND OLD.role = 'super_admin' AND NEW.role != 'super_admin' THEN
    RAISE EXCEPTION 'Super admin role cannot be changed';
  END IF;
  
  -- Prevent creating new super_admin through updates (only one allowed)
  IF TG_OP = 'UPDATE' AND OLD.role != 'super_admin' AND NEW.role = 'super_admin' THEN
    RAISE EXCEPTION 'Cannot create additional super admin - role is unique';
  END IF;
  
  -- Only super admins can change admin/super_admin roles
  IF TG_OP = 'UPDATE' AND OLD.role != NEW.role THEN
    -- Prevent admins from changing other admin/super_admin roles
    IF OLD.role IN ('admin', 'super_admin') AND NOT is_super_admin() THEN
      NEW.role = OLD.role;
    END IF;
    
    -- Prevent regular users from changing their role (unless no admins exist - bootstrap case)
    IF NOT (
      is_super_admin() OR 
      is_admin() OR
      NOT EXISTS (SELECT 1 FROM profiles WHERE role IN ('admin', 'super_admin'))
    ) THEN
      NEW.role = OLD.role;
    END IF;
  END IF;
  
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;