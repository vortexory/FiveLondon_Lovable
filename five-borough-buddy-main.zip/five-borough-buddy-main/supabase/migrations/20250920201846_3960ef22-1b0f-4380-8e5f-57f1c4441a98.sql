-- 3. Create enhanced RLS policies with additional safeguards
-- Drop existing policies to recreate with enhanced security
DROP POLICY IF EXISTS "admin_only_select_applications" ON model_applications;
DROP POLICY IF EXISTS "admin_only_update_applications" ON model_applications;
DROP POLICY IF EXISTS "admin_only_delete_applications" ON model_applications;
DROP POLICY IF EXISTS "approved_users_insert_applications" ON model_applications;

-- Create enhanced RLS policies with audit logging
CREATE POLICY "enhanced_admin_select_applications" 
ON model_applications 
FOR SELECT 
USING (
  is_admin() AND (
    -- Log every admin access to sensitive data
    log_security_event('admin_access_application', 'model_applications', id) IS NULL
    OR true
  )
);

CREATE POLICY "enhanced_admin_update_applications" 
ON model_applications 
FOR UPDATE 
USING (
  is_admin() AND (
    -- Log every admin modification
    log_security_event('admin_update_application', 'model_applications', id) IS NULL
    OR true
  )
)
WITH CHECK (
  is_admin()
);

CREATE POLICY "enhanced_admin_delete_applications" 
ON model_applications 
FOR DELETE 
USING (
  is_admin() AND (
    -- Log every deletion attempt (high risk)
    log_security_event('admin_delete_application', 'model_applications', id) IS NULL
    OR true
  )
);

-- Enhanced insert policy with additional validation
CREATE POLICY "secure_user_insert_applications" 
ON model_applications 
FOR INSERT 
WITH CHECK (
  auth.uid() IS NOT NULL 
  AND is_approved_user() 
  AND email IS NOT NULL 
  AND full_name IS NOT NULL 
  AND length(TRIM(BOTH FROM email)) > 0 
  AND length(TRIM(BOTH FROM full_name)) > 0
  AND (
    -- Log application submissions for monitoring
    log_security_event('user_submit_application', 'model_applications', gen_random_uuid()) IS NULL
    OR true
  )
);

-- 4. Create function to migrate existing plain text data to encrypted format
CREATE OR REPLACE FUNCTION migrate_existing_sensitive_data()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  processed_count integer := 0;
  rec record;
BEGIN
  -- Only allow admins to run this migration
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Only admins can migrate sensitive data';
  END IF;
  
  -- Process existing records that don't have encrypted data
  FOR rec IN 
    SELECT id, measurements, date_of_birth, photos, videos, height, 
           tattoos, piercings, instagram_handle, escort_experience
    FROM model_applications 
    WHERE measurements_encrypted IS NULL 
       OR date_of_birth_encrypted IS NULL
  LOOP
    UPDATE model_applications 
    SET 
      measurements_encrypted = CASE 
        WHEN rec.measurements IS NOT NULL 
        THEN encrypt_pii_data(rec.measurements, 'measurements') 
        ELSE NULL END,
      date_of_birth_encrypted = CASE 
        WHEN rec.date_of_birth IS NOT NULL 
        THEN encrypt_pii_data(rec.date_of_birth::text, 'general') 
        ELSE NULL END,
      photos_encrypted = CASE 
        WHEN rec.photos IS NOT NULL 
        THEN encrypt_pii_data(array_to_string(rec.photos, '|'), 'photos') 
        ELSE NULL END,
      videos_encrypted = CASE 
        WHEN rec.videos IS NOT NULL 
        THEN encrypt_pii_data(array_to_string(rec.videos, '|'), 'photos') 
        ELSE NULL END,
      height_encrypted = CASE 
        WHEN rec.height IS NOT NULL 
        THEN encrypt_pii_data(rec.height, 'measurements') 
        ELSE NULL END,
      tattoos_encrypted = CASE 
        WHEN rec.tattoos IS NOT NULL 
        THEN encrypt_pii_data(rec.tattoos, 'general') 
        ELSE NULL END,
      piercings_encrypted = CASE 
        WHEN rec.piercings IS NOT NULL 
        THEN encrypt_pii_data(rec.piercings, 'general') 
        ELSE NULL END,
      instagram_handle_encrypted = CASE 
        WHEN rec.instagram_handle IS NOT NULL 
        THEN encrypt_pii_data(rec.instagram_handle, 'contact') 
        ELSE NULL END,
      escort_experience_encrypted = CASE 
        WHEN rec.escort_experience IS NOT NULL 
        THEN encrypt_pii_data(rec.escort_experience, 'general') 
        ELSE NULL END
    WHERE id = rec.id;
    
    processed_count := processed_count + 1;
  END LOOP;
  
  -- Log the migration
  PERFORM log_security_event(
    'sensitive_data_migration',
    'model_applications',
    NULL,
    NULL,
    jsonb_build_object(
      'processed_records', processed_count,
      'migration_timestamp', now()
    )
  );
  
  RETURN format('Successfully migrated %s records with enhanced encryption', processed_count);
END;
$$;