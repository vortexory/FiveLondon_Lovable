-- Create locations table for SEO functionality
CREATE TABLE public.locations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  seo_path TEXT UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;

-- Create policies for locations
CREATE POLICY "Locations are viewable by everyone" 
ON public.locations 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage locations" 
ON public.locations 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.profiles 
  WHERE id = auth.uid() AND role = 'admin'
));

-- Insert existing locations from models table
INSERT INTO public.locations (name, seo_path, description, order_index) VALUES
('Belgravia', 'belgravia', 'Exclusive companions in prestigious Belgravia area', 1),
('Knightsbridge', 'knightsbridge', 'Elite escorts in luxury Knightsbridge district', 2),
('Mayfair', 'mayfair', 'Premium companions in the heart of Mayfair', 3),
('Chelsea', 'chelsea', 'Sophisticated escorts in fashionable Chelsea', 4),
('Kensington', 'kensington', 'Elegant companions in Royal Kensington', 5),
('Marylebone', 'marylebone', 'Refined escorts in charming Marylebone', 6),
('Canary Wharf', 'canary-wharf', 'Professional companions in business district', 7),
('City of London', 'city-of-london', 'Executive escorts in the financial center', 8),
('Covent Garden', 'covent-garden', 'Cultural companions in vibrant Covent Garden', 9),
('Notting Hill', 'notting-hill', 'Stylish escorts in trendy Notting Hill', 10);