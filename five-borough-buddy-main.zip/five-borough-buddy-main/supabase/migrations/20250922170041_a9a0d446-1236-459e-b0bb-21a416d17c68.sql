-- Update RLS policies to include super_admin access

-- Drop existing policies that only check for admin
DROP POLICY IF EXISTS "Admins can manage all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;

-- Create new policies that include both admin and super_admin
CREATE POLICY "Admins and super admins can manage all profiles" 
ON profiles 
FOR ALL 
USING (get_current_user_role() IN ('admin', 'super_admin'));

CREATE POLICY "Admins and super admins can view all profiles" 
ON profiles 
FOR SELECT 
USING (get_current_user_role() IN ('admin', 'super_admin'));

-- Update other RLS policies that might have the same issue
-- Update model_applications policies
DROP POLICY IF EXISTS "strict_admin_only_select" ON model_applications;
DROP POLICY IF EXISTS "strict_admin_only_update" ON model_applications;  
DROP POLICY IF EXISTS "strict_admin_only_delete" ON model_applications;

CREATE POLICY "admin_and_super_admin_select" 
ON model_applications 
FOR SELECT 
USING ((is_admin() OR is_super_admin()) AND ((log_admin_action('view_application_data'::text, 'model_applications'::text, id, NULL::jsonb, jsonb_build_object('action', 'view_sensitive_data', 'timestamp', now(), 'security_level', 'critical'), 'critical'::text) IS NULL) OR true));

CREATE POLICY "admin_and_super_admin_update" 
ON model_applications 
FOR UPDATE 
USING (is_admin() OR is_super_admin())
WITH CHECK (is_admin() OR is_super_admin());

CREATE POLICY "admin_and_super_admin_delete" 
ON model_applications 
FOR DELETE 
USING (is_admin() OR is_super_admin());