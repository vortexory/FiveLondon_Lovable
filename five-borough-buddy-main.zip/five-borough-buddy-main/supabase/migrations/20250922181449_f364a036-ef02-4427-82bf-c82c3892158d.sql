-- Simply create the new policy without dropping the old one first
-- If it conflicts, we'll handle it differently

CREATE OR REPLACE POLICY "Admin and super admin users can manage FAQs" 
ON public.faqs 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role IN ('admin', 'super_admin')
  )
);