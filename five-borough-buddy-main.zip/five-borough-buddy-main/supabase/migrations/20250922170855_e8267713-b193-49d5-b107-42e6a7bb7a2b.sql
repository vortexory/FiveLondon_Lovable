-- Add image_url_local column to store Supabase Storage URLs
ALTER TABLE blog_posts 
ADD COLUMN IF NOT EXISTS image_url_local TEXT,
ADD COLUMN IF NOT EXISTS image_local TEXT;

-- Update the table to use proper storage for blog images
UPDATE blog_posts 
SET image_url_local = NULL, image_local = NULL 
WHERE image LIKE '/images/%' OR image LIKE '/src/%';