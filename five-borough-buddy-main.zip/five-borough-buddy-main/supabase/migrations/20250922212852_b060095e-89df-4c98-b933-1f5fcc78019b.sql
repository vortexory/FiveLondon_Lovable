-- Add explicit DELETE policy for models table to ensure proper deletion
DROP POLICY IF EXISTS "Admin users can delete models" ON public.models;

CREATE POLICY "Admin users can delete models"
ON public.models
FOR DELETE
USING (is_admin());