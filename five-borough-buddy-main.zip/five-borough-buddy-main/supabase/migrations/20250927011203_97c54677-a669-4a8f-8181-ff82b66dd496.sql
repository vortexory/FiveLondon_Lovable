-- Restore site_banners table with realistic banner data
INSERT INTO site_banners (section, image_url, caption, alt_text, visibility, device_type, is_active, order_index) VALUES
-- Homepage banners
('homepage', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=1920&q=80', 'Welcome to our premium services', 'Premium homepage banner featuring elegant design', 'public', 'all', true, 0),
('homepage', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1920&q=80', 'Experience luxury and sophistication', 'Sophisticated homepage banner with professional styling', 'public', 'all', false, 1),

-- Services banners  
('services', 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=1920&q=80', 'Our premium companion services', 'Services banner showcasing elegant companion services', 'public', 'all', true, 0),

-- About banners
('about', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=1920&q=80', 'Learn about our story and values', 'About us banner with professional team representation', 'public', 'all', true, 0),

-- Contact banners
('contact', 'https://images.unsplash.com/photo-1423666639041-f56000c27a9a?w=1920&q=80', 'Get in touch with our team', 'Contact banner with communication theme', 'public', 'all', true, 0);