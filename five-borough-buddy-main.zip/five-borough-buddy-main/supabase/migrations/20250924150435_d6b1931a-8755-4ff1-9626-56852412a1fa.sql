-- Function to convert existing blog post HTML content to blocks
CREATE OR REPLACE FUNCTION convert_html_content_to_blocks()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  post_record RECORD;
  text_blocks JSONB;
  image_blocks JSONB;
  all_blocks JSONB;
  block_order INTEGER;
BEGIN
  -- Process each blog post that has content but empty blocks
  FOR post_record IN 
    SELECT id, content, image 
    FROM blog_posts 
    WHERE content IS NOT NULL 
    AND content != '' 
    AND (blocks IS NULL OR blocks = '[]'::jsonb)
  LOOP
    text_blocks := '[]'::jsonb;
    image_blocks := '[]'::jsonb;
    block_order := 1;
    
    -- Create a main text block from existing content
    IF post_record.content IS NOT NULL AND post_record.content != '' THEN
      text_blocks := text_blocks || jsonb_build_array(
        jsonb_build_object(
          'id', gen_random_uuid()::text,
          'type', 'text',
          'content', post_record.content,
          'title', 'Main Content',
          'order', block_order
        )
      );
      block_order := block_order + 1;
    END IF;
    
    -- Create an image block if there's a main image
    IF post_record.image IS NOT NULL AND post_record.image != '' THEN
      image_blocks := image_blocks || jsonb_build_array(
        jsonb_build_object(
          'id', gen_random_uuid()::text,
          'type', 'image', 
          'content', post_record.image,
          'caption', 'Main Article Image',
          'alt', 'Article featured image',
          'order', block_order
        )
      );
      block_order := block_order + 1;
    END IF;
    
    -- Combine all blocks
    all_blocks := text_blocks || image_blocks;
    
    -- Update the blog post with the new blocks
    UPDATE blog_posts 
    SET blocks = all_blocks
    WHERE id = post_record.id;
    
    RAISE NOTICE 'Converted blog post % to blocks format', post_record.id;
  END LOOP;
  
  RAISE NOTICE 'Completed HTML content to blocks conversion';
END;
$function$;

-- Execute the conversion
SELECT convert_html_content_to_blocks();