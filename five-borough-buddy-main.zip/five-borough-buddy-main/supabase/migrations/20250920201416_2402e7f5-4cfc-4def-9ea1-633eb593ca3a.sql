-- 4. Add encrypted columns for all sensitive data that doesn't already have them
ALTER TABLE model_applications 
ADD COLUMN IF NOT EXISTS measurements_encrypted text,
ADD COLUMN IF NOT EXISTS date_of_birth_encrypted text,
ADD COLUMN IF NOT EXISTS photos_encrypted text,
ADD COLUMN IF NOT EXISTS videos_encrypted text,
ADD COLUMN IF NOT EXISTS height_encrypted text,
ADD COLUMN IF NOT EXISTS tattoos_encrypted text,
ADD COLUMN IF NOT EXISTS piercings_encrypted text,
ADD COLUMN IF NOT EXISTS instagram_handle_encrypted text,
ADD COLUMN IF NOT EXISTS escort_experience_encrypted text;

-- 5. Create comprehensive encryption trigger
CREATE OR REPLACE FUNCTION encrypt_sensitive_application_data()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Encrypt all sensitive fields before storing
  IF NEW.full_name IS NOT NULL THEN
    NEW.full_name_encrypted = encrypt_pii_data(NEW.full_name, 'contact');
  END IF;
  
  IF NEW.email IS NOT NULL THEN
    NEW.email_encrypted = encrypt_pii_data(NEW.email, 'contact');
  END IF;
  
  IF NEW.phone IS NOT NULL THEN
    NEW.phone_encrypted = encrypt_pii_data(NEW.phone, 'contact');
  END IF;
  
  IF NEW.measurements IS NOT NULL THEN
    NEW.measurements_encrypted = encrypt_pii_data(NEW.measurements, 'measurements');
  END IF;
  
  IF NEW.date_of_birth IS NOT NULL THEN
    NEW.date_of_birth_encrypted = encrypt_pii_data(NEW.date_of_birth::text, 'general');
  END IF;
  
  IF NEW.photos IS NOT NULL THEN
    NEW.photos_encrypted = encrypt_pii_data(array_to_string(NEW.photos, '|'), 'photos');
  END IF;
  
  IF NEW.videos IS NOT NULL THEN
    NEW.videos_encrypted = encrypt_pii_data(array_to_string(NEW.videos, '|'), 'photos');
  END IF;
  
  IF NEW.height IS NOT NULL THEN
    NEW.height_encrypted = encrypt_pii_data(NEW.height, 'measurements');
  END IF;
  
  IF NEW.tattoos IS NOT NULL THEN
    NEW.tattoos_encrypted = encrypt_pii_data(NEW.tattoos, 'general');
  END IF;
  
  IF NEW.piercings IS NOT NULL THEN
    NEW.piercings_encrypted = encrypt_pii_data(NEW.piercings, 'general');
  END IF;
  
  IF NEW.instagram_handle IS NOT NULL THEN
    NEW.instagram_handle_encrypted = encrypt_pii_data(NEW.instagram_handle, 'contact');
  END IF;
  
  IF NEW.escort_experience IS NOT NULL THEN
    NEW.escort_experience_encrypted = encrypt_pii_data(NEW.escort_experience, 'general');
  END IF;
  
  RETURN NEW;
END;
$$;

-- Replace the existing encryption trigger with the enhanced one
DROP TRIGGER IF EXISTS encrypt_application_data_trigger ON model_applications;
CREATE TRIGGER encrypt_sensitive_application_data_trigger
  BEFORE INSERT OR UPDATE ON model_applications
  FOR EACH ROW
  EXECUTE FUNCTION encrypt_sensitive_application_data();