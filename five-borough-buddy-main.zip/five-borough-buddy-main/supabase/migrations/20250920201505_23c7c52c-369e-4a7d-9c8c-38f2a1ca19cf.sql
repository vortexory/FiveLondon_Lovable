-- Fix the trigger issue and continue with security enhancements
-- 4. Add encrypted columns for all sensitive data that doesn't already have them
ALTER TABLE model_applications 
ADD COLUMN IF NOT EXISTS measurements_encrypted text,
ADD COLUMN IF NOT EXISTS date_of_birth_encrypted text,
ADD COLUMN IF NOT EXISTS photos_encrypted text,
ADD COLUMN IF NOT EXISTS videos_encrypted text,
ADD COLUMN IF NOT EXISTS height_encrypted text,
ADD COLUMN IF NOT EXISTS tattoos_encrypted text,
ADD COLUMN IF NOT EXISTS piercings_encrypted text,
ADD COLUMN IF NOT EXISTS instagram_handle_encrypted text,
ADD COLUMN IF NOT EXISTS escort_experience_encrypted text;

-- 5. Drop existing triggers and create comprehensive encryption trigger
DROP TRIGGER IF EXISTS encrypt_application_data_trigger ON model_applications;
DROP TRIGGER IF EXISTS encrypt_sensitive_application_data_trigger ON model_applications;

-- Create comprehensive encryption trigger with unique name
CREATE TRIGGER enhanced_encrypt_application_data_trigger
  BEFORE INSERT OR UPDATE ON model_applications
  FOR EACH ROW
  EXECUTE FUNCTION encrypt_sensitive_application_data();

-- 6. Create audit logging function for sensitive data access
CREATE OR REPLACE FUNCTION log_sensitive_data_access(
  table_name text,
  record_id uuid,
  access_type text,
  field_accessed text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    new_values,
    ip_address
  ) VALUES (
    auth.uid(),
    access_type || '_sensitive_data',
    table_name,
    record_id,
    jsonb_build_object(
      'field_accessed', field_accessed,
      'timestamp', now(),
      'access_level', CASE WHEN is_admin() THEN 'admin' ELSE 'user' END
    ),
    inet_client_addr()
  );
END;
$$;