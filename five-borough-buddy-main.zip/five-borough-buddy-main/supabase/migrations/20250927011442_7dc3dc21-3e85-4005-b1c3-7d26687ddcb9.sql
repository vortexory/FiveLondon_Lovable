-- Update existing hero slides with realistic banner images
UPDATE hero_slides SET 
  image_url = 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=1920&q=80',
  image_url_mobile = 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=768&q=80',
  title = 'Welcome to Premium Elegance',
  subtitle = 'Experience sophisticated companionship services',
  button_text = 'Explore Our Services',
  button_link = '/models'
WHERE id = '575d935e-2302-4865-95d1-c46b4ec244cb';

UPDATE hero_slides SET 
  image_url = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1920&q=80',
  image_url_mobile = 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=768&q=80',
  title = 'Elite Luxury Companionship',
  subtitle = 'Unparalleled elegance and sophistication',
  button_text = 'View Our Models',
  button_link = '/models'
WHERE id = '862627b7-9f5d-4054-852c-52307438f614';

-- Add a third hero slide for variety
INSERT INTO hero_slides (title, subtitle, image_url, image_url_mobile, button_text, button_link, order_index, active) VALUES
('Discover Exceptional Service', 'Premium companionship tailored to your needs', 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=1920&q=80', 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=768&q=80', 'Get Started', '/contact', 2, true);