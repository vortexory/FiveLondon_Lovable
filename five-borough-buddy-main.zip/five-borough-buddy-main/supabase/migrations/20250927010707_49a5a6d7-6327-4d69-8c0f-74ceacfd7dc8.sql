-- Simplify hero_slides table by removing unnecessary fields
-- First, let's backup the current image data by updating main image_url with local versions where they exist
UPDATE hero_slides 
SET image_url = COALESCE(image_url_local_desktop, image_url_local, image_url)
WHERE image_url_local_desktop IS NOT NULL OR image_url_local IS NOT NULL;

-- Add mobile image field (simplified)
ALTER TABLE hero_slides 
ADD COLUMN IF NOT EXISTS image_url_mobile text;

-- Update mobile image from existing local mobile URLs
UPDATE hero_slides 
SET image_url_mobile = image_url_local_mobile
WHERE image_url_local_mobile IS NOT NULL;

-- Remove unnecessary video and multiple image URL fields
ALTER TABLE hero_slides 
DROP COLUMN IF EXISTS video_url,
DROP COLUMN IF EXISTS media_type,
DROP COLUMN IF EXISTS image_url_local,
DROP COLUMN IF EXISTS image_url_local_desktop,
DROP COLUMN IF EXISTS image_url_local_mobile,
DROP COLUMN IF EXISTS image_url_local_fallback;

-- Remove redundant site_banners entries for hero section since we have hero_slides
DELETE FROM site_banners WHERE section = 'hero';

-- Simplify hero_settings by removing show_scroll_indicator (not commonly used)
ALTER TABLE hero_settings 
DROP COLUMN IF EXISTS show_scroll_indicator;

-- Add a description to hero_settings for better UX
ALTER TABLE hero_settings 
ADD COLUMN IF NOT EXISTS description text DEFAULT 'Configure hero section behavior and timing';

-- Update site_banners sections to be more realistic
-- Remove 'header' and 'footer' sections as they're not commonly needed
DELETE FROM site_banners WHERE section IN ('header', 'footer');

-- Update SECTIONS in the banner management component will be handled in code
-- The realistic sections are: homepage, services, about, contact