-- Drop and recreate the trigger properly
DROP TRIGGER IF EXISTS handle_profile_updates_trigger ON profiles;

-- Recreate the function and trigger
CREATE OR REPLACE FUNCTION public.handle_profile_updates()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Allow role changes if current user is admin OR if no admins exist yet (bootstrap case)
  IF TG_OP = 'UPDATE' AND OLD.role != NEW.role THEN
    IF NOT (
      (SELECT get_current_user_role()) = 'admin' OR
      NOT EXISTS (SELECT 1 FROM profiles WHERE role = 'admin')
    ) THEN
      NEW.role = OLD.role;
    END IF;
  END IF;
  
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

CREATE TRIGGER handle_profile_updates_trigger
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION handle_profile_updates();