-- Recreate the profile security triggers with better logic
CREATE OR REPLACE FUNCTION public.handle_profile_updates()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Allow role changes if:
  -- 1. User is updating their own non-sensitive fields
  -- 2. Current user is already an admin
  -- 3. This is the initial admin bootstrap (no admins exist yet)
  
  IF TG_OP = 'UPDATE' AND OLD.role != NEW.role THEN
    -- Allow if current user is admin OR if no admins exist yet (bootstrap case)
    IF NOT (
      (SELECT get_current_user_role()) = 'admin' OR
      NOT EXISTS (SELECT 1 FROM profiles WHERE role = 'admin')
    ) THEN
      -- Don't allow non-admins to change roles, but preserve the old role
      NEW.role = OLD.role;
    END IF;
  END IF;
  
  -- Always update the timestamp
  NEW.updated_at = now();
  
  RETURN NEW;
END;
$function$;

-- Attach the trigger
CREATE TRIGGER handle_profile_updates_trigger
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION handle_profile_updates();

-- Clear any cached auth state to force refresh
NOTIFY pgrst, 'reload config';