-- Fix all CRUD permissions for model management - ensure admin and super_admin have full access

-- Drop existing policies for models table
DROP POLICY IF EXISTS "Admin users can delete models" ON public.models;
DROP POLICY IF EXISTS "Admin users can insert models" ON public.models;
DROP POLICY IF EXISTS "Admin users can update models" ON public.models;
DROP POLICY IF EXISTS "Authenticated users can view all model data" ON public.models;
DROP POLICY IF EXISTS "Everyone can view basic model info via function" ON public.models;

-- Create comprehensive admin/super_admin policies for models
CREATE POLICY "Admins and super admins can manage all models"
ON public.models
FOR ALL
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
)
WITH CHECK (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
);

-- Keep existing select policies for public access
CREATE POLICY "Authenticated users can view all model data"
ON public.models
FOR SELECT
USING (
  (auth.uid() IS NOT NULL) OR 
  ((members_only = false) OR (members_only IS NULL))
);

-- Fix model_gallery policies
DROP POLICY IF EXISTS "Admin users can manage model gallery" ON public.model_gallery;

CREATE POLICY "Admins and super admins can manage model gallery"
ON public.model_gallery
FOR ALL
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
)
WITH CHECK (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
);

-- Fix model_reviews policies
DROP POLICY IF EXISTS "Admins can manage model reviews" ON public.model_reviews;

CREATE POLICY "Admins and super admins can manage model reviews"
ON public.model_reviews
FOR ALL
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
)
WITH CHECK (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
);

-- Fix homepage_carousel policies
DROP POLICY IF EXISTS "Admins can manage homepage carousel" ON public.homepage_carousel;

CREATE POLICY "Admins and super admins can manage homepage carousel"
ON public.homepage_carousel
FOR ALL
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
)
WITH CHECK (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
);

-- Fix public_gallery policies
DROP POLICY IF EXISTS "Admin users can manage public gallery" ON public.public_gallery;

CREATE POLICY "Admins and super admins can manage public gallery"
ON public.public_gallery
FOR ALL
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
)
WITH CHECK (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE public.profiles.id = auth.uid() 
    AND public.profiles.role IN ('admin', 'super_admin')
  )
);