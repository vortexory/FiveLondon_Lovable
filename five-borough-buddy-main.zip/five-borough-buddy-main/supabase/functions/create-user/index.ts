import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface CreateUserRequest {
  email: string;
  password: string;
  role: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { 
        status: 405, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }

  try {
    // Create admin Supabase client using service role key
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    // Parse request body
    const { email, password, role }: CreateUserRequest = await req.json();

    // Validate input
    if (!email || !password || !role) {
      return new Response(
        JSON.stringify({ error: 'Email, password, and role are required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log('Received request to create user:', { email, role });
    
    // Get the requesting user's token and verify permissions
    const authHeader = req.headers.get('authorization');
    console.log('Auth header present:', !!authHeader);
    
    if (!authHeader) {
      console.log('No authorization header found');
      return new Response(
        JSON.stringify({ error: 'Authorization header required' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Verify user authentication and get their profile using admin client
    const token = authHeader.replace('Bearer ', '');
    console.log('Attempting to verify token for user creation...');
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);
    
    if (userError || !user) {
      console.error('Auth error:', userError);
      return new Response(
        JSON.stringify({ error: 'Invalid authentication token' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log('User authenticated successfully:', user.id);

    // Check user permissions
    const { data: profile, error: profileError } = await supabaseAdmin
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (profileError || !profile) {
      return new Response(
        JSON.stringify({ error: 'User profile not found' }),
        { 
          status: 403, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Only super_admin can create users with any role, admin can only create regular users
    if (profile.role === 'super_admin') {
      // Super admin can create any role, but check if trying to create another super_admin
      if (role === 'super_admin') {
        // Check if a super_admin already exists
        const { data: existingSuperAdmin } = await supabaseAdmin
          .from('profiles')
          .select('id')
          .eq('role', 'super_admin')
          .limit(1);
        
        if (existingSuperAdmin && existingSuperAdmin.length > 0) {
          return new Response(
            JSON.stringify({ error: 'Only one super admin can exist in the system' }),
            { 
              status: 403, 
              headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
            }
          );
        }
      }
    } else if (profile.role === 'admin') {
      // Admin can only create user roles
      if (role !== 'user') {
        return new Response(
          JSON.stringify({ error: 'Admin users can only create regular user accounts' }),
          { 
            status: 403, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }
    } else {
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions to create users' }),
        { 
          status: 403, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log(`Creating user with email: ${email} and role: ${role}`);

    // Create the user in auth.users
    const { data: authUser, error: authUserError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        role: role
      }
    });

    if (authUserError) {
      console.error('Error creating auth user:', authUserError);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to create user', 
          details: authUserError.message 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    if (!authUser.user) {
      return new Response(
        JSON.stringify({ error: 'User creation failed - no user returned' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log('Auth user created with ID:', authUser.user.id);

    // Check if profile already exists (might be created by trigger)
    const { data: existingProfile } = await supabaseAdmin
      .from('profiles')
      .select('id, role')
      .eq('id', authUser.user.id)
      .single();

    if (!existingProfile) {
      console.log('Creating new profile with role:', role);
      // Create the profile record only if it doesn't exist
      const { error: profileCreateError } = await supabaseAdmin
        .from('profiles')
        .insert({
          id: authUser.user.id,
          email: email,
          role: role,
          status: 'approved',
          approved_at: new Date().toISOString(),
          approved_by: user.id
        });

      if (profileCreateError) {
        console.error('Error creating profile:', profileCreateError);
        
        // Try to clean up the auth user if profile creation fails
        await supabaseAdmin.auth.admin.deleteUser(authUser.user.id);
        
        return new Response(
          JSON.stringify({ 
            error: 'Failed to create user profile', 
            details: profileCreateError.message
          }),
          { 
            status: 400, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }
      console.log('User profile created successfully with role:', role);
    } else {
      console.log('Profile already exists, updating with role and approval info');
      console.log('Existing role:', existingProfile.role, 'New role:', role);
      
      // Use service role permissions to bypass triggers
      const { error: updateError } = await supabaseAdmin
        .from('profiles')
        .update({
          role: role,
          status: 'approved',
          approved_at: new Date().toISOString(),
          approved_by: user.id,
          updated_at: new Date().toISOString()
        })
        .eq('id', authUser.user.id);

      if (updateError) {
        console.error('Error updating existing profile:', updateError);
        return new Response(
          JSON.stringify({ 
            error: 'Failed to update user profile', 
            details: updateError.message
          }),
          { 
            status: 400, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }
      console.log('Existing profile updated successfully');
    }

    // Log the admin action
    await supabaseAdmin.from('admin_audit_log').insert({
      admin_user_id: user.id,
      action_type: 'user_created',
      resource_type: 'profiles',
      resource_id: authUser.user.id,
      new_values: {
        email: email,
        role: role,
        status: 'approved'
      },
      risk_level: role === 'super_admin' ? 'critical' : role === 'admin' ? 'high' : 'medium'
    });

    return new Response(
      JSON.stringify({
        success: true,
        message: 'User created successfully',
        user_id: authUser.user.id,
        email: email,
        role: role
      }),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Unexpected error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error', 
        details: (error as Error).message || 'Unknown error' 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});