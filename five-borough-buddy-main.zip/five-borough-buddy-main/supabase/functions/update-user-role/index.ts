import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface UpdateRoleRequest {
  userId: string;
  newRole: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { 
        status: 405, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }

  try {
    // Create admin Supabase client
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    // Parse request
    const { userId, newRole }: UpdateRoleRequest = await req.json();
    console.log('Updating user role:', { userId, newRole });

    // Validate input
    if (!userId || !newRole) {
      return new Response(
        JSON.stringify({ error: 'User ID and new role are required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Get authorization token
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Authorization required' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Verify user authentication
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);
    
    if (userError || !user) {
      console.error('Auth error:', userError);
      return new Response(
        JSON.stringify({ error: 'Invalid authentication' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log('Attempting to update role for user:', userId, 'to role:', newRole);

    // Get current user role for validation
    const { data: currentUserProfile } = await supabaseAdmin
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (!currentUserProfile || !['admin', 'super_admin'].includes(currentUserProfile.role)) {
      return new Response(
        JSON.stringify({ error: 'Insufficient permissions to update user roles' }),
        { 
          status: 403, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Get target user's current role
    const { data: targetUserProfile } = await supabaseAdmin
      .from('profiles')
      .select('role')
      .eq('id', userId)
      .single();

    if (!targetUserProfile) {
      return new Response(
        JSON.stringify({ error: 'Target user not found' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log('Current user role:', currentUserProfile.role);
    console.log('Target user current role:', targetUserProfile.role);

    // Prevent regular admins from editing other admins or super_admins
    if (currentUserProfile.role === 'admin' && targetUserProfile.role === 'super_admin') {
      return new Response(
        JSON.stringify({ error: 'Admin users cannot modify super admin accounts' }),
        { 
          status: 403, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Prevent creating multiple super_admins
    if (newRole === 'super_admin') {
      const { data: existingSuperAdmin } = await supabaseAdmin
        .from('profiles')
        .select('id')
        .eq('role', 'super_admin')
        .neq('id', userId)
        .single();

      if (existingSuperAdmin) {
        return new Response(
          JSON.stringify({ error: 'Only one super admin can exist in the system' }),
          { 
            status: 400, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }
    }

    // Update the role directly using service role permissions
    const { error: updateError } = await supabaseAdmin
      .from('profiles')
      .update({ 
        role: newRole, 
        updated_at: new Date().toISOString() 
      })
      .eq('id', userId);

    if (updateError) {
      console.error('Direct role update error:', updateError);
      return new Response(
        JSON.stringify({ error: 'Failed to update user role: ' + updateError.message }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Log the action
    await supabaseAdmin.from('admin_audit_log').insert({
      admin_user_id: user.id,
      action_type: 'role_updated',
      resource_type: 'profiles',
      resource_id: userId,
      old_values: { old_role: targetUserProfile.role },
      new_values: { new_role: newRole },
      risk_level: newRole === 'super_admin' ? 'critical' : newRole === 'admin' ? 'high' : 'medium'
    });

    console.log('Role updated successfully from', targetUserProfile.role, 'to', newRole);

    return new Response(
      JSON.stringify({ success: true, message: 'Role updated successfully' }),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Unexpected error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error', 
        details: (error as Error).message || 'Unknown error'
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});