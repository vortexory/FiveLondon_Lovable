import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Get admin credentials from environment variables (Supabase secrets)
const ADMIN_EMAIL = Deno.env.get('ADMIN_EMAIL');
const ADMIN_PASSWORD = Deno.env.get('ADMIN_PASSWORD');

interface CreateAdminRequest {
  email: string;
  password: string;
  confirm?: boolean;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { 
        status: 405, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }

  try {
    console.log('Create admin function called');
    
    // Validate environment variables are available
    if (!ADMIN_EMAIL || !ADMIN_PASSWORD) {
      console.error('Missing admin credentials in environment variables');
      return new Response(
        JSON.stringify({ error: 'Server configuration error: Missing admin credentials' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }
    
    // Use credentials from environment variables
    const email = ADMIN_EMAIL;
    const password = ADMIN_PASSWORD;

    // Create admin Supabase client using service role key
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    console.log(`Creating admin user with email: ${email}`);

    // Check if user already exists
    const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
    const existingUser = existingUsers.users?.find(user => user.email === email);
    
    if (existingUser) {
      console.log('Admin user already exists, checking profile...');
      
      // Check if profile exists
      const { data: profile } = await supabaseAdmin
        .from('profiles')
        .select('*')
        .eq('id', existingUser.id)
        .single();
        
      if (!profile) {
        // Create missing profile
        const { error: profileError } = await supabaseAdmin
          .from('profiles')
          .insert({
            id: existingUser.id,
            email: email,
            role: 'admin',
            status: 'approved',
            approved_at: new Date().toISOString(),
          });
          
        if (profileError) {
          console.error('Error creating missing profile:', profileError);
        }
      }
      
      return new Response(
        JSON.stringify({
          success: true,
          message: 'Admin user already exists and is ready to use',
          email: email,
          note: 'You can now login with these credentials'
        }),
        { 
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Step 1: Create the admin user in auth.users
    const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        role: 'admin'
      }
    });

    if (authError) {
      console.error('Error creating auth user:', authError);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to create admin user', 
          details: authError.message 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    if (!authUser.user) {
      return new Response(
        JSON.stringify({ error: 'User creation failed - no user returned' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log(`Auth user created with ID: ${authUser.user.id}`);

    // Step 2: Create the profile record
    const { error: profileError } = await supabaseAdmin
      .from('profiles')
      .insert({
        id: authUser.user.id,
        email: email,
        role: 'admin',
        status: 'approved',
        approved_at: new Date().toISOString(),
      });

    if (profileError) {
      console.error('Error creating profile:', profileError);
      
      // If profile creation fails, we should clean up the auth user
      // But for now, just log and return error
      return new Response(
        JSON.stringify({ 
          error: 'Failed to create admin profile', 
          details: profileError.message,
          note: 'Auth user was created but profile creation failed'
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log('Admin profile created successfully');

    // Log the admin creation for security audit
    await supabaseAdmin.from('admin_audit_log').insert({
      admin_user_id: authUser.user.id,
      action_type: 'admin_user_created',
      resource_type: 'user',
      resource_id: authUser.user.id,
      new_values: {
        email: email,
        role: 'admin',
        status: 'approved'
      },
      risk_level: 'high'
    });

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Admin user created successfully',
        user_id: authUser.user.id,
        email: email,
        role: 'admin'
      }),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Unexpected error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error', 
        details: (error as Error).message || 'Unknown error'
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});