# Five London Admin Panel

A modern React Vite admin panel for managing the Five London website.

## Features

- 🔐 Secure admin authentication with Supabase
- 📊 Dashboard with system statistics
- 📝 Blog management
- 👥 Model management
- 👤 User management
- ⚙️ System settings
- 🎨 Modern UI with Tailwind CSS
- 📱 Responsive design

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn
- Supabase account

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open [http://localhost:5173](http://localhost:5173) in your browser

### Admin User Creation

Admin users must be created through the Supabase API using Postman. See `POSTMAN_API.md` for detailed instructions.

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── ui/             # Basic UI components (Button, Input, etc.)
│   ├── Layout.tsx      # Main layout wrapper
│   ├── Sidebar.tsx     # Navigation sidebar
│   └── ProtectedRoute.tsx # Route protection
├── contexts/           # React contexts
│   └── AuthContext.tsx # Authentication context
├── pages/              # Page components
│   ├── Login.tsx       # Admin login page
│   ├── Dashboard.tsx   # Main dashboard
│   ├── BlogManagement.tsx
│   ├── ModelManagement.tsx
│   ├── UserManagement.tsx
│   └── Settings.tsx
├── lib/                # Utility functions
│   ├── supabase.ts     # Supabase client
│   └── utils.ts        # General utilities
└── App.tsx             # Main app component
```

## Database Connection

The admin panel connects to the same Supabase database as the main website:
- **URL**: `https://jiegopvbwpyfohhfvmwo.supabase.co`
- **Tables**: profiles, models, blog_posts, model_applications

## Authentication

- Admin users are authenticated through Supabase Auth
- Admin status is determined by the `role` field in the `profiles` table
- Only users with `role: "admin"` and `status: "approved"` can access the panel

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Security

- All admin routes are protected
- Database queries use Row Level Security (RLS)
- Admin status is verified on every request
- Service role key is only used for admin user creation

## Contributing

1. Follow the existing code style
2. Use TypeScript for all new code
3. Test all changes thoroughly
4. Update documentation as needed

## License

Private project - All rights reserved