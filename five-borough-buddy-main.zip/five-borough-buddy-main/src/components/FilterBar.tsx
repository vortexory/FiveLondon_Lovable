import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X, Filter, Search } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface FilterOption {
  key: string;
  label: string;
  type: 'select' | 'search' | 'date';
  options?: { value: string; label: string }[];
  placeholder?: string;
}

interface FilterBarProps {
  filters: Record<string, any>;
  onFilterChange: (key: string, value: any) => void;
  onClearFilters: () => void;
  filterOptions: FilterOption[];
  activeFiltersCount: number;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onFilterChange,
  onClearFilters,
  filterOptions,
  activeFiltersCount
}) => {
  const [isExpanded, setIsExpanded] = React.useState(false);

  return (
    <Card className="mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span className="font-medium">Filters</span>
            {activeFiltersCount > 0 && (
              <Badge variant="secondary">
                {activeFiltersCount} active
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? 'Hide' : 'Show'} Filters
            </Button>
            {activeFiltersCount > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={onClearFilters}
              >
                <X className="h-4 w-4 mr-1" />
                Clear All
              </Button>
            )}
          </div>
        </div>

        {isExpanded && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filterOptions.map((option) => (
              <div key={option.key} className="space-y-2">
                <label className="text-sm font-medium">{option.label}</label>
                {option.type === 'search' && (
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder={option.placeholder || `Search ${option.label.toLowerCase()}...`}
                      value={filters[option.key] || ''}
                      onChange={(e) => onFilterChange(option.key, e.target.value)}
                      className="pl-9"
                    />
                  </div>
                )}
                {option.type === 'select' && option.options && (
                  <Select
                    value={filters[option.key] || ''}
                    onValueChange={(value) => onFilterChange(option.key, value === 'all' ? '' : value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={`All ${option.label}`} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All {option.label}</SelectItem>
                      {option.options.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>
                          {opt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
                {option.type === 'date' && (
                  <Input
                    type="date"
                    value={filters[option.key] || ''}
                    onChange={(e) => onFilterChange(option.key, e.target.value)}
                  />
                )}
              </div>
            ))}
          </div>
        )}

        {/* Quick filters for common actions */}
        {!isExpanded && activeFiltersCount > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {Object.entries(filters).map(([key, value]) => {
              if (!value) return null;
              const option = filterOptions.find(opt => opt.key === key);
              if (!option) return null;
              
              let displayValue = value;
              if (option.type === 'select' && option.options) {
                const foundOption = option.options.find(opt => opt.value === value);
                displayValue = foundOption?.label || value;
              }
              
              return (
                <Badge key={key} variant="secondary" className="gap-1">
                  {option.label}: {displayValue}
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => onFilterChange(key, '')}
                  />
                </Badge>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};