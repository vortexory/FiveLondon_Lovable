import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ExternalLink, Search, Globe } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { getCharacteristicSEOPaths, generateModelMetaTags, generateBreadcrumbs, generateCharacteristicSEOUrl, generateLocationSEOUrl, type CharacteristicSEO } from '@/utils/seoUtils';

interface LocationSEO {
  name: string;
  seo_path: string | null;
  description: string | null;
}

interface Model {
  id: string;
  name: string;
  location?: string;
  description?: string;
  characteristics?: string[];
  image?: string;
  services?: string[];
  price?: string;
  availability?: string;
}

interface ModelSEOPreviewProps {
  model: Model;
}

export const ModelSEOPreview: React.FC<ModelSEOPreviewProps> = ({ model }) => {
  const [characteristicSEO, setCharacteristicSEO] = useState<CharacteristicSEO[]>([]);
  const [locationSEO, setLocationSEO] = useState<LocationSEO | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      await Promise.all([
        model.characteristics?.length ? fetchCharacteristicSEO() : Promise.resolve(),
        model.location ? fetchLocationSEO() : Promise.resolve()
      ]);
      setLoading(false);
    };
    
    fetchData();
  }, [model.characteristics, model.location]);

  const fetchCharacteristicSEO = async () => {
    try {
      const seoData = await getCharacteristicSEOPaths(model.characteristics || []);
      setCharacteristicSEO(seoData);
    } catch (error) {
      console.error('Error fetching characteristic SEO:', error);
    }
  };

  const fetchLocationSEO = async () => {
    if (!model.location) return;
    
    try {
      const { data, error } = await supabase
        .from('locations')
        .select('name, seo_path, description')
        .eq('name', model.location)
        .eq('is_active', true)
        .maybeSingle();

      if (error) throw error;
      setLocationSEO(data);
    } catch (error) {
      console.error('Error fetching location SEO:', error);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            SEO Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-3 bg-muted rounded w-full"></div>
            <div className="h-3 bg-muted rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const metaTags = generateModelMetaTags(model, characteristicSEO);
  const breadcrumbs = generateBreadcrumbs(model, characteristicSEO);
  const seoConnectedCharacteristics = characteristicSEO.filter(char => char.seo_path);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="w-5 h-5" />
          SEO Preview & Website Integration
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search Engine Preview */}
        <div className="border rounded-lg p-4 bg-white">
          <div className="text-sm text-muted-foreground mb-2">How this appears in search results:</div>
          <div className="space-y-1">
            <div className="text-blue-600 text-lg hover:underline cursor-pointer truncate">
              {metaTags.title}
            </div>
            <div className="text-green-700 text-sm truncate">
              {metaTags.canonical}
            </div>
            <div className="text-gray-700 text-sm line-clamp-2">
              {metaTags.description}
            </div>
          </div>
        </div>

        {/* Connected SEO Pages */}
        {(seoConnectedCharacteristics.length > 0 || locationSEO?.seo_path) && (
          <div>
            <div className="text-sm font-medium mb-2 flex items-center gap-2">
              <Globe className="w-4 h-4 text-green-600" />
              Connected SEO Pages ({seoConnectedCharacteristics.length + (locationSEO?.seo_path ? 1 : 0)})
            </div>
            <div className="grid gap-2">
              {seoConnectedCharacteristics.map((char) => (
                <div key={char.name} className="flex items-center justify-between p-2 bg-green-50 rounded border border-green-200">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-green-700 border-green-300">
                      {char.name}
                    </Badge>
                    <span className="text-sm text-green-700 capitalize">({char.category})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <a 
                      href={char.seo_path ? generateCharacteristicSEOUrl(char.seo_path) : '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-green-600 font-mono hover:text-green-800 underline"
                    >
                      {char.seo_path}
                    </a>
                    <a 
                      href={char.seo_path ? generateCharacteristicSEOUrl(char.seo_path) : '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                        <ExternalLink className="w-3 h-3 text-green-600" />
                      </Button>
                    </a>
                  </div>
                </div>
              ))}
              {locationSEO?.seo_path && (
                <div className="flex items-center justify-between p-2 bg-blue-50 rounded border border-blue-200">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-blue-700 border-blue-300">
                      📍 {locationSEO.name}
                    </Badge>
                    <span className="text-sm text-blue-700">Location Page</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <a 
                      href={locationSEO.seo_path ? generateLocationSEOUrl(locationSEO.seo_path) : '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-blue-600 font-mono hover:text-blue-800 underline"
                    >
                      {locationSEO.seo_path}
                    </a>
                    <a 
                      href={locationSEO.seo_path ? generateLocationSEOUrl(locationSEO.seo_path) : '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                        <ExternalLink className="w-3 h-3 text-blue-600" />
                      </Button>
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Breadcrumb Preview */}
        <div>
          <div className="text-sm font-medium mb-2">Navigation Breadcrumbs</div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            {breadcrumbs.map((crumb, index) => (
              <React.Fragment key={index}>
                {index > 0 && <span>›</span>}
                <span className={index === breadcrumbs.length - 1 ? 'text-foreground font-medium' : 'hover:text-blue-600 cursor-pointer'}>
                  {crumb.name}
                </span>
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* SEO Benefits */}
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="text-sm font-medium text-blue-900 mb-2">SEO Benefits</div>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Model profile automatically appears on {seoConnectedCharacteristics.length + (locationSEO?.seo_path ? 1 : 0)} SEO pages</li>
            <li>• Improved search engine visibility for specific characteristics</li>
            <li>• Better internal linking structure across your website</li>
            <li>• Automatic schema.org structured data for better rich snippets</li>
            <li>• Cross-linking between related characteristics and models</li>
          </ul>
        </div>

        {/* Meta Tags Details */}
        <details className="group">
          <summary className="cursor-pointer text-sm font-medium text-muted-foreground hover:text-foreground">
            View Meta Tags & Technical SEO
          </summary>
          <div className="mt-2 space-y-2 text-xs font-mono bg-gray-50 p-3 rounded">
            <div><strong>Title:</strong> {metaTags.title}</div>
            <div><strong>Description:</strong> {metaTags.description}</div>
            <div><strong>Keywords:</strong> {metaTags.keywords}</div>
            <div><strong>Canonical:</strong> {metaTags.canonical}</div>
          </div>
        </details>
      </CardContent>
    </Card>
  );
};