import React, { useState } from 'react';
import { Upload, X, Image as ImageIcon, Globe, Users, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface ImageUploadProps {
  bucket: string;
  value?: string;
  onChange: (url: string, audience?: 'public' | 'members_only') => void;
  label?: string;
  accept?: string;
  modelVisibilityType?: 'public' | 'members_only' | 'mixed';
  showAudienceSelector?: boolean;
  folder?: string;
}

export const ImageUpload: React.FC<ImageUploadProps> = ({
  bucket,
  value,
  onChange,
  label = 'Image',
  accept = 'image/*',
  modelVisibilityType = 'public',
  showAudienceSelector = false,
  folder
}) => {
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(value || null);
  const [faceVisible, setFaceVisible] = useState(false);
  const [selectedAudience, setSelectedAudience] = useState<'public' | 'members_only'>('public');

  // Update preview when value changes from parent
  React.useEffect(() => {
    setPreview(value || null);
  }, [value]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log('ImageUpload: handleFileUpload started');
    const file = event.target.files?.[0];
    if (!file) {
      console.log('ImageUpload: No file selected');
      return;
    }

    console.log('ImageUpload: File selected:', file.name, file.size, file.type);

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      console.log('ImageUpload: File too large');
      toast.error('File size must be less than 10MB');
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      console.log('ImageUpload: Invalid file type');
      toast.error('Please upload a valid image file');
      return;
    }

    console.log('ImageUpload: Starting upload process');
    setUploading(true);

    try {
      // Check if user is authenticated
      console.log('ImageUpload: Checking authentication');
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('ImageUpload: User not authenticated');
        toast.error('You must be logged in to upload images');
        return;
      }
      console.log('ImageUpload: User authenticated:', user.id);

      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = folder ? `${folder}/${fileName}` : fileName;

      console.log('ImageUpload: Uploading to:', bucket, filePath);

      const { error: uploadError } = await supabase.storage
        .from(bucket)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('ImageUpload: Upload error:', uploadError);
        let errorMessage = 'Upload failed';
        
        if (uploadError.message.includes('row-level security policy')) {
          errorMessage = 'Permission denied. Please make sure you are logged in with the correct permissions.';
        } else if (uploadError.message.includes('The resource already exists')) {
          errorMessage = 'A file with this name already exists. Please try again.';
        } else if (uploadError.message.includes('413')) {
          errorMessage = 'File is too large. Please use a smaller image (max 10MB).';
        } else {
          errorMessage = `Upload failed: ${uploadError.message}`;
        }
        
        toast.error(errorMessage);
        return;
      }

      console.log('ImageUpload: Upload successful');

      const { data: { publicUrl } } = supabase.storage
        .from(bucket)
        .getPublicUrl(filePath);

      console.log('ImageUpload: Public URL:', publicUrl);

      setPreview(publicUrl);
      
      // For mixed models, determine audience based on face visibility
      let audience: 'public' | 'members_only' = selectedAudience;
      if (showAudienceSelector && modelVisibilityType === 'mixed') {
        audience = faceVisible ? 'members_only' : 'public';
      }
      
      console.log('ImageUpload: Calling onChange with:', publicUrl, audience);
      onChange(publicUrl, audience);
      toast.success('Image uploaded successfully');
      
      // Reset the file input
      event.target.value = '';
    } catch (error: any) {
      console.error('ImageUpload: Upload error:', error);
      toast.error(`Failed to upload image: ${error.message || 'Unknown error'}`);
    } finally {
      console.log('ImageUpload: Upload process finished');
      setUploading(false);
    }
  };

  const handleFaceVisibilityChange = (checked: boolean) => {
    setFaceVisible(checked);
    // Auto-set audience based on face visibility
    const newAudience = checked ? 'members_only' : 'public';
    setSelectedAudience(newAudience);
  };

  const handleAudienceChange = (audience: 'public' | 'members_only') => {
    setSelectedAudience(audience);
    // Update face visibility based on audience (reverse mapping)
    setFaceVisible(audience === 'members_only');
  };

  const handleRemove = () => {
    setPreview(null);
    onChange('');
  };

  return (
    <div className="space-y-4">
      {label && <Label className="text-base font-medium">{label}</Label>}
      
      {/* Face Visibility & Audience Selector for Mixed Models */}
      {showAudienceSelector && modelVisibilityType === 'mixed' && (
        <Card>
          <CardContent className="p-4 space-y-4">
            <div>
              <Label className="text-sm font-medium mb-3 block">Photo Settings</Label>
              
              <div className="flex items-center space-x-2 mb-4">
                <Checkbox
                  id="face-visible"
                  checked={faceVisible}
                  onCheckedChange={handleFaceVisibilityChange}
                />
                <Label htmlFor="face-visible" className="text-sm cursor-pointer flex items-center gap-2">
                  {faceVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  Face is visible in this photo
                </Label>
              </div>

              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Audience (based on face visibility)</Label>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant={selectedAudience === 'public' ? 'default' : 'outline'}
                    onClick={() => handleAudienceChange('public')}
                    className="flex-1"
                  >
                    <Globe className="w-4 h-4 mr-2" />
                    Public
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={selectedAudience === 'members_only' ? 'default' : 'outline'}
                    onClick={() => handleAudienceChange('members_only')}
                    className="flex-1"
                  >
                    <Users className="w-4 h-4 mr-2" />
                    Members Only
                  </Button>
                </div>
              </div>

              <div className="bg-muted/50 p-3 rounded-md">
                <p className="text-xs text-muted-foreground">
                  <strong>Default:</strong> Face visible photos → Members Only, Face not visible → Public
                  <br />
                  You can override this by selecting the audience manually.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {preview ? (
        <div className="relative w-full">
          <div className="w-full h-48 overflow-hidden rounded-md border bg-muted flex-shrink-0">
            <img 
              src={preview} 
              alt="Preview" 
              className="w-full h-full object-cover"
            />
          </div>
          <Button
            type="button"
            variant="destructive"
            size="sm"
            className="absolute top-2 right-2 z-10"
            onClick={handleRemove}
            disabled={uploading}
          >
            <X className="h-4 w-4" />
          </Button>
          
          {/* Show audience badge on preview for mixed models */}
          {showAudienceSelector && modelVisibilityType === 'mixed' && (
            <div className="absolute bottom-2 left-2 z-10">
              <Badge 
                variant={selectedAudience === 'public' ? 'default' : 'secondary'}
                className="text-xs"
              >
                {selectedAudience === 'public' ? (
                  <><Globe className="w-3 h-3 mr-1" />Public</>
                ) : (
                  <><Users className="w-3 h-3 mr-1" />Members Only</>
                )}
              </Badge>
            </div>
          )}
          
          {/* Upload progress overlay */}
          {uploading && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center rounded-md z-20">
              <div className="text-white text-sm font-medium">Uploading...</div>
            </div>
          )}
        </div>
      ) : (
        <div className="border-2 border-dashed border-muted-foreground/25 rounded-md p-6">
          <div className="text-center">
            <ImageIcon className="mx-auto h-12 w-12 text-muted-foreground" />
            <div className="mt-4">
              <Label htmlFor={`file-upload-${bucket}`} className="cursor-pointer">
                <div className="flex items-center justify-center">
                  <Upload className="h-4 w-4 mr-2" />
                  {uploading ? 'Uploading...' : 'Upload Image'}
                </div>
              </Label>
              <Input
                id={`file-upload-${bucket}`}
                type="file"
                accept={accept}
                onChange={handleFileUpload}
                disabled={uploading}
                className="sr-only"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              PNG, JPG, WEBP up to 10MB
            </p>
          </div>
        </div>
      )}

      {/* Audience Preview for Mixed Models */}
      {showAudienceSelector && modelVisibilityType === 'mixed' && !preview && (
        <div className="bg-muted/30 p-3 rounded-md border">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Selected audience:</span>
            <Badge 
              variant={selectedAudience === 'public' ? 'default' : 'secondary'}
              className="text-xs"
            >
              {selectedAudience === 'public' ? (
                <><Globe className="w-3 h-3 mr-1" />Public</>
              ) : (
                <><Users className="w-3 h-3 mr-1" />Members Only</>
              )}
            </Badge>
          </div>
        </div>
      )}
    </div>
  );
};