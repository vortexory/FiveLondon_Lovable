import React, { useState } from 'react';
import { Upload, X, Image as ImageIcon, Globe, Users, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface UploadedImage {
  id: string;
  url: string;
  audience: 'public' | 'members_only';
  faceVisible: boolean;
}

interface MultiImageUploadProps {
  bucket: string;
  images: UploadedImage[];
  onChange: (images: UploadedImage[]) => void;
  label?: string;
  modelVisibilityType?: 'public' | 'members_only' | 'mixed';
  maxImages?: number;
}

export const MultiImageUpload: React.FC<MultiImageUploadProps> = ({
  bucket,
  images,
  onChange,
  label = 'Images',
  modelVisibilityType = 'public',
  maxImages = 10
}) => {
  const [uploading, setUploading] = useState(false);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log('MultiImageUpload: handleFileUpload started');
    const files = Array.from(event.target.files || []);
    if (!files.length) {
      console.log('MultiImageUpload: No files selected');
      return;
    }

    if (images.length + files.length > maxImages) {
      console.log('MultiImageUpload: Too many images');
      toast.error(`Maximum ${maxImages} images allowed`);
      return;
    }

    console.log('MultiImageUpload: Processing', files.length, 'files');
    setUploading(true);

    try {
      // Check if user is authenticated
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('You must be logged in to upload images');
        return;
      }

      const uploadPromises = files.map(async (file) => {
        // Validate file size (max 10MB)
        if (file.size > 10 * 1024 * 1024) {
          throw new Error(`File ${file.name} is too large (max 10MB)`);
        }

        // Validate file type
        if (!file.type.startsWith('image/')) {
          throw new Error(`${file.name} is not a valid image file`);
        }

        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = fileName;

        const { error: uploadError } = await supabase.storage
          .from(bucket)
          .upload(filePath, file, {
            cacheControl: '3600',
            upsert: false
          });

        if (uploadError) {
          let errorMessage = `Upload failed for ${file.name}`;
          
          if (uploadError.message.includes('row-level security policy')) {
            errorMessage = 'Permission denied. Please make sure you are logged in with the correct permissions.';
          } else if (uploadError.message.includes('The resource already exists')) {
            errorMessage = `File ${file.name} already exists. Please rename and try again.`;
          } else if (uploadError.message.includes('413')) {
            errorMessage = `File ${file.name} is too large (max 10MB).`;
          } else {
            errorMessage = `Upload failed for ${file.name}: ${uploadError.message}`;
          }
          
          throw new Error(errorMessage);
        }

        const { data: { publicUrl } } = supabase.storage
          .from(bucket)
          .getPublicUrl(filePath);

        // Default audience based on model visibility type
        let defaultAudience: 'public' | 'members_only';
        if (modelVisibilityType === 'public') {
          defaultAudience = 'public';
        } else if (modelVisibilityType === 'members_only') {
          defaultAudience = 'members_only';
        } else {
          // For mixed, default to public (can be changed later)
          defaultAudience = 'public';
        }

        return {
          id: `${Date.now()}-${Math.random()}`,
          url: publicUrl,
          audience: defaultAudience,
          faceVisible: false
        };
      });

      const uploadedImages = await Promise.all(uploadPromises);
      console.log('MultiImageUpload: All uploads completed:', uploadedImages.length);
      onChange([...images, ...uploadedImages]);
      toast.success(`${uploadedImages.length} image(s) uploaded successfully`);
    } catch (error: any) {
      console.error('MultiImageUpload: Upload error:', error);
      toast.error(error.message || 'Failed to upload images');
    } finally {
      console.log('MultiImageUpload: Upload process finished');
      setUploading(false);
      // Reset file input
      event.target.value = '';
    }
  };

  const handleRemoveImage = (imageId: string) => {
    onChange(images.filter(img => img.id !== imageId));
  };

  const handleUpdateImage = (imageId: string, updates: Partial<UploadedImage>) => {
    onChange(images.map(img => 
      img.id === imageId ? { ...img, ...updates } : img
    ));
  };

  const handleFaceVisibilityChange = (imageId: string, faceVisible: boolean) => {
    const audience = faceVisible ? 'members_only' : 'public';
    handleUpdateImage(imageId, { faceVisible, audience });
  };

  return (
    <div className="space-y-4">
      {label && <Label className="text-base font-medium">{label}</Label>}
      
      {/* Upload Area */}
      {images.length < maxImages && (
        <div className="border-2 border-dashed border-muted-foreground/25 rounded-md p-6">
          <div className="text-center">
            <ImageIcon className="mx-auto h-12 w-12 text-muted-foreground" />
            <div className="mt-4">
              <Label htmlFor={`multi-file-upload-${bucket}`} className="cursor-pointer">
                <div className="flex items-center justify-center">
                  <Upload className="h-4 w-4 mr-2" />
                  {uploading ? 'Uploading...' : 'Upload Images'}
                </div>
              </Label>
              <Input
                id={`multi-file-upload-${bucket}`}
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileUpload}
                disabled={uploading}
                className="sr-only"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              PNG, JPG, WEBP up to 10MB each • {images.length}/{maxImages} images
            </p>
          </div>
        </div>
      )}

        {/* Uploaded Images Grid */}
        {images.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {images.map((image, index) => (
              <Card key={image.id} className="flex-shrink-0">
                <div className="relative">
                  <div className="w-full h-24 overflow-hidden rounded-t-md bg-muted flex-shrink-0">
                    <img
                      src={image.url}
                      alt={`Upload ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  className="absolute top-2 right-2"
                  onClick={() => handleRemoveImage(image.id)}
                >
                  <X className="h-3 w-3" />
                </Button>
                
                {/* Audience Badge */}
                <div className="absolute bottom-2 right-2">
                  <Badge 
                    variant={image.audience === 'public' ? 'default' : 'secondary'}
                    className="text-xs"
                  >
                    {image.audience === 'public' ? (
                      <><Globe className="w-3 h-3 mr-1" />Public</>
                    ) : (
                      <><Users className="w-3 h-3 mr-1" />Members</>
                    )}
                  </Badge>
                </div>

                {/* Order Number */}
                <div className="absolute top-2 left-2">
                  <Badge variant="outline" className="text-xs bg-white/90">
                    #{index + 1}
                  </Badge>
                </div>
              </div>

              {/* Controls for Mixed Models */}
              {modelVisibilityType === 'mixed' && (
                <CardContent className="p-3 space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id={`face-visible-${image.id}`}
                      checked={image.faceVisible}
                      onCheckedChange={(checked) => 
                        handleFaceVisibilityChange(image.id, checked as boolean)
                      }
                    />
                    <Label 
                      htmlFor={`face-visible-${image.id}`} 
                      className="text-xs cursor-pointer flex items-center gap-1"
                    >
                      {image.faceVisible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      Face visible
                    </Label>
                  </div>

                  <div className="flex gap-1">
                    <Button
                      type="button"
                      size="sm"
                      variant={image.audience === 'public' ? 'default' : 'outline'}
                      onClick={() => handleUpdateImage(image.id, { 
                        audience: 'public', 
                        faceVisible: false 
                      })}
                      className="flex-1 text-xs"
                    >
                      <Globe className="w-3 h-3 mr-1" />
                      Public
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant={image.audience === 'members_only' ? 'default' : 'outline'}
                      onClick={() => handleUpdateImage(image.id, { 
                        audience: 'members_only', 
                        faceVisible: true 
                      })}
                      className="flex-1 text-xs"
                    >
                      <Users className="w-3 h-3 mr-1" />
                      Members
                    </Button>
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}

      {/* Summary for Mixed Models */}
      {modelVisibilityType === 'mixed' && images.length > 0 && (
        <div className="bg-muted/30 p-3 rounded-md border">
          <div className="text-sm space-y-1">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Public photos:</span>
              <span className="font-medium">
                {images.filter(img => img.audience === 'public').length}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Members only photos:</span>
              <span className="font-medium">
                {images.filter(img => img.audience === 'members_only').length}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};