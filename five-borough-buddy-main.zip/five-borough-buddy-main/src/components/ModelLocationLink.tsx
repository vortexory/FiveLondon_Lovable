import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { ExternalLink, MapPin } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { generateLocationSEOUrl } from '@/utils/seoUtils';

interface LocationSEO {
  name: string;
  seo_path: string | null;
  description: string | null;
}

interface ModelLocationLinkProps {
  location: string;
  className?: string;
  showIcon?: boolean;
  showDescription?: boolean;
}

export const ModelLocationLink: React.FC<ModelLocationLinkProps> = ({
  location,
  className = "",
  showIcon = true,
  showDescription = false
}) => {
  const [locationData, setLocationData] = useState<LocationSEO | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (location) {
      fetchLocationData();
    } else {
      setLoading(false);
    }
  }, [location]);

  const fetchLocationData = async () => {
    try {
      const { data, error } = await supabase
        .from('locations')
        .select('name, seo_path, description')
        .eq('name', location)
        .eq('is_active', true)
        .maybeSingle();

      if (error) throw error;
      setLocationData(data);
    } catch (error) {
      console.error('Error fetching location data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        {showIcon && <MapPin className="h-4 w-4 animate-pulse" />}
        <span className="text-sm text-muted-foreground">Loading location...</span>
      </div>
    );
  }

  if (!location) {
    return null;
  }

  // If location has SEO path, render as link
  if (locationData?.seo_path) {
    const seoUrl = generateLocationSEOUrl(locationData.seo_path);
    
    return (
      <div className={`flex flex-col gap-1 ${className}`}>
        <div className="flex items-center gap-2">
          {showIcon && <MapPin className="h-4 w-4 text-primary" />}
          <a 
            href={seoUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-primary hover:text-primary/80 transition-colors font-medium"
          >
            {locationData.name}
            <ExternalLink className="h-3 w-3" />
          </a>
          <Badge variant="secondary" className="text-xs">
            SEO Connected
          </Badge>
        </div>
        {showDescription && locationData.description && (
          <p className="text-sm text-muted-foreground ml-6">
            {locationData.description}
          </p>
        )}
      </div>
    );
  }

  // Fallback: render as plain text if no SEO connection
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {showIcon && <MapPin className="h-4 w-4 text-muted-foreground" />}
      <span className="text-sm text-muted-foreground">{location}</span>
      <Badge variant="outline" className="text-xs">
        Not SEO Connected
      </Badge>
    </div>
  );
};