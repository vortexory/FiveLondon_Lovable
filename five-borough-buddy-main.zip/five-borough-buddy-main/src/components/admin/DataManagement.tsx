import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Database, 
  Download, 
  Upload, 
  Trash2, 
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  FileText,
  Users,
  Image,
  Shield
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface BulkOperation {
  id: string;
  type: 'export' | 'import' | 'cleanup' | 'backup';
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  message: string;
  startTime?: Date;
  endTime?: Date;
}

interface DataStats {
  totalUsers: number;
  totalModels: number;
  totalApplications: number;
  totalBlogs: number;
  storageUsed: number;
  orphanedFiles: number;
}

export const DataManagement: React.FC = () => {
  const [stats, setStats] = useState<DataStats>({
    totalUsers: 0,
    totalModels: 0,
    totalApplications: 0,
    totalBlogs: 0,
    storageUsed: 0,
    orphanedFiles: 0
  });
  const [operations, setOperations] = useState<BulkOperation[]>([]);
  const [selectedTables, setSelectedTables] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  const availableTables = [
    { id: 'profiles', name: 'User Profiles', icon: Users, sensitive: false },
    { id: 'models', name: 'Model Profiles', icon: Users, sensitive: true },
    { id: 'model_applications', name: 'Applications', icon: FileText, sensitive: true },
    { id: 'blog_posts', name: 'Blog Posts', icon: FileText, sensitive: false },
    { id: 'model_gallery', name: 'Model Gallery', icon: Image, sensitive: false },
    { id: 'model_reviews', name: 'Reviews', icon: FileText, sensitive: false }
  ];

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const [
        usersRes,
        modelsRes,
        applicationsRes,
        blogsRes
      ] = await Promise.allSettled([
        supabase.from('profiles').select('id'),
        supabase.from('models').select('id'),
        supabase.from('model_applications').select('id'),
        supabase.from('blog_posts').select('id')
      ]);

      setStats({
        totalUsers: usersRes.status === 'fulfilled' ? usersRes.value.data?.length || 0 : 0,
        totalModels: modelsRes.status === 'fulfilled' ? modelsRes.value.data?.length || 0 : 0,
        totalApplications: applicationsRes.status === 'fulfilled' ? applicationsRes.value.data?.length || 0 : 0,
        totalBlogs: blogsRes.status === 'fulfilled' ? blogsRes.value.data?.length || 0 : 0,
        storageUsed: 2.8, // Mock data
        orphanedFiles: 5 // Mock data
      });

    } catch (error) {
      console.error('Error loading stats:', error);
      toast.error('Failed to load data statistics');
    } finally {
      setLoading(false);
    }
  };

  const startBulkOperation = async (type: BulkOperation['type']) => {
    const operation: BulkOperation = {
      id: Date.now().toString(),
      type,
      status: 'running',
      progress: 0,
      message: `Starting ${type} operation...`,
      startTime: new Date()
    };

    setOperations(prev => [operation, ...prev]);

    // Simulate operation progress
    const interval = setInterval(() => {
      setOperations(prev => prev.map(op => {
        if (op.id === operation.id && op.status === 'running') {
          const newProgress = Math.min(op.progress + Math.random() * 15, 100);
          return {
            ...op,
            progress: newProgress,
            message: newProgress < 100 
              ? `Processing... ${Math.round(newProgress)}%`
              : 'Completing operation...'
          };
        }
        return op;
      }));
    }, 500);

    // Complete operation after random time
    setTimeout(() => {
      clearInterval(interval);
      setOperations(prev => prev.map(op => {
        if (op.id === operation.id) {
          return {
            ...op,
            status: 'completed',
            progress: 100,
            message: `${type.charAt(0).toUpperCase() + type.slice(1)} completed successfully`,
            endTime: new Date()
          };
        }
        return op;
      }));

      toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} operation completed`);
    }, 3000 + Math.random() * 2000);
  };

  const handleExport = async () => {
    if (selectedTables.length === 0) {
      toast.error('Please select at least one table to export');
      return;
    }

    startBulkOperation('export');
  };

  const handleCleanup = async () => {
    if (!confirm('Are you sure you want to perform data cleanup? This will remove orphaned files and temporary data.')) {
      return;
    }

    startBulkOperation('cleanup');
  };

  const handleBackup = async () => {
    startBulkOperation('backup');
  };

  const toggleTableSelection = (tableId: string) => {
    setSelectedTables(prev => 
      prev.includes(tableId) 
        ? prev.filter(id => id !== tableId)
        : [...prev, tableId]
    );
  };

  const getOperationIcon = (type: string) => {
    switch (type) {
      case 'export': return <Download className="h-4 w-4" />;
      case 'import': return <Upload className="h-4 w-4" />;
      case 'cleanup': return <Trash2 className="h-4 w-4" />;
      case 'backup': return <Database className="h-4 w-4" />;
      default: return <Database className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'failed': return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case 'running': return <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />;
      default: return <Database className="h-4 w-4 text-muted-foreground" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Data Management</h1>
          <p className="text-muted-foreground">
            Export, import, and manage your database records
          </p>
        </div>
        <Button onClick={loadStats} variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh Stats
        </Button>
      </div>

      {/* Data Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers}</div>
            <p className="text-xs text-muted-foreground">Total registered users</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Models</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalModels}</div>
            <p className="text-xs text-muted-foreground">Active model profiles</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Applications</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalApplications}</div>
            <p className="text-xs text-muted-foreground">Model applications</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Storage</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.storageUsed}GB</div>
            <p className="text-xs text-muted-foreground">
              {stats.orphanedFiles} orphaned files
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Bulk Operations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Export Data</CardTitle>
            <CardDescription>
              Select tables to export as CSV files
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              {availableTables.map((table) => (
                <div key={table.id} className="flex items-center space-x-3">
                  <Checkbox
                    id={table.id}
                    checked={selectedTables.includes(table.id)}
                    onCheckedChange={() => toggleTableSelection(table.id)}
                  />
                  <div className="flex items-center gap-2 flex-1">
                    <table.icon className="h-4 w-4 text-muted-foreground" />
                    <label 
                      htmlFor={table.id} 
                      className="text-sm font-medium cursor-pointer flex-1"
                    >
                      {table.name}
                    </label>
                    {table.sensitive && (
                      <Shield className="h-3 w-3 text-yellow-600" />
                    )}
                  </div>
                </div>
              ))}
            </div>

            {selectedTables.length > 0 && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  {selectedTables.some(id => availableTables.find(t => t.id === id)?.sensitive) 
                    ? 'Warning: Some selected tables contain sensitive data. Ensure exported files are handled securely.'
                    : `${selectedTables.length} table(s) selected for export.`
                  }
                </AlertDescription>
              </Alert>
            )}

            <Button 
              onClick={handleExport} 
              disabled={selectedTables.length === 0}
              className="w-full"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Selected Tables
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">System Maintenance</CardTitle>
            <CardDescription>
              Database cleanup and backup operations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">Database Backup</p>
                  <p className="text-xs text-muted-foreground">Create full database backup</p>
                </div>
                <Button size="sm" onClick={handleBackup}>
                  <Database className="h-4 w-4 mr-2" />
                  Backup
                </Button>
              </div>

              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">Data Cleanup</p>
                  <p className="text-xs text-muted-foreground">Remove orphaned files and temp data</p>
                </div>
                <Button size="sm" variant="outline" onClick={handleCleanup}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Cleanup
                </Button>
              </div>
            </div>

            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Maintenance operations may temporarily affect system performance.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>

      {/* Operation History */}
      {operations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent Operations</CardTitle>
            <CardDescription>Status of bulk operations and data management tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {operations.map((operation) => (
                <div key={operation.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getOperationIcon(operation.type)}
                      <span className="font-medium capitalize">{operation.type}</span>
                      {getStatusIcon(operation.status)}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {operation.startTime?.toLocaleTimeString()}
                    </span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-2">{operation.message}</p>
                  
                  {operation.status === 'running' && (
                    <Progress value={operation.progress} className="w-full" />
                  )}
                  
                  {operation.endTime && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Completed in {Math.round((operation.endTime.getTime() - operation.startTime!.getTime()) / 1000)}s
                    </p>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};