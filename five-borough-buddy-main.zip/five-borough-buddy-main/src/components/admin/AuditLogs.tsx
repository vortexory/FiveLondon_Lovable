import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Search, 
  Filter, 
  Download, 
  RefreshCw,
  User,
  Shield,
  Database,
  Settings,
  Clock,
  Eye
} from 'lucide-react';
import { toast } from 'sonner';

interface AuditLog {
  id: string;
  action: string;
  user_id: string;
  user_email?: string;
  table_name?: string;
  record_id?: string;
  old_values?: any;
  new_values?: any;
  ip_address?: string;
  user_agent?: string;
  timestamp: Date;
  risk_level: 'low' | 'medium' | 'high' | 'critical';
}

interface LogFilters {
  search: string;
  action: string;
  riskLevel: string;
  dateRange: string;
  user: string;
}

export const AuditLogs: React.FC = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filters, setFilters] = useState<LogFilters>({
    search: '',
    action: 'all',
    riskLevel: 'all',
    dateRange: 'today',
    user: 'all'
  });

  useEffect(() => {
    loadAuditLogs();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [logs, filters]);

  const loadAuditLogs = async () => {
    try {
      // Generate mock audit logs (in real app, query from audit_log table)
      const mockLogs: AuditLog[] = [
        {
          id: '1',
          action: 'login_success',
          user_id: 'admin-1',
          user_email: 'admin@fivelondon.com',
          timestamp: new Date(Date.now() - 5 * 60 * 1000),
          risk_level: 'low',
          ip_address: '192.168.1.100'
        },
        {
          id: '2',
          action: 'user_role_updated',
          user_id: 'admin-1',
          user_email: 'admin@fivelondon.com',
          table_name: 'profiles',
          record_id: 'user-123',
          old_values: { role: 'user' },
          new_values: { role: 'admin' },
          timestamp: new Date(Date.now() - 15 * 60 * 1000),
          risk_level: 'high',
          ip_address: '192.168.1.100'
        },
        {
          id: '3',
          action: 'model_deleted',
          user_id: 'admin-1',
          user_email: 'admin@fivelondon.com',
          table_name: 'models',
          record_id: 'model-456',
          old_values: { name: 'Test Model', status: 'active' },
          timestamp: new Date(Date.now() - 30 * 60 * 1000),
          risk_level: 'medium',
          ip_address: '192.168.1.100'
        },
        {
          id: '4',
          action: 'login_failed',
          user_id: 'unknown',
          user_email: 'hacker@example.com',
          timestamp: new Date(Date.now() - 45 * 60 * 1000),
          risk_level: 'critical',
          ip_address: '10.0.0.1'
        },
        {
          id: '5',
          action: 'blog_post_published',
          user_id: 'admin-1',
          user_email: 'admin@fivelondon.com',
          table_name: 'blog_posts',
          record_id: 'blog-789',
          new_values: { is_published: true, title: 'New Blog Post' },
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
          risk_level: 'low',
          ip_address: '192.168.1.100'
        },
        {
          id: '6',
          action: 'sensitive_data_accessed',
          user_id: 'admin-1',
          user_email: 'admin@fivelondon.com',
          table_name: 'model_applications',
          record_id: 'app-321',
          timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
          risk_level: 'high',
          ip_address: '192.168.1.100'
        }
      ];

      setLogs(mockLogs);

    } catch (error) {
      console.error('Error loading audit logs:', error);
      toast.error('Failed to load audit logs');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...logs];

    // Search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter(log => 
        log.action.toLowerCase().includes(searchLower) ||
        log.user_email?.toLowerCase().includes(searchLower) ||
        log.table_name?.toLowerCase().includes(searchLower)
      );
    }

    // Action filter
    if (filters.action !== 'all') {
      filtered = filtered.filter(log => log.action.includes(filters.action));
    }

    // Risk level filter
    if (filters.riskLevel !== 'all') {
      filtered = filtered.filter(log => log.risk_level === filters.riskLevel);
    }

    // Date range filter
    const now = new Date();
    switch (filters.dateRange) {
      case 'today':
        filtered = filtered.filter(log => {
          const logDate = new Date(log.timestamp);
          return logDate.toDateString() === now.toDateString();
        });
        break;
      case 'week':
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        filtered = filtered.filter(log => new Date(log.timestamp) >= weekAgo);
        break;
      case 'month':
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        filtered = filtered.filter(log => new Date(log.timestamp) >= monthAgo);
        break;
    }

    setFilteredLogs(filtered);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadAuditLogs();
  };

  const exportLogs = () => {
    const csvData = filteredLogs.map(log => ({
      timestamp: log.timestamp.toISOString(),
      action: log.action,
      user: log.user_email || log.user_id,
      table: log.table_name || '',
      risk_level: log.risk_level,
      ip_address: log.ip_address || ''
    }));

    const csv = [
      Object.keys(csvData[0]).join(','),
      ...csvData.map(row => Object.values(row).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-logs-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Audit logs exported successfully');
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'low': return 'default';
      case 'medium': return 'secondary';
      case 'high': return 'destructive';
      case 'critical': return 'destructive';
      default: return 'default';
    }
  };

  const getActionIcon = (action: string) => {
    if (action.includes('login')) return <User className="h-4 w-4" />;
    if (action.includes('role') || action.includes('permission')) return <Shield className="h-4 w-4" />;
    if (action.includes('data') || action.includes('delete') || action.includes('update')) return <Database className="h-4 w-4" />;
    if (action.includes('settings') || action.includes('config')) return <Settings className="h-4 w-4" />;
    return <Eye className="h-4 w-4" />;
  };

  const formatTimestamp = (timestamp: Date) => {
    const now = new Date();
    const diff = now.getTime() - timestamp.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return timestamp.toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Audit Logs</h1>
          <p className="text-muted-foreground">
            Track all system activities and security events
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={exportLogs}
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filters</CardTitle>
          <CardDescription>Filter and search audit logs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                className="pl-10"
              />
            </div>

            <Select value={filters.action} onValueChange={(value) => setFilters({ ...filters, action: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Action type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All actions</SelectItem>
                <SelectItem value="login">Login events</SelectItem>
                <SelectItem value="role">Role changes</SelectItem>
                <SelectItem value="data">Data access</SelectItem>
                <SelectItem value="delete">Deletions</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.riskLevel} onValueChange={(value) => setFilters({ ...filters, riskLevel: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Risk level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All levels</SelectItem>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.dateRange} onValueChange={(value) => setFilters({ ...filters, dateRange: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Date range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This week</SelectItem>
                <SelectItem value="month">This month</SelectItem>
                <SelectItem value="all">All time</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                {filteredLogs.length} of {logs.length} logs
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Logs */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recent Activities</CardTitle>
          <CardDescription>Latest security and system events</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredLogs.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No logs match your current filters</p>
              </div>
            ) : (
              filteredLogs.map((log) => (
                <div key={log.id} className="flex items-start gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex-shrink-0 mt-1">
                    {getActionIcon(log.action)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-medium">
                        {log.action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </h4>
                      <div className="flex items-center gap-2">
                        <Badge variant={getRiskLevelColor(log.risk_level)}>
                          {log.risk_level}
                        </Badge>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {formatTimestamp(log.timestamp)}
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-sm text-muted-foreground space-y-1">
                      <div className="flex items-center gap-4">
                        <span>User: {log.user_email || log.user_id}</span>
                        {log.ip_address && <span>IP: {log.ip_address}</span>}
                        {log.table_name && <span>Table: {log.table_name}</span>}
                      </div>
                      
                      {(log.old_values || log.new_values) && (
                        <div className="text-xs bg-muted p-2 rounded mt-2">
                          {log.old_values && (
                            <div>
                              <span className="font-medium">Old:</span> {JSON.stringify(log.old_values)}
                            </div>
                          )}
                          {log.new_values && (
                            <div>
                              <span className="font-medium">New:</span> {JSON.stringify(log.new_values)}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};