import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { DataTable } from '@/components/DataTable';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Star,
  Plus,
  Edit,
  Trash2,
  Eye,
  EyeOff
} from 'lucide-react';

interface Review {
  id: string;
  author_name: string;
  author_initial: string;
  area_name: string;
  location_postcode: string;
  review_text: string;
  rating: number;
  service_type: string | null;
  is_featured: boolean | null;
  created_at: string | null;
}

export const ReviewsManagement: React.FC = () => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<{ [key: string]: boolean }>({});
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingReview, setEditingReview] = useState<Review | null>(null);
  const [formData, setFormData] = useState({
    author_name: '',
    author_initial: '',
    area_name: '',
    location_postcode: '',
    review_text: '',
    rating: 5,
    service_type: 'companion',
    is_featured: false
  });

  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setReviews((data || []).map(review => ({
        ...review,
        service_type: review.service_type ?? 'companion',
        is_featured: review.is_featured ?? false,
        created_at: review.created_at ?? new Date().toISOString()
      })));
    } catch (error: any) {
      console.error('Error fetching reviews:', error);
      toast.error('Failed to fetch reviews');
    } finally {
      setLoading(false);
    }
  };

  const saveReview = async () => {
    if (!formData.author_name.trim() || !formData.review_text.trim()) {
      toast.error('Author name and review text are required');
      return;
    }

    setActionLoading({ save: true });

    try {
      // Generate initial from author name if not provided
      const initial = formData.author_initial.trim() || formData.author_name.charAt(0).toUpperCase();

      const reviewData = {
        ...formData,
        author_initial: initial
      };

      if (editingReview) {
        const { error } = await supabase
          .from('reviews')
          .update(reviewData)
          .eq('id', editingReview.id);
        if (error) throw error;
        toast.success('Review updated successfully');
      } else {
        const { error } = await supabase
          .from('reviews')
          .insert(reviewData);
        if (error) throw error;
        toast.success('Review created successfully');
      }

      await fetchReviews();
      closeDialog();
    } catch (error: any) {
      console.error('Error saving review:', error);
      toast.error('Failed to save review');
    } finally {
      setActionLoading({ save: false });
    }
  };

  const deleteReview = async (review: Review) => {
    if (!confirm('Are you sure you want to delete this review?')) return;

    setActionLoading({ [`delete_${review.id}`]: true });

    try {
      const { error } = await supabase
        .from('reviews')
        .delete()
        .eq('id', review.id);

      if (error) throw error;
      toast.success('Review deleted successfully');
      await fetchReviews();
    } catch (error: any) {
      console.error('Error deleting review:', error);
      toast.error('Failed to delete review');
    } finally {
      setActionLoading({ [`delete_${review.id}`]: false });
    }
  };

  const toggleFeatured = async (review: Review) => {
    setActionLoading({ [`toggle_${review.id}`]: true });

    try {
      const { error } = await supabase
        .from('reviews')
        .update({ is_featured: !review.is_featured })
        .eq('id', review.id);

      if (error) throw error;
      toast.success(`Review ${!review.is_featured ? 'featured' : 'unfeatured'} successfully`);
      await fetchReviews();
    } catch (error: any) {
      console.error('Error toggling review featured status:', error);
      toast.error('Failed to update review');
    } finally {
      setActionLoading({ [`toggle_${review.id}`]: false });
    }
  };

  const openDialog = (review?: Review) => {
    if (review) {
      setEditingReview(review);
      setFormData({
        author_name: review.author_name,
        author_initial: review.author_initial,
        area_name: review.area_name,
        location_postcode: review.location_postcode,
        review_text: review.review_text,
        rating: review.rating,
        service_type: review.service_type ?? 'companion',
        is_featured: review.is_featured ?? false
      });
    } else {
      setEditingReview(null);
      setFormData({
        author_name: '',
        author_initial: '',
        area_name: '',
        location_postcode: '',
        review_text: '',
        rating: 5,
        service_type: 'companion',
        is_featured: false
      });
    }
    setIsDialogOpen(true);
  };

  const closeDialog = () => {
    setIsDialogOpen(false);
    setEditingReview(null);
  };

  const renderRating = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {Array.from({ length: 5 }, (_, i) => (
          <Star
            key={i}
            className={`w-4 h-4 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
          />
        ))}
        <span className="ml-1 text-sm font-medium">{rating}/5</span>
      </div>
    );
  };

  const columns = [
    {
      key: 'author',
      header: 'Author',
      render: (review: Review) => (
        <div>
          <div className="font-medium">{review.author_name}</div>
          <div className="text-sm text-muted-foreground">
            {review.area_name}, {review.location_postcode}
          </div>
        </div>
      )
    },
    {
      key: 'review_text',
      header: 'Review',
      render: (review: Review) => (
        <div className="max-w-md">
          <p className="text-sm line-clamp-3" title={review.review_text}>
            {review.review_text}
          </p>
        </div>
      )
    },
    {
      key: 'rating',
      header: 'Rating',
      render: (review: Review) => renderRating(review.rating)
    },
    {
      key: 'service_type',
      header: 'Service Type',
      render: (review: Review) => (
        <Badge variant="outline">
          {review.service_type}
        </Badge>
      )
    },
    {
      key: 'featured',
      header: 'Featured',
      render: (review: Review) => (
        <Button
          size="sm"
          variant={review.is_featured ? "default" : "secondary"}
          onClick={() => toggleFeatured(review)}
          disabled={actionLoading[`toggle_${review.id}`]}
          className="flex items-center gap-1"
        >
          {review.is_featured ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
          {review.is_featured ? 'Featured' : 'Regular'}
        </Button>
      )
    },
    {
      key: 'created_at',
      header: 'Date',
      render: (review: Review) => (
        <div className="text-sm">
          {review.created_at ? new Date(review.created_at).toLocaleDateString() : 'N/A'}
        </div>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (review: Review) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => openDialog(review)}
          >
            <Edit className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteReview(review)}
            disabled={actionLoading[`delete_${review.id}`]}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner size={32} text="Loading reviews..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5" />
            <CardTitle>Reviews Settings</CardTitle>
          </div>
          <Button onClick={() => openDialog()} className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Review
          </Button>
        </CardHeader>
        <CardContent>
          <DataTable
            data={reviews}
            columns={columns}
            emptyStateIcon={Star}
            emptyStateTitle="No reviews found"
            emptyStateDescription="Click 'Add Review' to create your first review."
            emptyStateAction="Add Review"
            onEmptyStateAction={() => openDialog()}
          />
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingReview ? 'Edit Review' : 'Create Review'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Author Name *</Label>
                <Input
                  value={formData.author_name}
                  onChange={(e) => setFormData({ ...formData, author_name: e.target.value })}
                  placeholder="Enter author's name"
                />
              </div>

              <div>
                <Label>Author Initial</Label>
                <Input
                  value={formData.author_initial}
                  onChange={(e) => setFormData({ ...formData, author_initial: e.target.value })}
                  placeholder="Auto-generated from name"
                  maxLength={3}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Area/City</Label>
                <Input
                  value={formData.area_name}
                  onChange={(e) => setFormData({ ...formData, area_name: e.target.value })}
                  placeholder="Enter area or city"
                />
              </div>

              <div>
                <Label>Postcode</Label>
                <Input
                  value={formData.location_postcode}
                  onChange={(e) => setFormData({ ...formData, location_postcode: e.target.value })}
                  placeholder="Enter postcode"
                />
              </div>
            </div>

            <div>
              <Label>Review Text *</Label>
              <Textarea
                value={formData.review_text}
                onChange={(e) => setFormData({ ...formData, review_text: e.target.value })}
                placeholder="Enter the review content"
                rows={4}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Rating (1-5)</Label>
                <select
                  value={formData.rating}
                  onChange={(e) => setFormData({ ...formData, rating: parseInt(e.target.value) })}
                  className="w-full p-2 border rounded-md"
                >
                  {[1, 2, 3, 4, 5].map(rating => (
                    <option key={rating} value={rating}>
                      {rating} Star{rating !== 1 ? 's' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label>Service Type</Label>
                <select
                  value={formData.service_type}
                  onChange={(e) => setFormData({ ...formData, service_type: e.target.value })}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="companion">Companion</option>
                  <option value="escort">Escort</option>
                  <option value="massage">Massage</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.is_featured}
                onCheckedChange={(checked) => setFormData({ ...formData, is_featured: checked })}
              />
              <Label>Featured review (displayed prominently)</Label>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={closeDialog}>
              Cancel
            </Button>
            <Button onClick={saveReview} disabled={actionLoading.save}>
              {actionLoading.save ? 'Saving...' : editingReview ? 'Update Review' : 'Create Review'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};