import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Upload, Globe, Users, Eye, Trash2, Plus } from 'lucide-react';
import { ImageUpload } from './ImageUpload';
import { ModelVisibilitySettings, type ModelVisibilityType } from './ModelVisibilitySettings';

interface ModelPhoto {
  id: string;
  image_url: string;
  visibility: 'public' | 'members_only';
  order_index: number;
  caption?: string | null;
  markedForDeletion?: boolean;
}

interface ModelGalleryManagerProps {
  modelId: string;
  modelName: string;
  initialVisibilityType?: ModelVisibilityType;
  onClose: () => void;
  onVisibilityChange?: () => void;
  mixedModeOnly?: boolean;
}

export const ModelGalleryManager: React.FC<ModelGalleryManagerProps> = ({
  modelId,
  modelName,
  initialVisibilityType = 'public',
  onClose,
  onVisibilityChange,
  mixedModeOnly = false
}) => {
  const [photos, setPhotos] = useState<ModelPhoto[]>([]);
  const [originalPhotos, setOriginalPhotos] = useState<ModelPhoto[]>([]);
  const [visibilityType, setVisibilityType] = useState<ModelVisibilityType>(initialVisibilityType);
  const [loading, setLoading] = useState(false);
  const [showAddPhoto, setShowAddPhoto] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  useEffect(() => {
    fetchPhotos();
  }, [modelId]);

  // Update visibility type when initialVisibilityType changes
  useEffect(() => {
    if (mixedModeOnly) {
      setVisibilityType('mixed');
    } else {
      setVisibilityType(initialVisibilityType);
    }
  }, [initialVisibilityType, mixedModeOnly]);

  const fetchPhotos = async () => {
    try {
      const { data } = await supabase
        .from('model_gallery')
        .select('*')
        .eq('model_id', modelId)
        .order('order_index');

      const filteredData = (data || []).map(photo => ({
        ...photo,
        visibility: (photo.visibility as 'public' | 'members_only') || 'public',
        order_index: photo.order_index || 0,
        caption: photo.caption || undefined
      }));
      setPhotos(filteredData);
      setOriginalPhotos(JSON.parse(JSON.stringify(filteredData))); // Deep copy for comparison
      setHasUnsavedChanges(false);
    } catch (error: any) {
      console.error('Error fetching photos:', error);
      toast.error('Failed to load photos');
    }
  };

  const handleVisibilityChange = async (type: ModelVisibilityType, photoVisibilities?: { [photoId: string]: 'public' | 'members_only' }) => {
    console.log('ModelGalleryManager: handleVisibilityChange called with type:', type);
    setLoading(true);

    try {
      console.log('Calling atomic sync function for visibility:', type);
      
      // Prepare photo visibilities for mixed type
      let photoVisibilitiesJson = null;
      if (type === 'mixed' && photoVisibilities) {
        photoVisibilitiesJson = photoVisibilities;
      }
      
      // Call the atomic sync function
      const { data, error } = await supabase.rpc('sync_model_photo_visibility', {
        model_id_param: modelId,
        visibility_type_param: type,
        photo_visibilities_param: photoVisibilitiesJson
      });

      if (error) {
        console.error('Database sync error:', error);
        throw error;
      }

      // Type assertion for the returned data
      const result = data as { success: boolean; error?: string; photos_updated: number; };
      
      if (!result?.success) {
        console.error('Sync function failed:', result?.error || 'Unknown error');
        throw new Error(result?.error || 'Failed to sync visibility');
      }

      console.log('Database sync successful:', result);
      
      // Update local state to match the successful database change
      setVisibilityType(type);
      
      // Refresh photos from database to ensure UI consistency
      await fetchPhotos();
      
      // After syncing, check actual photo visibility and update model status
      await updateModelStatusFromPhotos();
      
      const statusLabels = {
        'public': 'Public',
        'mixed': 'Mixed Visibility',
        'members_only': 'Members Only'
      };
      
      toast.success(`Model visibility updated to ${statusLabels[type]} and ${result.photos_updated} photos synchronized`);
      
      // Notify parent component of visibility change
      if (onVisibilityChange) {
        onVisibilityChange();
      }
      
    } catch (error: any) {
      console.error('Error updating visibility:', error);
      toast.error('Failed to update visibility settings: ' + (error.message || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const updateModelStatusFromPhotos = async () => {
    try {
      console.log('Updating model status from photos...');
      
      // Fetch all photos for this model
      const { data: allPhotos } = await supabase
        .from('model_gallery')
        .select('visibility')
        .eq('model_id', modelId);

      console.log('All photos fetched:', allPhotos);

      if (!allPhotos || allPhotos.length === 0) {
        // No photos, set to public
        const { error } = await supabase
          .from('models')
          .update({
            visibility_type: 'public',
            members_only: false,
            all_photos_public: true,
            face_visible: true
          })
          .eq('id', modelId);
          
        if (error) {
          console.error('Error updating model to public (no photos):', error);
        } else {
          console.log('Model updated to public (no photos)');
          setVisibilityType('public');
        }
        return;
      }

      // Determine visibility type based on all photos
      const publicCount = allPhotos.filter(photo => photo.visibility === 'public').length;
      const membersOnlyCount = allPhotos.filter(photo => photo.visibility === 'members_only').length;
      const totalPhotos = allPhotos.length;
      
      console.log(`Photo visibility analysis: ${publicCount} public, ${membersOnlyCount} members only, ${totalPhotos} total`);
      
      let finalVisibilityType: ModelVisibilityType;
      if (publicCount === totalPhotos && totalPhotos > 0) {
        finalVisibilityType = 'public';
      } else if (membersOnlyCount === totalPhotos && totalPhotos > 0) {
        finalVisibilityType = 'members_only';
      } else {
        finalVisibilityType = 'mixed';
      }

      console.log(`Determined final visibility type: ${finalVisibilityType} (current: ${visibilityType})`);

      // Always update the model, even if the type seems the same (to ensure consistency)
      const { error } = await supabase
        .from('models')
        .update({
          visibility_type: finalVisibilityType,
          members_only: finalVisibilityType === 'members_only',
          all_photos_public: finalVisibilityType === 'public',
          face_visible: finalVisibilityType !== 'mixed'
        })
        .eq('id', modelId);

      if (error) {
        console.error('Error updating model visibility from photos:', error);
      } else {
        console.log(`Model status updated to: ${finalVisibilityType} based on ${totalPhotos} photos (${publicCount} public, ${membersOnlyCount} members only)`);
        
        // Update local state immediately
        setVisibilityType(finalVisibilityType);
        
        // Show notification if the status changed
        if (finalVisibilityType !== visibilityType) {
          const statusLabels = {
            'public': 'Public',
            'mixed': 'Mixed Visibility', 
            'members_only': 'Members Only'
          };
          
          toast.success(`Model automatically updated to ${statusLabels[finalVisibilityType]} based on photo visibility`);
        }
        
        // Notify parent component
        if (onVisibilityChange) {
          onVisibilityChange();
        }
      }
      
    } catch (error) {
      console.error('Error updating model status from photos:', error);
    }
  };

  const handleAddPhoto = async (imageUrl: string, audience?: 'public' | 'members_only') => {
    try {
      setLoading(true);
      
      const maxOrder = Math.max(...photos.map(p => p.order_index), -1);
      
      // For mixed models, use the specified audience, otherwise use default based on visibility type
      let photoVisibility: 'public' | 'members_only';
      if (visibilityType === 'mixed' && audience) {
        photoVisibility = audience;
      } else {
        photoVisibility = visibilityType === 'public' ? 'public' : 'members_only';
      }

      const { error } = await supabase
        .from('model_gallery')
        .insert({
          model_id: modelId,
          image_url: imageUrl,
          visibility: photoVisibility,
          order_index: maxOrder + 1,
          caption: ''
        });

      if (error) throw error;
      
      await fetchPhotos();
      setShowAddPhoto(false);
      toast.success(`Photo added successfully${visibilityType === 'mixed' ? ` (${photoVisibility === 'public' ? 'Public' : 'Members Only'})` : ''}`);
    } catch (error: any) {
      console.error('Error adding photo:', error);
      toast.error('Failed to add photo');
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePhoto = (photoId: string) => {
    if (!confirm('Are you sure you want to delete this photo?')) return;

    console.log(`Marking photo ${photoId} for deletion (local only)`);
    
    // Mark photo for deletion locally without removing from database
    setPhotos(prevPhotos => 
      prevPhotos.map(photo => 
        photo.id === photoId 
          ? { ...photo, markedForDeletion: true }
          : photo
      )
    );
    
    setHasUnsavedChanges(true);
    toast.success('Photo marked for deletion (not saved yet)');
  };

  const handleApplyChanges = async () => {
    if (!hasUnsavedChanges) {
      toast.info('No changes to apply');
      return;
    }

    setLoading(true);
    
    try {
      console.log('Applying changes to database...');
      
      // Handle photo deletions
      const photosToDelete = photos.filter(photo => photo.markedForDeletion);
      if (photosToDelete.length > 0) {
        const deleteIds = photosToDelete.map(photo => photo.id);
        const { error: deleteError } = await supabase
          .from('model_gallery')
          .delete()
          .in('id', deleteIds);
          
        if (deleteError) throw deleteError;
        console.log(`Deleted ${photosToDelete.length} photos`);
      }
      
      // Handle photo visibility updates
      const photosToUpdate = photos.filter(photo => !photo.markedForDeletion);
      const changedPhotos = photosToUpdate.filter(photo => {
        const originalPhoto = originalPhotos.find(orig => orig.id === photo.id);
        return originalPhoto && originalPhoto.visibility !== photo.visibility;
      });
      
      if (changedPhotos.length > 0) {
        for (const photo of changedPhotos) {
          const { error: updateError } = await supabase
            .from('model_gallery')
            .update({ visibility: photo.visibility })
            .eq('id', photo.id);
            
          if (updateError) throw updateError;
        }
        console.log(`Updated visibility for ${changedPhotos.length} photos`);
      }
      
      // Refresh photos from database
      await fetchPhotos();
      
      // Update model status based on all photos
      await updateModelStatusFromPhotos();
      
      toast.success(`Changes applied successfully! ${photosToDelete.length + changedPhotos.length} changes saved.`);
      setHasUnsavedChanges(false);
      
      // Close the gallery manager after successful changes
      onClose();
      
    } catch (error: any) {
      console.error('Error applying changes:', error);
      toast.error('Failed to apply changes: ' + (error.message || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (hasUnsavedChanges) {
      if (confirm('You have unsaved changes. Are you sure you want to close without saving?')) {
        onClose();
      }
    } else {
      onClose();
    }
  };

  const handlePhotoVisibilityToggle = (photoId: string, currentVisibility: 'public' | 'members_only') => {
    const newVisibility = currentVisibility === 'public' ? 'members_only' : 'public';
    
    console.log(`Changing photo ${photoId} from ${currentVisibility} to ${newVisibility} (local only)`);
    
    // Update photos locally without saving to database
    setPhotos(prevPhotos => 
      prevPhotos.map(photo => 
        photo.id === photoId 
          ? { ...photo, visibility: newVisibility }
          : photo
      )
    );
    
    setHasUnsavedChanges(true);
    toast.success(`Photo visibility changed to ${newVisibility === 'public' ? 'public' : 'members only'} (not saved yet)`);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Photo Gallery Manager - {modelName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Visibility Settings - Only show if not in mixed-mode-only */}
          {!mixedModeOnly && (
            <ModelVisibilitySettings
              initialVisibilityType={visibilityType}
              photos={photos}
              onVisibilityChange={handleVisibilityChange}
              loading={loading}
            />
          )}

          {/* Photo Gallery */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Upload className="w-5 h-5" />
                  Photo Gallery ({photos.length} photos)
                </CardTitle>
                <Button onClick={() => setShowAddPhoto(true)} disabled={loading}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Photo
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {photos.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Upload className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No photos uploaded yet</p>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowAddPhoto(true)}
                    className="mt-4"
                  >
                    Upload First Photo
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {photos.filter(photo => !photo.markedForDeletion).map((photo, index) => (
                    <div key={photo.id} className={`group relative ${photo.markedForDeletion ? 'opacity-50' : ''}`}>
                      <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                        <img
                          src={photo.image_url}
                          alt={`Photo ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      {/* Photo Controls */}
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                        <div className="flex gap-2">
                          {visibilityType === 'mixed' && (
                            <Button
                              size="sm"
                              variant={photo.visibility === 'public' ? 'default' : 'secondary'}
                              onClick={() => handlePhotoVisibilityToggle(photo.id, photo.visibility)}
                            >
                              {photo.visibility === 'public' ? (
                                <><Globe className="w-3 h-3 mr-1" />Public</>
                              ) : (
                                <><Users className="w-3 h-3 mr-1" />Members</>
                              )}
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDeletePhoto(photo.id)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>

                      {/* Visibility Badge */}
                      <div className="absolute top-2 right-2">
                        <Badge 
                          variant={photo.visibility === 'public' ? 'default' : 'secondary'}
                          className="text-xs"
                        >
                          {photo.visibility === 'public' ? (
                            <><Globe className="w-3 h-3 mr-1" />Public</>
                          ) : (
                            <><Users className="w-3 h-3 mr-1" />Members</>
                          )}
                        </Badge>
                      </div>

                      {/* Order Index */}
                      <div className="absolute top-2 left-2">
                        <Badge variant="outline" className="text-xs bg-white/90">
                          #{photo.order_index + 1}
                        </Badge>
                      </div>

                      {/* Unsaved Changes Indicator */}
                      {(() => {
                        const originalPhoto = originalPhotos.find(orig => orig.id === photo.id);
                        const hasChanged = originalPhoto && originalPhoto.visibility !== photo.visibility;
                        return hasChanged ? (
                          <div className="absolute bottom-2 left-2">
                            <Badge variant="outline" className="text-xs bg-yellow-100 border-yellow-300">
                              Unsaved
                            </Badge>
                          </div>
                        ) : null;
                      })()}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="flex justify-between items-center gap-2 pt-4 border-t">
            {hasUnsavedChanges && (
              <div className="flex items-center gap-2 text-sm text-yellow-600">
                <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                You have unsaved changes
              </div>
            )}
            <div className="flex gap-2 ml-auto">
              <Button 
                variant="outline" 
                onClick={handleClose}
                disabled={loading}
              >
                Close
              </Button>
              <Button 
                onClick={handleApplyChanges}
                disabled={loading || !hasUnsavedChanges}
              >
                {loading ? 'Applying...' : 'Apply Changes'}
              </Button>
            </div>
          </div>
        </div>

        {/* Add Photo Dialog */}
        {showAddPhoto && (
          <Dialog open={showAddPhoto} onOpenChange={setShowAddPhoto}>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Add New Photo - {modelName}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <ImageUpload
                  bucket="model-images"
                  onChange={(url: string, audience?: 'public' | 'members_only') => {
                    handleAddPhoto(url, audience);
                  }}
                  label="Upload Photo"
                  modelVisibilityType={visibilityType}
                  showAudienceSelector={visibilityType === 'mixed'}
                />
                
                {visibilityType === 'mixed' ? (
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h4 className="font-medium text-blue-900 mb-2">Mixed Model Photo Upload</h4>
                    <ul className="text-sm text-blue-800 space-y-1">
                      <li>• Check "Face is visible" if the photo shows the model's face</li>
                      <li>• Face visible photos default to "Members Only"</li>
                      <li>• Face not visible photos default to "Public"</li>
                      <li>• You can override the default audience selection</li>
                    </ul>
                  </div>
                ) : (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-600">
                      The photo will be added with <strong>
                        {visibilityType === 'public' ? 'public' : 'members only'}
                      </strong> visibility.
                    </p>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        )}
      </DialogContent>
    </Dialog>
  );
};