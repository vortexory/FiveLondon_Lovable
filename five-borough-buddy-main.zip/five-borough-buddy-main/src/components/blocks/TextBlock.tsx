import React, { useState } from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { GripVertical, Trash2, Type, Bold, Italic, List, Link, Code, AlignLeft, AlignCenter, AlignRight, AlignJustify, Underline, Strikethrough, Quote, ListOrdered, Minus, RotateCcw, Eraser, Subscript, Superscript, Search, Save, Eye, EyeOff, Copy, Clipboard, Redo, Image as ImageIcon, Table, Indent, Outdent, Palette } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

export interface TextBlockData {
  id: string;
  type: 'text';
  content: string;
  title?: string;
  order: number;
}

interface TextBlockProps {
  block: TextBlockData;
  partNumber: number;
  onUpdate: (id: string, updates: Partial<TextBlockData>) => void;
  onDelete: (id: string) => void;
}

export const TextBlock: React.FC<TextBlockProps> = ({
  block,
  partNumber,
  onUpdate,
  onDelete
}) => {
  const [showPreview, setShowPreview] = useState(false);
  const [undoStack, setUndoStack] = useState<string[]>([]);
  const [redoStack, setRedoStack] = useState<string[]>([]);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [autoSave, setAutoSave] = useState(true);
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging: sortableIsDragging,
  } = useSortable({ id: block.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: sortableIsDragging ? 0.5 : 1,
  };

  // Count words when content changes
  React.useEffect(() => {
    const words = block.content.replace(/<[^>]*>/g, '').trim().split(/\s+/).filter(word => word.length > 0);
    setWordCount(words.length);
  }, [block.content]);

  const handleContentChange = (content: string) => {
    // Add current content to undo stack before changing  
    if (block.content !== content) {
      setUndoStack(prev => [...prev.slice(-19), block.content]); // Keep last 20 states
      setRedoStack([]); // Clear redo stack on new change
    }
    
    // Update word count
    const words = content.replace(/<[^>]*>/g, '').trim().split(/\s+/).filter(word => word.length > 0);
    setWordCount(words.length);
    
    onUpdate(block.id, { content });
    
    // Auto-save functionality
    if (autoSave) {
      // Debounced save could be implemented here
    }
  };

  const handleTitleChange = (title: string) => {
    onUpdate(block.id, { title });
  };

  const handleUndo = () => {
    if (undoStack.length > 0) {
      const previousContent = undoStack[undoStack.length - 1];
      setRedoStack(prev => [...prev.slice(-19), block.content]);
      setUndoStack(prev => prev.slice(0, -1));
      onUpdate(block.id, { content: previousContent });
    }
  };

  const handleRedo = () => {
    if (redoStack.length > 0) {
      const nextContent = redoStack[redoStack.length - 1];
      setUndoStack(prev => [...prev.slice(-19), block.content]);
      setRedoStack(prev => prev.slice(0, -1));
      onUpdate(block.id, { content: nextContent });
    }
  };

  const clearFormatting = () => {
    const textarea = document.getElementById(`content-${block.id}`) as HTMLTextAreaElement;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selectedText = text.substring(start, end);
    
    // Remove all HTML tags from selected text
    const cleanText = selectedText.replace(/<[^>]*>/g, '');
    const newText = text.substring(0, start) + cleanText + text.substring(end);
    
    handleContentChange(newText);
    
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start, start + cleanText.length);
    }, 0);
  };

  const insertSpecialElement = (element: string) => {
    const textarea = document.getElementById(`content-${block.id}`) as HTMLTextAreaElement;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    
    let insertText = '';
    switch (element) {
      case 'hr':
        insertText = '\n<hr style="border: 1px solid #e0e0e0; margin: 20px 0;" />\n';
        break;
      case 'br':
        insertText = '<br />';
        break;
      case 'blockquote':
        insertText = '\n<blockquote style="border-left: 4px solid #ccc; margin: 10px 0; padding: 10px 15px; font-style: italic;">Quote text here</blockquote>\n';
        break;
      case 'table':
        insertText = '\n<table style="border-collapse: collapse; width: 100%; margin: 20px 0;">\n<thead>\n<tr>\n<th style="border: 1px solid #ddd; padding: 12px; background-color: #f5f5f5;">Header 1</th>\n<th style="border: 1px solid #ddd; padding: 12px; background-color: #f5f5f5;">Header 2</th>\n<th style="border: 1px solid #ddd; padding: 12px; background-color: #f5f5f5;">Header 3</th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<td style="border: 1px solid #ddd; padding: 12px;">Cell 1</td>\n<td style="border: 1px solid #ddd; padding: 12px;">Cell 2</td>\n<td style="border: 1px solid #ddd; padding: 12px;">Cell 3</td>\n</tr>\n<tr>\n<td style="border: 1px solid #ddd; padding: 12px;">Cell 4</td>\n<td style="border: 1px solid #ddd; padding: 12px;">Cell 5</td>\n<td style="border: 1px solid #ddd; padding: 12px;">Cell 6</td>\n</tr>\n</tbody>\n</table>\n';
        break;
      case 'code-block':
        insertText = '\n<pre style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; overflow-x: auto; font-family: monospace; border: 1px solid #e0e0e0;"><code>// Your code here\nconsole.log("Hello World!");</code></pre>\n';
        break;
      case 'image-placeholder':
        insertText = '\n<div style="border: 2px dashed #ccc; padding: 40px; text-align: center; margin: 20px 0; background-color: #f9f9f9;">\n<p style="margin: 0; color: #666;">📷 Image Placeholder - Replace with actual image</p>\n</div>\n';
        break;
    }
    
    const newText = text.substring(0, start) + insertText + text.substring(end);
    handleContentChange(newText);
    
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + insertText.length, start + insertText.length);
    }, 0);
  };

  const handleFindReplace = (action: 'find' | 'replace' | 'replace-all') => {
    const textarea = document.getElementById(`content-${block.id}`) as HTMLTextAreaElement;
    if (!textarea || !findText) return;
    
    const content = textarea.value;
    
    switch (action) {
      case 'find':
        const index = content.toLowerCase().indexOf(findText.toLowerCase());
        if (index !== -1) {
          textarea.focus();
          textarea.setSelectionRange(index, index + findText.length);
        }
        break;
      case 'replace':
        const selectedText = content.substring(textarea.selectionStart, textarea.selectionEnd);
        if (selectedText.toLowerCase() === findText.toLowerCase()) {
          const newContent = content.substring(0, textarea.selectionStart) + 
                           replaceText + 
                           content.substring(textarea.selectionEnd);
          handleContentChange(newContent);
        }
        break;
      case 'replace-all':
        const newContent = content.replace(new RegExp(findText, 'gi'), replaceText);
        handleContentChange(newContent);
        break;
    }
  };

  const handleKeyboardShortcuts = (e: React.KeyboardEvent) => {
    if (e.ctrlKey || e.metaKey) {
      switch (e.key.toLowerCase()) {
        case 'b':
          e.preventDefault();
          applySmartFormatting('font-weight', 'bold');
          break;
        case 'i':
          e.preventDefault();
          applySmartFormatting('font-style', 'italic');
          break;
        case 'u':
          e.preventDefault();
          applySmartFormatting('text-decoration', 'underline');
          break;
        case 'z':
          e.preventDefault();
          if (e.shiftKey) {
            handleRedo();
          } else {
            handleUndo();
          }
          break;
        case 'f':
          e.preventDefault();
          setShowFindReplace(!showFindReplace);
          break;
        case 's':
          e.preventDefault();
          // Auto-save is handled automatically
          break;
      }
    }
  };

  const copyToClipboard = async () => {
    const textarea = document.getElementById(`content-${block.id}`) as HTMLTextAreaElement;
    if (!textarea) return;
    
    const selectedText = textarea.value.substring(textarea.selectionStart, textarea.selectionEnd);
    if (selectedText) {
      await navigator.clipboard.writeText(selectedText);
    } else {
      await navigator.clipboard.writeText(textarea.value);
    }
  };

  const pasteFromClipboard = async () => {
    try {
      const clipboardText = await navigator.clipboard.readText();
      const textarea = document.getElementById(`content-${block.id}`) as HTMLTextAreaElement;
      if (!textarea) return;
      
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = textarea.value;
      const newText = text.substring(0, start) + clipboardText + text.substring(end);
      
      handleContentChange(newText);
      
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + clipboardText.length, start + clipboardText.length);
      }, 0);
    } catch (err) {
      console.warn('Failed to read clipboard');
    }
  };

  const handleIndentation = (outdent = false) => {
    const textarea = document.getElementById(`content-${block.id}`) as HTMLTextAreaElement;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selectedLines = text.substring(start, end);
    
    let modifiedText;
    if (outdent) {
      modifiedText = selectedLines.replace(/^(\s{2})/gm, ''); // Remove 2 spaces
    } else {
      modifiedText = selectedLines.replace(/^/gm, '  '); // Add 2 spaces
    }
    
    const newText = text.substring(0, start) + modifiedText + text.substring(end);
    handleContentChange(newText);
    
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start, start + modifiedText.length);
    }, 0);
  };

  const parseExistingStyles = (text: string): { styles: Record<string, string>, cleanText: string } => {
    let workingText = text;
    const styles: Record<string, string> = {};
    
    // First, extract all span elements with styles and consolidate them
    const spanRegex = /<span style="([^"]*)">(.*?)<\/span>/g;
    let match;
    let hasSpans = false;
    
    // Keep extracting spans until we get the innermost content
    while ((match = spanRegex.exec(workingText)) !== null) {
      hasSpans = true;
      const styleString = match[1];
      const content = match[2];
      
      // Parse and merge styles
      styleString.split(';').forEach(style => {
        const [property, value] = style.split(':').map(s => s.trim());
        if (property && value) {
          if (property === 'text-decoration') {
            // Handle multiple text decorations
            const existing = styles[property] || '';
            const newDecorations = value.split(' ').filter(Boolean);
            const existingDecorations = existing.split(' ').filter(Boolean);
            const combined = [...new Set([...existingDecorations, ...newDecorations])];
            styles[property] = combined.join(' ');
          } else {
            styles[property] = value;
          }
        }
      });
      
      // Continue with inner content
      workingText = content;
      spanRegex.lastIndex = 0; // Reset regex
    }
    
    // If we found spans, return the consolidated styles and clean text
    if (hasSpans) {
      return { styles, cleanText: workingText };
    }
    
    // Handle other formatting tags (fallback for non-span elements)
    let cleanText = workingText;
    
    if (text.includes('<strong>') || text.includes('<b>')) {
      styles['font-weight'] = 'bold';
      cleanText = cleanText.replace(/<\/?(?:strong|b)>/g, '');
    }
    if (text.includes('<em>') || text.includes('<i>')) {
      styles['font-style'] = 'italic';
      cleanText = cleanText.replace(/<\/?(?:em|i)>/g, '');
    }
    if (text.includes('<u>')) {
      const existing = styles['text-decoration'] || '';
      const decorations = existing.split(' ').filter(Boolean);
      if (!decorations.includes('underline')) {
        decorations.push('underline');
      }
      styles['text-decoration'] = decorations.join(' ');
      cleanText = cleanText.replace(/<\/?u>/g, '');
    }
    if (text.includes('<s>')) {
      const existing = styles['text-decoration'] || '';
      const decorations = existing.split(' ').filter(Boolean);
      if (!decorations.includes('line-through')) {
        decorations.push('line-through');
      }
      styles['text-decoration'] = decorations.join(' ');
      cleanText = cleanText.replace(/<\/?s>/g, '');
    }
    
    return { styles, cleanText };
  };

  const applySmartFormatting = (formatType: string, value: string) => {
    const textarea = document.getElementById(`content-${block.id}`) as HTMLTextAreaElement;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selectedText = text.substring(start, end);
    
    if (!selectedText.trim()) {
      // If no selection, wrap placeholder text
      const placeholderText = 'formatted text';
      const styles: Record<string, string> = {};
      styles[formatType] = value;
      const styledText = `<span style="${Object.entries(styles).map(([k, v]) => `${k}: ${v}`).join('; ')}">${placeholderText}</span>`;
      const newText = text.substring(0, start) + styledText + text.substring(end);
      handleContentChange(newText);
      
      setTimeout(() => {
        textarea.focus();
        const newStart = start + styledText.indexOf(placeholderText);
        textarea.setSelectionRange(newStart, newStart + placeholderText.length);
      }, 0);
      return;
    }
    
    const { styles: existingStyles, cleanText } = parseExistingStyles(selectedText);
    
    // Toggle the specific style
    const newStyles = { ...existingStyles };
    
    // Special handling for different format types
    if (formatType === 'text-decoration') {
      const currentDecorations = (newStyles['text-decoration'] || '').split(' ').filter(Boolean);
      if (currentDecorations.includes(value)) {
        // Remove this decoration
        const updatedDecorations = currentDecorations.filter(d => d !== value);
        if (updatedDecorations.length > 0) {
          newStyles['text-decoration'] = updatedDecorations.join(' ');
        } else {
          delete newStyles['text-decoration'];
        }
      } else {
        // Add this decoration
        currentDecorations.push(value);
        newStyles['text-decoration'] = currentDecorations.join(' ');
      }
    } else if (formatType === 'font-family' && value === 'monospace') {
      // Special handling for code formatting
      if (newStyles['font-family'] === 'monospace') {
        // Remove code formatting
        delete newStyles['font-family'];
        delete newStyles['background-color'];
        delete newStyles['padding'];
        delete newStyles['border-radius'];
      } else {
        // Apply code formatting
        newStyles['font-family'] = 'monospace';
        newStyles['background-color'] = '#f5f5f5';
        newStyles['padding'] = '2px 4px';
        newStyles['border-radius'] = '3px';
      }
    } else if (formatType === 'vertical-align') {
      // Special handling for superscript/subscript
      if (newStyles['vertical-align'] === value) {
        delete newStyles['vertical-align'];
        // Only remove font-size if it was set for super/sub
        if (newStyles['font-size'] === '0.8em') {
          delete newStyles['font-size'];
        }
      } else {
        newStyles['vertical-align'] = value;
        newStyles['font-size'] = '0.8em';
      }
    } else {
      // For other styles, toggle on/off
      if (newStyles[formatType] === value) {
        delete newStyles[formatType];
      } else {
        newStyles[formatType] = value;
      }
    }
    
    // Generate the final formatted text - always clean and consolidated
    let finalText = cleanText;
    if (Object.keys(newStyles).length > 0) {
      // Sort styles for consistency
      const sortedStyles = Object.entries(newStyles)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([property, val]) => `${property}: ${val}`)
        .join('; ');
      finalText = `<span style="${sortedStyles}">${cleanText}</span>`;
    }
    
    const newText = text.substring(0, start) + finalText + text.substring(end);
    handleContentChange(newText);
    
    setTimeout(() => {
      textarea.focus();
      const newStart = start + (finalText.indexOf(cleanText) >= 0 ? finalText.indexOf(cleanText) : 0);
      textarea.setSelectionRange(newStart, newStart + cleanText.length);
    }, 0);
  };

  const insertBasicFormatting = (startTag: string, endTag: string) => {
    const textarea = document.getElementById(`content-${block.id}`) as HTMLTextAreaElement;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selectedText = text.substring(start, end);
    
    // Check if selection is already wrapped with these tags
    const beforeSelection = text.substring(0, start);
    const afterSelection = text.substring(end);
    const isAlreadyFormatted = beforeSelection.endsWith(startTag) && afterSelection.startsWith(endTag);
    
    let newText: string;
    let newCursorStart: number;
    let newCursorEnd: number;
    
    if (isAlreadyFormatted) {
      // Remove the formatting
      const beforeStart = beforeSelection.slice(0, -startTag.length);
      const afterEnd = afterSelection.slice(endTag.length);
      newText = beforeStart + selectedText + afterEnd;
      newCursorStart = start - startTag.length;
      newCursorEnd = end - startTag.length;
    } else {
      // Apply the formatting
      const formattedText = startTag + (selectedText || 'placeholder text') + endTag;
      newText = text.substring(0, start) + formattedText + text.substring(end);
      newCursorStart = start + startTag.length;
      newCursorEnd = start + startTag.length + (selectedText || 'placeholder text').length;
    }
    
    handleContentChange(newText);
    
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursorStart, newCursorEnd);
    }, 0);
  };

  const toggleAlignment = (alignment: string) => {
    const textarea = document.getElementById(`content-${block.id}`) as HTMLTextAreaElement;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selectedText = text.substring(start, end);
    
    const alignmentStyle = `text-align: ${alignment};`;
    const divStartTag = `<div style="${alignmentStyle}">`;
    const divEndTag = '</div>';
    
    // Check if selection is already wrapped with alignment div
    const beforeSelection = text.substring(0, start);
    const afterSelection = text.substring(end);
    
    // Look for existing alignment div around selection
    const alignmentRegex = /<div style="text-align: \w+;">/;
    const isAlreadyAligned = beforeSelection.match(alignmentRegex) && afterSelection.startsWith(divEndTag);
    
    let newText: string;
    let newCursorPos: number;
    
    if (isAlreadyAligned) {
      // Remove alignment - find the last div with text-align
      const lastDivMatch = beforeSelection.match(/.*(<div style="text-align: \w+;">)$/);
      if (lastDivMatch) {
        const divStart = lastDivMatch[1];
        const beforeDiv = beforeSelection.slice(0, -divStart.length);
        const afterDiv = afterSelection.slice(divEndTag.length);
        newText = beforeDiv + selectedText + afterDiv;
        newCursorPos = start - divStart.length;
      } else {
        newText = text;
        newCursorPos = start;
      }
    } else {
      // Apply alignment
      const alignedText = divStartTag + selectedText + divEndTag;
      newText = text.substring(0, start) + alignedText + text.substring(end);
      newCursorPos = start + divStartTag.length;
    }
    
    handleContentChange(newText);
    
    // Reset cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursorPos, newCursorPos + selectedText.length);
    }, 0);
  };

  const applyTextColor = (color: string) => {
    applySmartFormatting('color', color);
  };

  const applyBackgroundColor = (color: string) => {
    applySmartFormatting('background-color', color);
  };

  const insertFontSize = (size: string) => {
    applySmartFormatting('font-size', size);
  };

  const insertFontFamily = (family: string) => {
    applySmartFormatting('font-family', family);
  };

  const basicFormatButtons = [
    { icon: Bold, action: () => applySmartFormatting('font-weight', 'bold'), tooltip: 'Bold (Ctrl+B)' },
    { icon: Italic, action: () => applySmartFormatting('font-style', 'italic'), tooltip: 'Italic (Ctrl+I)' },
    { icon: Underline, action: () => applySmartFormatting('text-decoration', 'underline'), tooltip: 'Underline (Ctrl+U)' },
    { icon: Strikethrough, action: () => applySmartFormatting('text-decoration', 'line-through'), tooltip: 'Strikethrough' },
    { icon: Code, action: () => applySmartFormatting('font-family', 'monospace'), tooltip: 'Inline Code' },
    { icon: Superscript, action: () => applySmartFormatting('vertical-align', 'super'), tooltip: 'Superscript' },
    { icon: Subscript, action: () => applySmartFormatting('vertical-align', 'sub'), tooltip: 'Subscript' },
  ];

  const listButtons = [
    { icon: List, action: () => insertBasicFormatting('<ul>\n<li>', '</li>\n</ul>'), tooltip: 'Bullet List' },
    { icon: ListOrdered, action: () => insertBasicFormatting('<ol>\n<li>', '</li>\n</ol>'), tooltip: 'Numbered List' },
    { icon: Quote, action: () => insertBasicFormatting('<blockquote>', '</blockquote>'), tooltip: 'Quote Block' },
  ];

  const alignmentButtons = [
    { icon: AlignLeft, action: () => toggleAlignment('left'), tooltip: 'Align Left' },
    { icon: AlignCenter, action: () => toggleAlignment('center'), tooltip: 'Align Center' },
    { icon: AlignRight, action: () => toggleAlignment('right'), tooltip: 'Align Right' },
    { icon: AlignJustify, action: () => toggleAlignment('justify'), tooltip: 'Justify' },
  ];

  const utilityButtons = [
    { icon: RotateCcw, action: handleUndo, tooltip: 'Undo (Ctrl+Z)', disabled: undoStack.length === 0 },
    { icon: Redo, action: handleRedo, tooltip: 'Redo (Ctrl+Shift+Z)', disabled: redoStack.length === 0 },
    { icon: Copy, action: copyToClipboard, tooltip: 'Copy (Ctrl+C)' },
    { icon: Clipboard, action: pasteFromClipboard, tooltip: 'Paste (Ctrl+V)' },
    { icon: Search, action: () => setShowFindReplace(!showFindReplace), tooltip: 'Find & Replace (Ctrl+F)' },
    { icon: Eraser, action: clearFormatting, tooltip: 'Clear Formatting' },
    { icon: Link, action: () => insertBasicFormatting('<a href="">', '</a>'), tooltip: 'Insert Link' },
  ];

  const advancedButtons = [
    { icon: Table, action: () => insertSpecialElement('table'), tooltip: 'Insert Table' },
    { icon: Code, action: () => insertSpecialElement('code-block'), tooltip: 'Code Block' },
    { icon: ImageIcon, action: () => insertSpecialElement('image-placeholder'), tooltip: 'Image Placeholder' },
    { icon: Indent, action: () => handleIndentation(false), tooltip: 'Indent' },
    { icon: Outdent, action: () => handleIndentation(true), tooltip: 'Outdent' },
  ];

  const fontFamilies = [
    { label: 'Default', value: 'inherit' },
    { label: 'Serif', value: 'serif' },
    { label: 'Sans Serif', value: 'sans-serif' },
    { label: 'Monospace', value: 'monospace' },
    { label: 'Arial', value: 'Arial, sans-serif' },
    { label: 'Georgia', value: 'Georgia, serif' },
    { label: 'Times', value: 'Times New Roman, serif' },
    { label: 'Courier', value: 'Courier New, monospace' },
  ];

  const textColors = [
    '#000000', '#e60000', '#ff9900', '#ffcc00', '#008a00', '#0066cc', '#9933ff',
    '#ffffff', '#facccc', '#ffebcc', '#ffffcc', '#cce8cc', '#cce0f5', '#ebd6ff',
    '#bbbbbb', '#f06666', '#ffc266', '#ffff66', '#66b266', '#66a3e0', '#c285ff',
    '#888888', '#a10000', '#b26b00', '#b2b200', '#006100', '#0047b2', '#6b24b2',
    '#444444', '#5c0000', '#663d00', '#666600', '#003700', '#002966', '#3d1466'
  ];

  const backgroundColors = [
    'transparent', '#ffebee', '#fff3e0', '#fffde7', '#e8f5e8', '#e3f2fd', '#f3e5f5',
    '#fce4ec', '#fff8e1', '#f1f8e9', '#e0f2f1', '#e1f5fe', '#ede7f6',
    '#f8bbd9', '#fff59d', '#dcedc1', '#b2dfdb', '#b3e5fc', '#d1c4e9'
  ];

  return (
    <div ref={setNodeRef} style={style}>
      <Card className={`relative ${sortableIsDragging ? 'shadow-lg' : ''}`}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div
                {...attributes}
                {...listeners}
                className="cursor-grab hover:cursor-grabbing p-1 rounded hover:bg-muted"
              >
                <GripVertical className="w-4 h-4 text-muted-foreground" />
              </div>
              <Type className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-medium text-muted-foreground">
                Part {partNumber} - Text Block
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(block.id)}
              className="text-destructive hover:text-destructive hover:bg-destructive/10"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor={`title-${block.id}`}>Section Title (Optional)</Label>
            <Input
              id={`title-${block.id}`}
              value={block.title || ''}
              onChange={(e) => handleTitleChange(e.target.value)}
              placeholder="Enter section title..."
              className="mt-1"
            />
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label htmlFor={`content-${block.id}`}>Content *</Label>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  {wordCount} words
                </span>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setAutoSave(!autoSave)}
                  className={`text-xs ${autoSave ? 'text-green-600' : 'text-gray-400'}`}
                  title={`Auto-save ${autoSave ? 'enabled' : 'disabled'}`}
                >
                  <Save className="w-3 h-3 mr-1" />
                  Auto
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowPreview(!showPreview)}
                  className="text-xs"
                >
                  {showPreview ? <EyeOff className="w-3 h-3 mr-1" /> : <Eye className="w-3 h-3 mr-1" />}
                  {showPreview ? 'Edit' : 'Preview'}
                </Button>
              </div>
            </div>
            
            {/* Find & Replace Bar */}
            {showFindReplace && !showPreview && (
              <div className="border rounded-md p-3 mb-2 bg-muted/10">
                <div className="flex items-center gap-2 mb-2">
                  <Input
                    placeholder="Find text..."
                    value={findText}
                    onChange={(e) => setFindText(e.target.value)}
                    className="flex-1 h-8"
                  />
                  <Input
                    placeholder="Replace with..."
                    value={replaceText}
                    onChange={(e) => setReplaceText(e.target.value)}
                    className="flex-1 h-8"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleFindReplace('find')}
                    className="text-xs"
                  >
                    Find Next
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleFindReplace('replace')}
                    className="text-xs"
                  >
                    Replace
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleFindReplace('replace-all')}
                    className="text-xs"
                  >
                    Replace All
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowFindReplace(false)}
                    className="text-xs ml-auto"
                  >
                    Close
                  </Button>
                </div>
              </div>
            )}
            
            {!showPreview && (
              <>
                {/* Professional Editor Toolbar */}
                <TooltipProvider>
                  <div className="border rounded-lg bg-card shadow-sm">
                    {/* Main Toolbar Header */}
                    <div className="flex items-center justify-between px-4 py-2 border-b bg-muted/30">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2">
                          <Type className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm font-medium">Rich Text Editor</span>
                        </div>
                        <Separator orientation="vertical" className="h-4" />
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>{wordCount} words</span>
                          <span>•</span>
                          <div className="flex items-center gap-1">
                            {autoSave ? (
                              <>
                                <Save className="w-3 h-3 text-green-600" />
                                <span className="text-green-600">Auto-save</span>
                              </>
                            ) : (
                              <>
                                <Save className="w-3 h-3" />
                                <span>Manual save</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setShowFindReplace(!showFindReplace)}
                              className="h-7 px-2"
                            >
                              <Search className="w-3 h-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Find & Replace (Ctrl+F)</TooltipContent>
                        </Tooltip>
                        
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setShowPreview(!showPreview)}
                              className="h-7 px-2"
                            >
                              <Eye className="w-3 h-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Preview Mode</TooltipContent>
                        </Tooltip>
                      </div>
                    </div>

                    {/* Primary Toolbar */}
                    <div className="px-3 py-2 border-b bg-background/50">
                      <div className="flex items-center gap-1">
                        {/* Text Formatting Group */}
                        <div className="flex items-center border rounded-md bg-background">
                          {basicFormatButtons.slice(0, 4).map((button, index) => (
                            <Tooltip key={index}>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={button.action}
                                  className="h-8 w-8 p-0 rounded-none border-r last:border-r-0 hover:bg-muted/50"
                                >
                                  <button.icon className="w-4 h-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>{button.tooltip}</TooltipContent>
                            </Tooltip>
                          ))}
                        </div>

                        <Separator orientation="vertical" className="h-6 mx-2" />

                        {/* Font Controls Group */}
                        <div className="flex items-center gap-2">
                          <Select onValueChange={insertFontFamily}>
                            <SelectTrigger className="w-32 h-8 text-xs">
                              <SelectValue placeholder="Font Family" />
                            </SelectTrigger>
                            <SelectContent>
                              {fontFamilies.map((font, index) => (
                                <SelectItem key={index} value={font.value} style={{ fontFamily: font.value }}>
                                  {font.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          
                          <Select onValueChange={insertFontSize}>
                            <SelectTrigger className="w-20 h-8 text-xs">
                              <SelectValue placeholder="Size" />
                            </SelectTrigger>
                            <SelectContent>
                              {['10px', '12px', '14px', '16px', '18px', '20px', '24px', '28px', '32px', '36px'].map(size => (
                                <SelectItem key={size} value={size}>{size}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <Separator orientation="vertical" className="h-6 mx-2" />

                        {/* Color Controls */}
                        <div className="flex items-center border rounded-md bg-background">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Select onValueChange={applyTextColor}>
                                <SelectTrigger className="w-10 h-8 border-0 rounded-none border-r">
                                  <Palette className="w-4 h-4" />
                                </SelectTrigger>
                                <SelectContent className="w-48">
                                  <div className="grid grid-cols-7 gap-1 p-2">
                                    {textColors.map((color, index) => (
                                      <button
                                        key={`text-${index}`}
                                        className="w-6 h-6 rounded border hover:scale-110 transition-transform"
                                        style={{ backgroundColor: color }}
                                        onClick={() => applyTextColor(color)}
                                        title={color}
                                      />
                                    ))}
                                  </div>
                                </SelectContent>
                              </Select>
                            </TooltipTrigger>
                            <TooltipContent>Text Color</TooltipContent>
                          </Tooltip>
                          
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Select onValueChange={applyBackgroundColor}>
                                <SelectTrigger className="w-10 h-8 border-0 rounded-none">
                                  <div className="w-4 h-4 bg-gradient-to-br from-yellow-200 to-yellow-400 rounded border" />
                                </SelectTrigger>
                                <SelectContent className="w-48">
                                  <div className="grid grid-cols-7 gap-1 p-2">
                                    {backgroundColors.map((color, index) => (
                                      <button
                                        key={`bg-${index}`}
                                        className="w-6 h-6 rounded border hover:scale-110 transition-transform"
                                        style={{ 
                                          backgroundColor: color === 'transparent' ? '#fff' : color,
                                          border: color === 'transparent' ? '2px dashed #ccc' : '1px solid #ccc' 
                                        }}
                                        onClick={() => applyBackgroundColor(color)}
                                        title={color}
                                      />
                                    ))}
                                  </div>
                                </SelectContent>
                              </Select>
                            </TooltipTrigger>
                            <TooltipContent>Background Color</TooltipContent>
                          </Tooltip>
                        </div>
                      </div>
                    </div>

                    {/* Secondary Toolbar */}
                    <div className="px-3 py-2 border-b bg-background/30">
                      <div className="flex items-center gap-1">
                        {/* Structure Group */}
                        <div className="flex items-center border rounded-md bg-background">
                          {['H1', 'H2', 'H3', 'H4', 'H5', 'H6'].map((heading, index) => (
                            <Tooltip key={heading}>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => insertBasicFormatting(`<h${index + 1}>`, `</h${index + 1}>`)}
                                  className="h-8 px-2 text-xs font-medium rounded-none border-r last:border-r-0 hover:bg-muted/50"
                                >
                                  {heading}
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Heading {index + 1}</TooltipContent>
                            </Tooltip>
                          ))}
                        </div>

                        <Separator orientation="vertical" className="h-6 mx-2" />

                        {/* Lists & Alignment Group */}
                        <div className="flex items-center border rounded-md bg-background">
                          {[...listButtons, ...alignmentButtons].map((button, index) => (
                            <Tooltip key={index}>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={button.action}
                                  className="h-8 w-8 p-0 rounded-none border-r last:border-r-0 hover:bg-muted/50"
                                >
                                  <button.icon className="w-4 h-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>{button.tooltip}</TooltipContent>
                            </Tooltip>
                          ))}
                        </div>

                        <Separator orientation="vertical" className="h-6 mx-2" />

                        {/* Insert Elements Group */}
                        <div className="flex items-center border rounded-md bg-background">
                          {advancedButtons.map((button, index) => (
                            <Tooltip key={index}>
                              <TooltipTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={button.action}
                                  className="h-8 w-8 p-0 rounded-none border-r last:border-r-0 hover:bg-muted/50"
                                >
                                  <button.icon className="w-4 h-4" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>{button.tooltip}</TooltipContent>
                            </Tooltip>
                          ))}
                          
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => insertSpecialElement('hr')}
                                className="h-8 w-8 p-0 rounded-none hover:bg-muted/50"
                              >
                                <Minus className="w-4 h-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Horizontal Rule</TooltipContent>
                          </Tooltip>
                        </div>
                      </div>
                    </div>

                    {/* Utility Toolbar */}
                    <div className="px-3 py-2 bg-background/20">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          {/* Edit History Group */}
                          <div className="flex items-center border rounded-md bg-background">
                            {utilityButtons.slice(0, 2).map((button, index) => (
                              <Tooltip key={index}>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={button.action}
                                    disabled={button.disabled}
                                    className="h-8 w-8 p-0 rounded-none border-r last:border-r-0 hover:bg-muted/50 disabled:opacity-30"
                                  >
                                    <button.icon className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>{button.tooltip}</TooltipContent>
                              </Tooltip>
                            ))}
                          </div>

                          <Separator orientation="vertical" className="h-6 mx-2" />

                          {/* Clipboard Group */}
                          <div className="flex items-center border rounded-md bg-background">
                            {utilityButtons.slice(2, 4).map((button, index) => (
                              <Tooltip key={index}>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={button.action}
                                    className="h-8 w-8 p-0 rounded-none border-r last:border-r-0 hover:bg-muted/50"
                                  >
                                    <button.icon className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>{button.tooltip}</TooltipContent>
                              </Tooltip>
                            ))}
                          </div>

                          <Separator orientation="vertical" className="h-6 mx-2" />

                          {/* Special Formatting */}
                          <div className="flex items-center border rounded-md bg-background">
                            {basicFormatButtons.slice(4).map((button, index) => (
                              <Tooltip key={index}>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={button.action}
                                    className="h-8 w-8 p-0 rounded-none border-r last:border-r-0 hover:bg-muted/50"
                                  >
                                    <button.icon className="w-4 h-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>{button.tooltip}</TooltipContent>
                              </Tooltip>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center border rounded-md bg-background">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={clearFormatting}
                                className="h-8 w-8 p-0 rounded-none border-r hover:bg-muted/50"
                              >
                                <Eraser className="w-4 h-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Clear Formatting</TooltipContent>
                          </Tooltip>
                          
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => insertBasicFormatting('<a href="">', '</a>')}
                                className="h-8 w-8 p-0 rounded-none hover:bg-muted/50"
                              >
                                <Link className="w-4 h-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Insert Link</TooltipContent>
                          </Tooltip>
                        </div>
                      </div>
                    </div>
                  </div>
                </TooltipProvider>
                
                <Textarea
                  id={`content-${block.id}`}
                  value={block.content}
                  onChange={(e) => handleContentChange(e.target.value)}
                  onKeyDown={handleKeyboardShortcuts}
                  placeholder="Start writing your content here. Use the toolbar above for rich formatting or keyboard shortcuts (Ctrl+B, Ctrl+I, Ctrl+U, Ctrl+Z, Ctrl+F)..."
                  rows={14}
                  className="mt-2 rounded-lg border-2 min-h-[350px] font-mono text-sm focus:border-primary/50 transition-colors resize-y"
                />
              </>
            )}
            
            {showPreview && (
              <div 
                className="border rounded-md p-4 min-h-[200px] bg-background prose prose-sm max-w-none"
                dangerouslySetInnerHTML={{ __html: block.content }}
              />
            )}
            
            <div className="text-xs text-muted-foreground mt-1 flex justify-between">
              <span>{block.content.length} characters • {wordCount} words</span>
              <div className="flex items-center gap-2">
                <span>Professional HTML Editor</span>
                {autoSave && <span className="text-green-600">● Auto-saved</span>}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};