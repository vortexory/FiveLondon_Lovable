import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { GripVertical, Trash2, Image as ImageIcon } from 'lucide-react';
import { ImageUpload } from '@/components/ImageUpload';

export interface ImageBlockData {
  id: string;
  type: 'image';
  content: string; // image URL
  title?: string;
  caption?: string;
  alt?: string;
  description?: string;
  order: number;
}

interface ImageBlockProps {
  block: ImageBlockData;
  partNumber: number;
  onUpdate: (id: string, updates: Partial<ImageBlockData>) => void;
  onDelete: (id: string) => void;
}

export const ImageBlock: React.FC<ImageBlockProps> = ({
  block,
  partNumber,
  onUpdate,
  onDelete
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging: sortableIsDragging,
  } = useSortable({ id: block.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: sortableIsDragging ? 0.5 : 1,
  };

  const handleImageChange = (url: string) => {
    onUpdate(block.id, { content: url });
  };

  const handleCaptionChange = (caption: string) => {
    onUpdate(block.id, { caption });
  };

  const handleDescriptionChange = (description: string) => {
    onUpdate(block.id, { description });
  };

  const handleAltChange = (alt: string) => {
    onUpdate(block.id, { alt });
  };

  const handleTitleChange = (title: string) => {
    onUpdate(block.id, { title });
  };

  return (
    <div ref={setNodeRef} style={style}>
      <Card className={`relative transition-all duration-200 ${sortableIsDragging ? 'shadow-xl scale-105' : 'shadow-sm hover:shadow-md'}`}>
        <CardHeader className="pb-4 bg-gradient-to-r from-primary/5 to-secondary/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                {...attributes}
                {...listeners}
                className="cursor-grab hover:cursor-grabbing p-2 rounded-md hover:bg-muted/50 transition-colors"
              >
                <GripVertical className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-primary" />
                <span className="text-sm font-semibold text-foreground">
                  Part {partNumber} - Image Block
                </span>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(block.id)}
              className="text-destructive hover:text-destructive hover:bg-destructive/10 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6 p-6">
          {/* Image Upload Section */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Image Upload</Label>
            <ImageUpload
              bucket="blog-images"
              value={block.content}
              onChange={handleImageChange}
              label=""
            />
          </div>

          {/* Form Fields */}
          <div className="grid gap-4">
            {/* Title Field */}
            <div className="space-y-2">
              <Label htmlFor={`title-${block.id}`} className="text-sm font-medium">
                Title <span className="text-muted-foreground font-normal">(Optional)</span>
              </Label>
              <Input
                id={`title-${block.id}`}
                value={block.title || ''}
                onChange={(e) => handleTitleChange(e.target.value)}
                placeholder="Enter image title..."
              />
              <div className="text-xs text-muted-foreground">
                Title will be displayed above the image
              </div>
            </div>

            {/* Content Field */}
            <div className="space-y-2">
              <Label htmlFor={`description-${block.id}`} className="text-sm font-medium">
                Content
              </Label>
              <Input
                id={`description-${block.id}`}
                value={block.description || ''}
                onChange={(e) => handleDescriptionChange(e.target.value)}
                placeholder="Brief description of the image content..."
                className="resize-none"
              />
              <div className="text-xs text-muted-foreground">
                This description will be displayed below the image in the blog post
              </div>
            </div>

            {/* Caption Field */}
            <div className="space-y-2">
              <Label htmlFor={`caption-${block.id}`} className="text-sm font-medium">
                Caption <span className="text-muted-foreground font-normal">(Optional)</span>
              </Label>
              <Input
                id={`caption-${block.id}`}
                value={block.caption || ''}
                onChange={(e) => handleCaptionChange(e.target.value)}
                placeholder="Enter image caption..."
              />
              <div className="text-xs text-muted-foreground">
                Caption appears as overlay text on the image
              </div>
            </div>

            {/* Alt Text Field */}
            <div className="space-y-2">
              <Label htmlFor={`alt-${block.id}`} className="text-sm font-medium">
                Alt Text <span className="text-xs text-primary">(Required for SEO)</span>
              </Label>
              <Input
                id={`alt-${block.id}`}
                value={block.alt || ''}
                onChange={(e) => handleAltChange(e.target.value)}
                placeholder="Describe the image for accessibility and SEO..."
                className={`${!block.alt && block.content ? 'border-amber-300 focus:border-amber-400' : ''}`}
              />
              <div className="text-xs text-muted-foreground">
                Descriptive text for screen readers and search engines - be specific and detailed
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};