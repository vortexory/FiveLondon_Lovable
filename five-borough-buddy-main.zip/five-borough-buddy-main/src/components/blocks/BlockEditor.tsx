import React, { useState, useCallback } from 'react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import {
  restrictToVerticalAxis,
  restrictToWindowEdges,
} from '@dnd-kit/modifiers';
import { Button } from '@/components/ui/button';
import { Type, Image as ImageIcon } from 'lucide-react';
import { TextBlock, type TextBlockData } from './TextBlock';
import { ImageBlock, type ImageBlockData } from './ImageBlock';
import { Card, CardContent } from '@/components/ui/card';

export type BlockData = TextBlockData | ImageBlockData;

interface BlockEditorProps {
  blocks: BlockData[];
  onChange: (blocks: BlockData[]) => void;
}

export const BlockEditor: React.FC<BlockEditorProps> = ({ blocks, onChange }) => {
  const [activeId, setActiveId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const generateId = () => {
    return `block-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  };

  const addTextBlock = useCallback(() => {
    const newBlock: TextBlockData = {
      id: generateId(),
      type: 'text',
      content: '',
      order: blocks.length + 1,
    };
    onChange([...blocks, newBlock]);
  }, [blocks, onChange]);

  const addImageBlock = useCallback(() => {
    const newBlock: ImageBlockData = {
      id: generateId(),
      type: 'image',
      content: '',
      order: blocks.length + 1,
    };
    onChange([...blocks, newBlock]);
  }, [blocks, onChange]);

  const updateBlock = useCallback((id: string, updates: Partial<BlockData>) => {
    const updatedBlocks = blocks.map(block =>
      block.id === id ? { ...block, ...updates } : block
    );
    onChange(updatedBlocks);
  }, [blocks, onChange]);

  const deleteBlock = useCallback((id: string) => {
    const filteredBlocks = blocks.filter(block => block.id !== id);
    // Reorder the remaining blocks
    const reorderedBlocks = filteredBlocks.map((block, index) => ({
      ...block,
      order: index + 1,
    }));
    onChange(reorderedBlocks);
  }, [blocks, onChange]);

  const handleDragStart = (event: any) => {
    setActiveId(event.active.id);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);

    if (over && active.id !== over.id) {
      const oldIndex = blocks.findIndex(block => block.id === active.id);
      const newIndex = blocks.findIndex(block => block.id === over.id);

      const reorderedBlocks = arrayMove(blocks, oldIndex, newIndex);
      // Update order values
      const updatedBlocks = reorderedBlocks.map((block, index) => ({
        ...block,
        order: index + 1,
      }));

      onChange(updatedBlocks);
    }
  };

  const handleDragCancel = () => {
    setActiveId(null);
  };

  const renderBlock = (block: BlockData, index: number) => {
    const partNumber = index + 1;
    const isActive = activeId === block.id;

    switch (block.type) {
      case 'text':
        return (
          <div key={block.id} className={isActive ? 'opacity-50' : ''}>
            <TextBlock
              block={block}
              partNumber={partNumber}
              onUpdate={updateBlock}
              onDelete={deleteBlock}
            />
          </div>
        );
      case 'image':
        return (
          <div key={block.id} className={isActive ? 'opacity-50' : ''}>
            <ImageBlock
              block={block}
              partNumber={partNumber}
              onUpdate={updateBlock}
              onDelete={deleteBlock}
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4">
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onDragCancel={handleDragCancel}
        modifiers={[restrictToVerticalAxis, restrictToWindowEdges]}
      >
        <SortableContext
          items={blocks.map(block => block.id)}
          strategy={verticalListSortingStrategy}
        >
          <div className="space-y-4">
            {blocks.map((block, index) => renderBlock(block, index))}
          </div>
        </SortableContext>
      </DndContext>

      {/* Add Block Buttons */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-center gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={addTextBlock}
              className="flex items-center gap-2"
            >
              <Type className="w-4 h-4" />
              Add Text Block
            </Button>
            <Button
              type="button"
              variant="outline" 
              onClick={addImageBlock}
              className="flex items-center gap-2"
            >
              <ImageIcon className="w-4 h-4" />
              Add Image Block
            </Button>
          </div>
          <div className="text-center text-sm text-muted-foreground mt-2">
            {blocks.length === 0 
              ? "Start by adding your first content block"
              : `${blocks.length} content block${blocks.length === 1 ? '' : 's'}`
            }
          </div>
        </CardContent>
      </Card>
    </div>
  );
};