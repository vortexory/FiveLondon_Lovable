import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { 
  User, 
  MapPin, 
  Calendar, 
  Ruler, 
  Eye, 
  Heart, 
  Star,
  Globe,
  Camera,
  BookOpen
} from 'lucide-react';
import { toast } from 'sonner';

interface Model {
  id: string;
  name: string;
  location?: string | null;
  age?: number | null;
  height?: string | null;
  measurements?: string | null;
  hair?: string | null;
  eyes?: string | null;
  nationality?: string | null;
  education?: string | null;
  description?: string | null;
  price?: string | null;
  services?: string[] | null;
  characteristics?: string[] | null;
  interests?: string[] | null;
  availability?: string | null;
  rating?: number | null;
  reviews?: number | null;
  members_only?: boolean | null;
  all_photos_public?: boolean | null;
  face_visible?: boolean | null;
  created_at: string;
}

interface ModelGallery {
  id: string;
  image_url: string;
  visibility: 'public' | 'members_only';
  caption?: string | null;
  order_index: number;
}

interface ModelDetailsDialogProps {
  model: Model | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ModelDetailsDialog: React.FC<ModelDetailsDialogProps> = ({
  model,
  isOpen,
  onClose
}) => {
  const [gallery, setGallery] = useState<ModelGallery[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (model && isOpen) {
      fetchModelGallery();
    }
  }, [model, isOpen]);

  const fetchModelGallery = async () => {
    if (!model) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('model_gallery')
        .select('*')
        .eq('model_id', model.id)
        .order('order_index');

      if (error) throw error;
      setGallery((data || []).map(item => ({
        ...item,
        visibility: (item.visibility as 'public' | 'members_only') || 'public',
        order_index: item.order_index || 0
      })));
    } catch (error) {
      console.error('Error fetching model gallery:', error);
      toast.error('Failed to load gallery');
    } finally {
      setLoading(false);
    }
  };

  if (!model) return null;

  const publicPhotos = gallery.filter(photo => photo.visibility === 'public');
  const memberPhotos = gallery.filter(photo => photo.visibility === 'members_only');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <User className="w-6 h-6" />
            {model.name} - Complete Profile
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="gallery">Gallery ({gallery.length})</TabsTrigger>
            <TabsTrigger value="statistics">Statistics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Basic Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Name:</span>
                    <span className="text-sm">{model.name}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      Age:
                    </span>
                    <span className="text-sm">{model.age || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      Location:
                    </span>
                    <span className="text-sm">{model.location || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <Globe className="w-3 h-3" />
                      Nationality:
                    </span>
                    <span className="text-sm">{model.nationality || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <BookOpen className="w-3 h-3" />
                      Education:
                    </span>
                    <span className="text-sm">{model.education || 'Not specified'}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Physical Attributes */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Ruler className="w-4 h-4" />
                    Physical Attributes
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Height:</span>
                    <span className="text-sm">{model.height || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Measurements:</span>
                    <span className="text-sm">{model.measurements || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Hair Color:</span>
                    <span className="text-sm">{model.hair || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Eye Color:</span>
                    <span className="text-sm">{model.eyes || 'Not specified'}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Services & Pricing */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-4 h-4" />
                    Services & Pricing
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Price Range:</span>
                    <span className="text-sm font-semibold text-primary">
                      {model.price || 'Contact for pricing'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Availability:</span>
                    <Badge variant="outline">
                      {model.availability || 'Contact us'}
                    </Badge>
                  </div>
                  <div>
                    <span className="text-sm font-medium">Services:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {model.services?.length ? (
                        model.services.map((service, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {service}
                          </Badge>
                        ))
                      ) : (
                        <span className="text-xs text-muted-foreground">No services specified</span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Privacy & Visibility */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    Privacy & Visibility
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Profile Type:</span>
                    <Badge variant={model.members_only ? 'secondary' : 'default'}>
                      {model.members_only ? 'Members Only' : 'Public'}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Face Visible:</span>
                    <Badge variant={model.face_visible ? 'default' : 'secondary'}>
                      {model.face_visible ? 'Yes' : 'No'}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">All Photos Public:</span>
                    <Badge variant={model.all_photos_public ? 'default' : 'secondary'}>
                      {model.all_photos_public ? 'Yes' : 'Mixed Visibility'}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Total Photos:</span>
                    <span className="text-sm font-semibold">{gallery.length}</span>
                  </div>
                  {!model.all_photos_public && (
                    <div className="text-xs space-y-1">
                      <div>Public Photos: {publicPhotos.length}</div>
                      <div>Member Photos: {memberPhotos.length}</div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Description */}
            {model.description && (
              <Card>
                <CardHeader>
                  <CardTitle>Description</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm leading-relaxed">{model.description}</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="details" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Characteristics */}
              <Card>
                <CardHeader>
                  <CardTitle>Characteristics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {model.characteristics?.length ? (
                      model.characteristics.map((char, index) => (
                        <Badge key={index} variant="outline">
                          {char}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-sm text-muted-foreground">No characteristics specified</span>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Interests */}
              <Card>
                <CardHeader>
                  <CardTitle>Interests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {model.interests?.length ? (
                      model.interests.map((interest, index) => (
                        <Badge key={index} variant="outline">
                          <Heart className="w-3 h-3 mr-1" />
                          {interest}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-sm text-muted-foreground">No interests specified</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="gallery" className="space-y-4">
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="text-sm text-muted-foreground mt-2">Loading gallery...</p>
              </div>
            ) : gallery.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-8">
                  <Camera className="w-12 h-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Photos Available</h3>
                  <p className="text-sm text-muted-foreground text-center">
                    This model doesn't have any photos in their gallery yet.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                {publicPhotos.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      Public Photos ({publicPhotos.length})
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {publicPhotos.map((photo, index) => (
                        <div key={photo.id} className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                          <img
                            src={photo.image_url}
                            alt={photo.caption || `Photo ${index + 1}`}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {memberPhotos.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      Member Only Photos ({memberPhotos.length})
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {memberPhotos.map((photo, index) => (
                        <div key={photo.id} className="aspect-square bg-gray-100 rounded-lg overflow-hidden relative">
                          <img
                            src={photo.image_url}
                            alt={photo.caption || `Member photo ${index + 1}`}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
                          />
                          <Badge className="absolute top-2 right-2" variant="secondary">
                            Members Only
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="statistics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Rating</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="text-2xl font-bold">
                      {model.rating ? model.rating.toFixed(1) : 'N/A'}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      ({model.reviews || 0} reviews)
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Profile Views</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Eye className="w-5 h-5 text-blue-500" />
                    <span className="text-2xl font-bold">N/A</span>
                    <span className="text-sm text-muted-foreground">this month</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Member Since</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-green-500" />
                    <span className="text-lg font-semibold">
                      {new Date(model.created_at).toLocaleDateString('en-US', {
                        month: 'short',
                        year: 'numeric'
                      })}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Activity Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Profile Created:</span>
                    <span className="text-sm font-medium">
                      {new Date(model.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Gallery Photos:</span>
                    <span className="text-sm font-medium">{gallery.length} photos</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Profile Status:</span>
                    <Badge variant={model.members_only ? 'secondary' : 'default'}>
                      {model.members_only ? 'Private' : 'Public'}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};