import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { DataTable } from '@/components/DataTable';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ImageUpload } from '@/components/ImageUpload';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Image as ImageIcon,
  Plus,
  Edit,
  Trash2
} from 'lucide-react';

interface ModelGalleryItem {
  id: string;
  model_id: string;
  image_url: string;
  caption?: string | null;
  order_index: number | null;
  visibility: string | null;
  created_at: string;
}

interface Model {
  id: string;
  name: string;
}

export const GalleryManagement: React.FC = () => {
  const [modelGallery, setModelGallery] = useState<ModelGalleryItem[]>([]);
  const [models, setModels] = useState<Model[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<{ [key: string]: boolean }>({});
  const [isModelDialogOpen, setIsModelDialogOpen] = useState(false);
  const [editingModelItem, setEditingModelItem] = useState<ModelGalleryItem | null>(null);

  const [modelForm, setModelForm] = useState({
    model_id: '',
    image_url: '',
    caption: '',
    visibility: 'public',
    new_model_name: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [modelRes, modelsRes] = await Promise.all([
        supabase.from('model_gallery').select('*').order('model_id, order_index'),
        supabase.from('models').select('id, name').order('name')
      ]);

      if (modelRes.error) throw modelRes.error;
      if (modelsRes.error) throw modelsRes.error;

      setModelGallery((modelRes.data || []).map(item => ({
        ...item,
        order_index: item.order_index ?? 0,
        visibility: item.visibility ?? 'public'
      })));
      setModels(modelsRes.data || []);
    } catch (error: any) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load gallery data');
    } finally {
      setLoading(false);
    }
  };

  // Create new model function
  const createNewModel = async (name: string) => {
    try {
      const { data, error } = await supabase
        .from('models')
        .insert({ name })
        .select()
        .single();
      
      if (error) throw error;
      
      // Refresh models list
      const { data: modelsData, error: modelsError } = await supabase
        .from('models')
        .select('id, name')
        .order('name');
      
      if (modelsError) throw modelsError;
      setModels(modelsData || []);
      
      return data.id;
    } catch (error: any) {
      console.error('Error creating model:', error);
      toast.error('Failed to create model');
      throw error;
    }
  };

  // Model Gallery Functions
  const saveModelItem = async () => {
    if (!modelForm.image_url) {
      toast.error('Image is required');
      return;
    }

    // Handle new model creation
    let modelId = modelForm.model_id;
    if (modelForm.model_id === 'new' && modelForm.new_model_name.trim()) {
      try {
        modelId = await createNewModel(modelForm.new_model_name.trim());
      } catch (error) {
        return; // Error already handled in createNewModel
      }
    } else if (!modelForm.model_id || modelForm.model_id === 'new') {
      toast.error('Please select a model or create a new one');
      return;
    }

    setActionLoading({ saveModel: true });

    try {
      const itemData = {
        model_id: modelId,
        image_url: modelForm.image_url,
        caption: modelForm.caption,
        visibility: modelForm.visibility,
        order_index: editingModelItem ? editingModelItem.order_index : 
          modelGallery.filter(item => item.model_id === modelId).length
      };

      if (editingModelItem) {
        const { error } = await supabase
          .from('model_gallery')
          .update(itemData)
          .eq('id', editingModelItem.id);
        if (error) throw error;
        toast.success('Model gallery item updated');
      } else {
        const { error } = await supabase
          .from('model_gallery')
          .insert(itemData);
        if (error) throw error;
        toast.success('Model gallery item created');
      }

      await fetchData();
      closeModelDialog();
    } catch (error: any) {
      console.error('Error saving model gallery item:', error);
      toast.error('Failed to save gallery item');
    } finally {
      setActionLoading({ saveModel: false });
    }
  };

  const deleteModelItem = async (item: ModelGalleryItem) => {
    if (!confirm('Are you sure you want to delete this gallery item?')) return;

    setActionLoading({ [`deleteModel_${item.id}`]: true });

    try {
      const { error } = await supabase
        .from('model_gallery')
        .delete()
        .eq('id', item.id);

      if (error) throw error;
      toast.success('Model gallery item deleted');
      await fetchData();
    } catch (error: any) {
      console.error('Error deleting model gallery item:', error);
      toast.error('Failed to delete gallery item');
    } finally {
      setActionLoading({ [`deleteModel_${item.id}`]: false });
    }
  };

  const openModelDialog = (item?: ModelGalleryItem) => {
    if (item) {
      setEditingModelItem(item);
      setModelForm({
        model_id: item.model_id,
        image_url: item.image_url,
        caption: item.caption || '',
        visibility: item.visibility || 'public',
        new_model_name: ''
      });
    } else {
      setEditingModelItem(null);
      setModelForm({
        model_id: '',
        image_url: '',
        caption: '',
        visibility: 'public',
        new_model_name: ''
      });
    }
    setIsModelDialogOpen(true);
  };

  const closeModelDialog = () => {
    setIsModelDialogOpen(false);
    setEditingModelItem(null);
    setModelForm({
      model_id: '',
      image_url: '',
      caption: '',
      visibility: 'public',
      new_model_name: ''
    });
  };

  const modelColumns = [
    {
      key: 'image',
      header: 'Image',
      render: (item: ModelGalleryItem) => (
        <div className="w-16 h-16 rounded overflow-hidden bg-muted flex items-center justify-center">
          <img src={item.image_url} alt={item.caption ?? ''} className="w-full h-full object-cover" />
        </div>
      )
    },
    {
      key: 'model',
      header: 'Model',
      render: (item: ModelGalleryItem) => {
        const model = models.find(m => m.id === item.model_id);
        return model?.name || 'Unknown Model';
      }
    },
    {
      key: 'caption',
      header: 'Caption',
      render: (item: ModelGalleryItem) => item.caption || 'No caption'
    },
    {
      key: 'visibility',
      header: 'Visibility',
      render: (item: ModelGalleryItem) => (
        <Badge variant={item.visibility === 'public' ? 'default' : 'secondary'}>
          {item.visibility}
        </Badge>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (item: ModelGalleryItem) => (
        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={() => openModelDialog(item)}>
            <Edit className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteModelItem(item)}
            disabled={actionLoading[`deleteModel_${item.id}`]}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner size={32} text="Loading galleries..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <ImageIcon className="w-5 h-5" />
        <h2 className="text-2xl font-bold">Gallery Settings</h2>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Model Galleries</CardTitle>
          <Button onClick={() => openModelDialog()} className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Model Item
          </Button>
        </CardHeader>
        <CardContent>
          <DataTable
            data={modelGallery}
            columns={modelColumns}
            emptyStateIcon={ImageIcon}
            emptyStateTitle="No model gallery items"
            emptyStateDescription="Add items to model galleries"
            emptyStateAction="Add Item"
            onEmptyStateAction={() => openModelDialog()}
          />
        </CardContent>
      </Card>

      {/* Model Gallery Dialog */}
      <Dialog open={isModelDialogOpen} onOpenChange={setIsModelDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingModelItem ? 'Edit Model Gallery Item' : 'Add Model Gallery Item'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Select Model</Label>
              <select
                value={modelForm.model_id}
                onChange={(e) => setModelForm({ ...modelForm, model_id: e.target.value, new_model_name: '' })}
                className="w-full p-2 border rounded-md"
              >
                <option value="">Select a model...</option>
                {models.map((model) => (
                  <option key={model.id} value={model.id}>
                    {model.name}
                  </option>
                ))}
                <option value="new">Create New Model</option>
              </select>
            </div>

            {modelForm.model_id === 'new' && (
              <div>
                <Label>New Model Name</Label>
                <Input
                  value={modelForm.new_model_name}
                  onChange={(e) => setModelForm({ ...modelForm, new_model_name: e.target.value })}
                  placeholder="Enter new model name"
                />
              </div>
            )}

            <div>
              <Label>Image</Label>
              <ImageUpload
                value={modelForm.image_url}
                onChange={(url: string) => setModelForm({ ...modelForm, image_url: url })}
                bucket="model-galleries"
              />
            </div>

            <div>
              <Label>Caption</Label>
              <Input
                value={modelForm.caption}
                onChange={(e) => setModelForm({ ...modelForm, caption: e.target.value })}
                placeholder="Optional caption"
              />
            </div>

            <div>
              <Label>Visibility</Label>
              <select
                value={modelForm.visibility}
                onChange={(e) => setModelForm({ ...modelForm, visibility: e.target.value })}
                className="w-full p-2 border rounded-md"
              >
                <option value="public">Public</option>
                <option value="members_only">Members Only</option>
                <option value="private">Private</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={closeModelDialog}>
              Cancel
            </Button>
            <Button onClick={saveModelItem} disabled={actionLoading.saveModel}>
              {actionLoading.saveModel ? 'Saving...' : editingModelItem ? 'Update' : 'Create'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};