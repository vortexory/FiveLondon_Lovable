import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { DataTable } from '@/components/DataTable';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Search,
  Plus,
  Edit,
  Trash2,
  Settings,
  FileText
} from 'lucide-react';

interface SEOSetting {
  id: string;
  setting_key: string;
  setting_value: any;
  category: string;
  description?: string | null;
  created_at: string;
  updated_at: string;
}

interface PageSEO {
  id: string;
  page_path: string;
  meta_title?: string | null;
  meta_description?: string | null;
  meta_keywords: string[] | null;
  og_title?: string | null;
  og_description?: string | null;
  og_image?: string | null;
  canonical_url?: string | null;
  is_active: boolean | null;
  created_at: string;
  updated_at: string;
}

export const SEOSettingsManagement: React.FC = () => {
  const [seoSettings, setSeoSettings] = useState<SEOSetting[]>([]);
  const [pageSettings, setPageSettings] = useState<PageSEO[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<{ [key: string]: boolean }>({});
  const [isSettingDialogOpen, setIsSettingDialogOpen] = useState(false);
  const [isPageDialogOpen, setIsPageDialogOpen] = useState(false);
  const [editingSetting, setEditingSetting] = useState<SEOSetting | null>(null);
  const [editingPage, setEditingPage] = useState<PageSEO | null>(null);

  const [settingForm, setSettingForm] = useState({
    setting_key: '',
    setting_value: '',
    category: 'global',
    description: ''
  });

  const [pageForm, setPageForm] = useState({
    page_path: '',
    meta_title: '',
    meta_description: '',
    meta_keywords: [] as string[],
    og_title: '',
    og_description: '',
    og_image: '',
    canonical_url: '',
    is_active: true
  });

  const [keywordInput, setKeywordInput] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [settingsRes, pagesRes] = await Promise.all([
        supabase.from('seo_settings').select('*').order('category, setting_key'),
        supabase.from('page_seo').select('*').order('page_path')
      ]);

      if (settingsRes.error) throw settingsRes.error;
      if (pagesRes.error) throw pagesRes.error;

      setSeoSettings(settingsRes.data || []);
      setPageSettings(pagesRes.data || []);
    } catch (error: any) {
      console.error('Error fetching SEO data:', error);
      toast.error('Failed to fetch SEO data');
    } finally {
      setLoading(false);
    }
  };

  const saveSetting = async () => {
    if (!settingForm.setting_key.trim()) {
      toast.error('Setting key is required');
      return;
    }

    setActionLoading({ saveSetting: true });

    try {
      let parsedValue;
      try {
        parsedValue = JSON.parse(settingForm.setting_value);
      } catch {
        parsedValue = settingForm.setting_value;
      }

      const settingData = {
        setting_key: settingForm.setting_key,
        setting_value: parsedValue,
        category: settingForm.category,
        description: settingForm.description
      };

      if (editingSetting) {
        const { error } = await supabase
          .from('seo_settings')
          .update(settingData)
          .eq('id', editingSetting.id);
        if (error) throw error;
        toast.success('SEO setting updated');
      } else {
        const { error } = await supabase
          .from('seo_settings')
          .insert(settingData);
        if (error) throw error;
        toast.success('SEO setting created');
      }

      await fetchData();
      closeSettingDialog();
    } catch (error: any) {
      console.error('Error saving SEO setting:', error);
      toast.error('Failed to save SEO setting');
    } finally {
      setActionLoading({ saveSetting: false });
    }
  };

  const savePage = async () => {
    if (!pageForm.page_path.trim()) {
      toast.error('Page path is required');
      return;
    }

    setActionLoading({ savePage: true });

    try {
      const pageData = {
        page_path: pageForm.page_path,
        meta_title: pageForm.meta_title || null,
        meta_description: pageForm.meta_description || null,
        meta_keywords: pageForm.meta_keywords,
        og_title: pageForm.og_title || null,
        og_description: pageForm.og_description || null,
        og_image: pageForm.og_image || null,
        canonical_url: pageForm.canonical_url || null,
        is_active: pageForm.is_active
      };

      if (editingPage) {
        const { error } = await supabase
          .from('page_seo')
          .update(pageData)
          .eq('id', editingPage.id);
        if (error) throw error;
        toast.success('Page SEO updated');
      } else {
        const { error } = await supabase
          .from('page_seo')
          .insert(pageData);
        if (error) throw error;
        toast.success('Page SEO created');
      }

      await fetchData();
      closePageDialog();
    } catch (error: any) {
      console.error('Error saving page SEO:', error);
      toast.error('Failed to save page SEO');
    } finally {
      setActionLoading({ savePage: false });
    }
  };

  const deleteSetting = async (setting: SEOSetting) => {
    if (!confirm('Are you sure you want to delete this SEO setting?')) return;

    setActionLoading({ [`deleteSetting_${setting.id}`]: true });

    try {
      const { error } = await supabase
        .from('seo_settings')
        .delete()
        .eq('id', setting.id);

      if (error) throw error;
      toast.success('SEO setting deleted');
      await fetchData();
    } catch (error: any) {
      console.error('Error deleting SEO setting:', error);
      toast.error('Failed to delete SEO setting');
    } finally {
      setActionLoading({ [`deleteSetting_${setting.id}`]: false });
    }
  };

  const deletePage = async (page: PageSEO) => {
    if (!confirm('Are you sure you want to delete this page SEO?')) return;

    setActionLoading({ [`deletePage_${page.id}`]: true });

    try {
      const { error } = await supabase
        .from('page_seo')
        .delete()
        .eq('id', page.id);

      if (error) throw error;
      toast.success('Page SEO deleted');
      await fetchData();
    } catch (error: any) {
      console.error('Error deleting page SEO:', error);
      toast.error('Failed to delete page SEO');
    } finally {
      setActionLoading({ [`deletePage_${page.id}`]: false });
    }
  };

  const openSettingDialog = (setting?: SEOSetting) => {
    if (setting) {
      setEditingSetting(setting);
      setSettingForm({
        setting_key: setting.setting_key,
        setting_value: typeof setting.setting_value === 'object' 
          ? JSON.stringify(setting.setting_value, null, 2)
          : String(setting.setting_value),
        category: setting.category,
        description: setting.description || ''
      });
    } else {
      setEditingSetting(null);
      setSettingForm({
        setting_key: '',
        setting_value: '',
        category: 'global',
        description: ''
      });
    }
    setIsSettingDialogOpen(true);
  };

  const closeSettingDialog = () => {
    setIsSettingDialogOpen(false);
    setEditingSetting(null);
  };

  const openPageDialog = (page?: PageSEO) => {
    if (page) {
      setEditingPage(page);
      setPageForm({
        page_path: page.page_path,
        meta_title: page.meta_title || '',
        meta_description: page.meta_description || '',
        meta_keywords: page.meta_keywords || [],
        og_title: page.og_title || '',
        og_description: page.og_description || '',
        og_image: page.og_image || '',
        canonical_url: page.canonical_url || '',
        is_active: page.is_active ?? true
      });
    } else {
      setEditingPage(null);
      setPageForm({
        page_path: '',
        meta_title: '',
        meta_description: '',
        meta_keywords: [],
        og_title: '',
        og_description: '',
        og_image: '',
        canonical_url: '',
        is_active: true
      });
    }
    setIsPageDialogOpen(true);
  };

  const closePageDialog = () => {
    setIsPageDialogOpen(false);
    setEditingPage(null);
    setKeywordInput('');
  };

  const addKeyword = () => {
    if (keywordInput.trim() && !pageForm.meta_keywords.includes(keywordInput.trim())) {
      setPageForm({
        ...pageForm,
        meta_keywords: [...pageForm.meta_keywords, keywordInput.trim()]
      });
      setKeywordInput('');
    }
  };

  const removeKeyword = (index: number) => {
    setPageForm({
      ...pageForm,
      meta_keywords: pageForm.meta_keywords.filter((_, i) => i !== index)
    });
  };

  const settingColumns = [
    {
      key: 'setting_key',
      header: 'Key',
      render: (setting: SEOSetting) => (
        <span className="font-mono text-sm">{setting.setting_key}</span>
      )
    },
    {
      key: 'setting_value',
      header: 'Value',
      render: (setting: SEOSetting) => (
        <div className="max-w-md">
          <pre className="text-sm bg-muted p-2 rounded text-wrap">
            {typeof setting.setting_value === 'object' 
              ? JSON.stringify(setting.setting_value, null, 2)
              : String(setting.setting_value)
            }
          </pre>
        </div>
      )
    },
    {
      key: 'category',
      header: 'Category',
      render: (setting: SEOSetting) => (
        <Badge variant="outline">{setting.category}</Badge>
      )
    },
    {
      key: 'description',
      header: 'Description',
      render: (setting: SEOSetting) => setting.description || 'No description'
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (setting: SEOSetting) => (
        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={() => openSettingDialog(setting)}>
            <Edit className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteSetting(setting)}
            disabled={actionLoading[`deleteSetting_${setting.id}`]}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      )
    }
  ];

  const pageColumns = [
    {
      key: 'page_path',
      header: 'Page Path',
      render: (page: PageSEO) => (
        <span className="font-mono text-sm">{page.page_path}</span>
      )
    },
    {
      key: 'meta_title',
      header: 'Meta Title',
      render: (page: PageSEO) => page.meta_title || 'No title'
    },
    {
      key: 'meta_description',
      header: 'Meta Description',
      render: (page: PageSEO) => (
        <div className="max-w-md">
          <p className="text-sm truncate">{page.meta_description || 'No description'}</p>
        </div>
      )
    },
    {
      key: 'keywords_count',
      header: 'Keywords',
      render: (page: PageSEO) => (
        <Badge variant="secondary">
          {page.meta_keywords?.length || 0} keywords
        </Badge>
      )
    },
    {
      key: 'is_active',
      header: 'Active',
      render: (page: PageSEO) => (
        <Badge variant={page.is_active ? 'default' : 'secondary'}>
          {page.is_active ? 'Active' : 'Inactive'}
        </Badge>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (page: PageSEO) => (
        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={() => openPageDialog(page)}>
            <Edit className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deletePage(page)}
            disabled={actionLoading[`deletePage_${page.id}`]}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner size={32} text="Loading SEO settings..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Search className="w-5 h-5" />
        <h2 className="text-2xl font-bold">SEO Settings</h2>
      </div>

      <Tabs defaultValue="global" className="space-y-6">
        <TabsList>
          <TabsTrigger value="global">Global Settings</TabsTrigger>
          <TabsTrigger value="pages">Page SEO</TabsTrigger>
        </TabsList>

        <TabsContent value="global">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                <CardTitle>Global SEO Settings</CardTitle>
              </div>
              <Button onClick={() => openSettingDialog()} className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add Setting
              </Button>
            </CardHeader>
            <CardContent>
              <DataTable
                data={seoSettings}
                columns={settingColumns}
                emptyStateIcon={Settings}
                emptyStateTitle="No SEO settings found"
                emptyStateDescription="Add global SEO settings for your website"
                emptyStateAction="Add Setting"
                onEmptyStateAction={() => openSettingDialog()}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pages">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                <CardTitle>Page SEO Settings</CardTitle>
              </div>
              <Button onClick={() => openPageDialog()} className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add Page SEO
              </Button>
            </CardHeader>
            <CardContent>
              <DataTable
                data={pageSettings}
                columns={pageColumns}
                emptyStateIcon={FileText}
                emptyStateTitle="No page SEO settings found"
                emptyStateDescription="Add SEO settings for specific pages"
                emptyStateAction="Add Page SEO"
                onEmptyStateAction={() => openPageDialog()}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Global Settings Dialog */}
      <Dialog open={isSettingDialogOpen} onOpenChange={setIsSettingDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingSetting ? 'Edit SEO Setting' : 'Add SEO Setting'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Setting Key *</Label>
              <Input
                value={settingForm.setting_key}
                onChange={(e) => setSettingForm({ ...settingForm, setting_key: e.target.value })}
                placeholder="e.g., site_title, default_description"
              />
            </div>

            <div>
              <Label>Setting Value *</Label>
              <Textarea
                value={settingForm.setting_value}
                onChange={(e) => setSettingForm({ ...settingForm, setting_value: e.target.value })}
                placeholder="Enter value (can be JSON for complex objects)"
                rows={4}
              />
            </div>

            <div>
              <Label>Category</Label>
              <select
                value={settingForm.category}
                onChange={(e) => setSettingForm({ ...settingForm, category: e.target.value })}
                className="w-full p-2 border rounded-md"
              >
                <option value="global">Global</option>
                <option value="social">Social Media</option>
                <option value="analytics">Analytics</option>
                <option value="schema">Schema Markup</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <Label>Description</Label>
              <Input
                value={settingForm.description}
                onChange={(e) => setSettingForm({ ...settingForm, description: e.target.value })}
                placeholder="Brief description of this setting"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={closeSettingDialog}>
              Cancel
            </Button>
            <Button onClick={saveSetting} disabled={actionLoading.saveSetting}>
              {actionLoading.saveSetting ? 'Saving...' : editingSetting ? 'Update' : 'Create'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Page SEO Dialog */}
      <Dialog open={isPageDialogOpen} onOpenChange={setIsPageDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingPage ? 'Edit Page SEO' : 'Add Page SEO'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Page Path *</Label>
              <Input
                value={pageForm.page_path}
                onChange={(e) => setPageForm({ ...pageForm, page_path: e.target.value })}
                placeholder="/about, /contact, /services"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Meta Title</Label>
                <Input
                  value={pageForm.meta_title}
                  onChange={(e) => setPageForm({ ...pageForm, meta_title: e.target.value })}
                  placeholder="Page title (50-60 characters)"
                />
              </div>

              <div>
                <Label>Canonical URL</Label>
                <Input
                  value={pageForm.canonical_url}
                  onChange={(e) => setPageForm({ ...pageForm, canonical_url: e.target.value })}
                  placeholder="https://example.com/page"
                />
              </div>
            </div>

            <div>
              <Label>Meta Description</Label>
              <Textarea
                value={pageForm.meta_description}
                onChange={(e) => setPageForm({ ...pageForm, meta_description: e.target.value })}
                placeholder="Page description (150-160 characters)"
                rows={3}
              />
            </div>

            <div>
              <Label>Meta Keywords</Label>
              <div className="space-y-2">
                <div className="flex gap-2">
                  <Input
                    value={keywordInput}
                    onChange={(e) => setKeywordInput(e.target.value)}
                    placeholder="Enter keyword and press Add"
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addKeyword())}
                  />
                  <Button type="button" onClick={addKeyword} size="sm">
                    Add
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {pageForm.meta_keywords.map((keyword, index) => (
                    <Badge key={index} variant="secondary" className="flex items-center gap-1">
                      {keyword}
                      <button
                        type="button"
                        onClick={() => removeKeyword(index)}
                        className="ml-1 hover:text-destructive"
                      >
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Open Graph Title</Label>
                <Input
                  value={pageForm.og_title}
                  onChange={(e) => setPageForm({ ...pageForm, og_title: e.target.value })}
                  placeholder="Social media title"
                />
              </div>

              <div>
                <Label>Open Graph Image URL</Label>
                <Input
                  value={pageForm.og_image}
                  onChange={(e) => setPageForm({ ...pageForm, og_image: e.target.value })}
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            </div>

            <div>
              <Label>Open Graph Description</Label>
              <Textarea
                value={pageForm.og_description}
                onChange={(e) => setPageForm({ ...pageForm, og_description: e.target.value })}
                placeholder="Social media description"
                rows={2}
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={closePageDialog}>
              Cancel
            </Button>
            <Button onClick={savePage} disabled={actionLoading.savePage}>
              {actionLoading.savePage ? 'Saving...' : editingPage ? 'Update' : 'Create'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};