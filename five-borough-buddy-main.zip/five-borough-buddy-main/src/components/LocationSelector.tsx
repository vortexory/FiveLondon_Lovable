import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, MapPin } from 'lucide-react';
import { generateLocationSEOUrl } from '@/utils/seoUtils';

interface Location {
  id: string;
  name: string;
  description: string | null;
  seo_path: string | null;
}

interface LocationSelectorProps {
  selectedLocation: string;
  onLocationChange: (location: string) => void;
}

export const LocationSelector: React.FC<LocationSelectorProps> = ({
  selectedLocation,
  onLocationChange,
}) => {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const { data, error } = await supabase
        .from('locations')
        .select('*')
        .eq('is_active', true)
        .order('order_index');

      if (error) throw error;
      setLocations(data || []);
    } catch (error) {
      console.error('Error fetching locations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLocationSelect = (locationName: string) => {
    // Single-select: deselect if clicking the same location
    if (selectedLocation === locationName) {
      onLocationChange('');
    } else {
      onLocationChange(locationName);
    }
  };

  const selectedLocationData = locations.find(loc => loc.name === selectedLocation);

  if (loading) {
    return (
      <div className="space-y-2">
        <label className="text-sm font-medium">Location</label>
        <div className="text-sm text-muted-foreground">Loading locations...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <MapPin className="h-4 w-4" />
        <label className="text-sm font-medium">Location</label>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {locations.map((location) => (
          <div
            key={location.id}
            onClick={() => handleLocationSelect(location.name)}
            className={`
              cursor-pointer rounded-md border px-4 py-3 text-left transition-colors
              ${selectedLocation === location.name 
                ? 'bg-primary text-primary-foreground border-primary' 
                : 'bg-background border-input hover:bg-accent hover:text-accent-foreground'
              }
            `}
          >
            <div className="flex flex-col items-start w-full">
              <span className="font-medium">{location.name}</span>
              {location.description && (
                <span className="text-xs opacity-70 mt-1 line-clamp-2">{location.description}</span>
              )}
            </div>
          </div>
        ))}
      </div>

      {selectedLocation && !selectedLocationData && (
        <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-sm text-yellow-800">
            Note: "{selectedLocation}" is not in the predefined locations list. 
            Consider selecting from available options above for proper SEO integration.
          </p>
        </div>
      )}

      {selectedLocationData && selectedLocationData.seo_path && (
        <div className="mt-4 p-3 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-2 text-sm">
            <Badge variant="secondary" className="gap-1">
              <ExternalLink className="h-3 w-3" />
              SEO Connected
            </Badge>
            <span className="text-muted-foreground">
              Links to: <a 
                href={generateLocationSEOUrl(selectedLocationData.seo_path)}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs bg-background px-1 py-0.5 rounded text-primary hover:text-primary/80 underline"
              >
                {generateLocationSEOUrl(selectedLocationData.seo_path)}
              </a>
            </span>
          </div>
        </div>
      )}
    </div>
  );
};