import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { LoadingSpinner } from './LoadingSpinner';
import { ImageUpload } from './ImageUpload';
import { MultiImageUpload } from './MultiImageUpload';
import { CharacteristicsSelector } from './CharacteristicsSelector';
import { LocationSelector } from './LocationSelector';
import { ModelSEOPreview } from './ModelSEOPreview';
import { User, MapPin, Camera, Settings, Eye, Globe } from 'lucide-react';

interface Model {
  id?: string;
  name: string;
  location?: string | null;
  age?: number | null;
  availability?: string | null;
  members_only?: boolean | null;
  all_photos_public?: boolean | null;
  face_visible?: boolean | null;
  description?: string | null;
  height?: string | null;
  measurements?: string | null;
  hair?: string | null;
  eyes?: string | null;
  nationality?: string | null;
  education?: string | null;
  price?: string | null;
  image?: string | null;
  services?: string[] | null;
  characteristics?: string[] | null;
  interests?: string[] | null;
  visibility_type?: string | null;
}

interface ModelFormProps {
  isOpen: boolean;
  onClose: () => void;
  model?: Model | null;
  onSave: () => void;
}

interface UploadedImage {
  id: string;
  url: string;
  audience: 'public' | 'members_only';
  faceVisible: boolean;
}

type ModelVisibilityType = 'public' | 'mixed' | 'members_only';

export const ModelForm: React.FC<ModelFormProps> = ({
  isOpen,
  onClose,
  model,
  onSave
}) => {
  const [formData, setFormData] = useState<Model>({
    name: '',
    location: '',
    age: undefined,
    availability: '',
    members_only: false,
    description: '',
    height: '',
    measurements: '',
    hair: '',
    eyes: '',
    nationality: '',
    education: '',
    price: '',
    image: '',
    services: [],
    characteristics: [],
    interests: []
  });
  const [loading, setLoading] = useState(false);
  const [servicesInput, setServicesInput] = useState('');
  const [selectedCharacteristics, setSelectedCharacteristics] = useState<string[]>([]);
  const [interestsInput, setInterestsInput] = useState('');
  const [visibilityType, setVisibilityType] = useState<ModelVisibilityType>('public');
  const [additionalImages, setAdditionalImages] = useState<UploadedImage[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const handleClose = () => {
    if (hasUnsavedChanges) {
      const confirmed = window.confirm(
        'You have unsaved changes. Are you sure you want to close without saving?'
      );
      if (!confirmed) return;
    }
    setHasUnsavedChanges(false);
    onClose();
  };

  useEffect(() => {
    if (isOpen) {
      if (model) {
        setFormData(model);
        setServicesInput(model.services?.join(', ') || '');
        setSelectedCharacteristics(model.characteristics || []);
        setInterestsInput(model.interests?.join(', ') || '');
        
        // Determine visibility type from model data
        if (model.visibility_type) {
          setVisibilityType(model.visibility_type as ModelVisibilityType);
        } else if (model.members_only) {
          setVisibilityType('members_only');
        } else if (model.all_photos_public) {
          setVisibilityType('public');
        } else {
          setVisibilityType('mixed');
        }
        setHasUnsavedChanges(false);
      } else {
        // Reset form for new model
        setFormData({
          name: '',
          location: '',
          age: undefined,
          availability: '',
          members_only: false,
          description: '',
          height: '',
          measurements: '',
          hair: '',
          eyes: '',
          nationality: '',
          education: '',
          price: '',
          image: '',
          services: [],
          characteristics: [],
          interests: []
        });
        setServicesInput('');
        setSelectedCharacteristics([]);
        setInterestsInput('');
        setVisibilityType('public');
        setAdditionalImages([]);
        setErrors({});
        setHasUnsavedChanges(false);
      }
      setLoading(false);
    }
  }, [model, isOpen]);

  const handleInputChange = useCallback((field: keyof Model, value: any) => {
    console.log('handleInputChange called:', field, value);
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    setHasUnsavedChanges(true);
    console.log('Unsaved changes set to true');
    
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  }, [errors]);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name?.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (formData.age && (formData.age < 18 || formData.age > 60)) {
      newErrors.age = 'Age must be between 18 and 60';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const determineModelVisibilityFromPhotos = (images: UploadedImage[]): ModelVisibilityType => {
    if (images.length === 0) return 'public';
    
    const publicImages = images.filter(img => img.audience === 'public');
    const membersOnlyImages = images.filter(img => img.audience === 'members_only');
    
    if (publicImages.length > 0 && membersOnlyImages.length > 0) {
      return 'mixed';
    } else if (membersOnlyImages.length > 0) {
      return 'members_only';
    } else {
      return 'public';
    }
  };

  const determineModelVisibilityFromAllPhotos = (mainImage: string, additionalImages: UploadedImage[]): ModelVisibilityType => {
    const allImages = [...additionalImages];
    if (mainImage) {
      allImages.unshift({
        id: 'main',
        url: mainImage,
        audience: 'public',
        faceVisible: true
      });
    }
    
    return determineModelVisibilityFromPhotos(allImages);
  };

  const handleAdditionalImagesChange = useCallback((images: UploadedImage[]) => {
    setAdditionalImages(images);
    setHasUnsavedChanges(true);
    const newVisibilityType = determineModelVisibilityFromAllPhotos(formData.image || '', images);
    setVisibilityType(newVisibilityType);
  }, [formData.image]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors below');
      return;
    }

    setLoading(true);

    try {
      const services = servicesInput.split(',').map(s => s.trim()).filter(s => s);
      const interests = interestsInput.split(',').map(s => s.trim()).filter(s => s);

      const modelData = {
        ...formData,
        name: formData.name, // Ensure name is not undefined
        services,
        characteristics: selectedCharacteristics,
        interests,
        visibility_type: visibilityType,
        members_only: visibilityType === 'members_only',
        all_photos_public: visibilityType === 'public'
      };

      let savedModel;
      if (model?.id) {
        const { data, error } = await supabase
          .from('models')
          .update(modelData)
          .eq('id', model.id)
          .select()
          .single();

        if (error) throw error;
        savedModel = data;
        toast.success('Model updated successfully');
      } else {
        const { data, error } = await supabase
          .from('models')
          .insert(modelData)
          .select()
          .single();

        if (error) throw error;
        savedModel = data;
        toast.success('Model created successfully');
      }

      // Save additional images to model_gallery
      if (additionalImages.length > 0 && savedModel) {
        // Clear existing gallery images if updating
        if (model?.id) {
          await supabase
            .from('model_gallery')
            .delete()
            .eq('model_id', savedModel.id);
        }

        // Insert new gallery images
        const galleryImages = additionalImages.map((img, index) => ({
          model_id: savedModel.id,
          image_url: img.url,
          order_index: index,
          visibility: img.audience,
          caption: `Image ${index + 1}`
        }));

        const { error: galleryError } = await supabase
          .from('model_gallery')
          .insert(galleryImages);

        if (galleryError) {
          console.error('Error saving gallery images:', galleryError);
        }

        // Update model visibility based on all photos
        const finalVisibilityType = determineModelVisibilityFromAllPhotos(formData.image || '', additionalImages);
        const { error: updateError } = await supabase
          .from('models')
          .update({
            visibility_type: finalVisibilityType,
            members_only: finalVisibilityType === 'members_only',
            all_photos_public: finalVisibilityType === 'public'
          })
          .eq('id', savedModel.id);

        if (updateError) {
          console.error('Error updating model visibility:', updateError);
        }
      }

      setHasUnsavedChanges(false);
      onSave();
      onClose();
    } catch (error: any) {
      console.error('Error saving model:', error);
      toast.error(error.message || 'Failed to save model');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-6xl h-[95vh] p-0 gap-0 flex flex-col">
        <DialogHeader className="px-6 py-4 border-b bg-muted/30 flex-shrink-0">
          <DialogTitle className="text-xl font-semibold flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <User className="h-5 w-5 text-primary" />
            </div>
            {model ? 'Edit Model Profile' : 'Create New Model'}
            {hasUnsavedChanges && (
              <Badge variant="outline" className="ml-2 bg-yellow-50 text-yellow-700 border-yellow-200">
                Unsaved Changes
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 min-h-0 overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center h-full p-8">
              <LoadingSpinner />
              <span className="ml-2">Processing...</span>
            </div>
          ) : (
            <div className="h-full overflow-y-auto overflow-x-hidden">
              <div className="p-6">
                <form onSubmit={handleSubmit} className="space-y-8 max-w-none">
                {/* Basic Information Section */}
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <User className="h-5 w-5 text-primary" />
                        Basic Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="name" className="text-sm font-medium">
                            Name <span className="text-destructive">*</span>
                          </Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            placeholder="Enter model name"
                            className={`h-11 ${errors.name ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                            required
                          />
                          {errors.name && (
                            <p className="text-sm text-destructive mt-1">{errors.name}</p>
                          )}
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="age" className="text-sm font-medium">Age</Label>
                          <Input
                            id="age"
                            type="number"
                            value={formData.age || ''}
                            onChange={(e) => handleInputChange('age', e.target.value ? parseInt(e.target.value) : undefined)}
                            placeholder="Enter age"
                            className={`h-11 ${errors.age ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                            min="18"
                            max="60"
                          />
                          {errors.age && (
                            <p className="text-sm text-destructive mt-1">{errors.age}</p>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="price" className="text-sm font-medium">Price</Label>
                          <Input
                            id="price"
                            value={formData.price || ''}
                            onChange={(e) => handleInputChange('price', e.target.value)}
                            placeholder="e.g., £200/hour"
                            className="h-11"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="availability" className="text-sm font-medium">Availability</Label>
                          <Input
                            id="availability"
                            value={formData.availability || ''}
                            onChange={(e) => handleInputChange('availability', e.target.value)}
                            placeholder="e.g., Mon-Fri, Weekends"
                            className="h-11"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="description" className="text-sm font-medium">Description</Label>
                        <Textarea
                          id="description"
                          value={formData.description || ''}
                          onChange={(e) => handleInputChange('description', e.target.value)}
                          placeholder="Write a compelling description..."
                          rows={4}
                          className="resize-none"
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Location Section */}
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <MapPin className="h-5 w-5 text-primary" />
                        Location & Coverage
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <LocationSelector
                        selectedLocation={formData.location || ''}
                        onLocationChange={(location) => handleInputChange('location', location)}
                      />
                    </CardContent>
                  </Card>

                  {/* Physical Attributes Section */}
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <User className="h-5 w-5 text-primary" />
                        Physical Attributes
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="height" className="text-sm font-medium">Height</Label>
                          <Input
                            id="height"
                            value={formData.height || ''}
                            onChange={(e) => handleInputChange('height', e.target.value)}
                            placeholder="e.g., 5'6&quot;, 168cm"
                            className="h-11"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="measurements" className="text-sm font-medium">Measurements</Label>
                          <Input
                            id="measurements"
                            value={formData.measurements || ''}
                            onChange={(e) => handleInputChange('measurements', e.target.value)}
                            placeholder="e.g., 34C-24-36"
                            className="h-11"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="hair" className="text-sm font-medium">Hair Color</Label>
                          <Input
                            id="hair"
                            value={formData.hair || ''}
                            onChange={(e) => handleInputChange('hair', e.target.value)}
                            placeholder="e.g., Blonde, Brunette"
                            className="h-11"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="eyes" className="text-sm font-medium">Eye Color</Label>
                          <Input
                            id="eyes"
                            value={formData.eyes || ''}
                            onChange={(e) => handleInputChange('eyes', e.target.value)}
                            placeholder="e.g., Blue, Brown, Green"
                            className="h-11"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="nationality" className="text-sm font-medium">Nationality</Label>
                          <Input
                            id="nationality"
                            value={formData.nationality || ''}
                            onChange={(e) => handleInputChange('nationality', e.target.value)}
                            placeholder="e.g., British, European"
                            className="h-11"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="education" className="text-sm font-medium">Education</Label>
                          <Input
                            id="education"
                            value={formData.education || ''}
                            onChange={(e) => handleInputChange('education', e.target.value)}
                            placeholder="e.g., University graduate"
                            className="h-11"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Photos Section */}
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Camera className="h-5 w-5 text-primary" />
                        Photo Gallery
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div>
                          <ImageUpload
                            bucket="model-images"
                            value={formData.image || ''}
                            onChange={(url) => {
                              console.log('Profile image onChange called:', url);
                              handleInputChange('image', url);
                            }}
                            label="Profile Image"
                          />
                        </div>
                        <div>
                          <MultiImageUpload
                            bucket="model-images"
                            images={additionalImages}
                            onChange={handleAdditionalImagesChange}
                            label="Additional Photos"
                            modelVisibilityType={visibilityType}
                            maxImages={20}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Services & Characteristics Section */}
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Settings className="h-5 w-5 text-primary" />
                        Services & Characteristics
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="services" className="text-sm font-medium">Services</Label>
                        <Input
                          id="services"
                          value={servicesInput}
                          onChange={(e) => {
                            setServicesInput(e.target.value);
                            setHasUnsavedChanges(true);
                          }}
                          placeholder="e.g., Dinner dates, Travel companion, Social events"
                          className="h-11"
                        />
                        <p className="text-xs text-muted-foreground">Separate multiple services with commas</p>
                      </div>

                      <CharacteristicsSelector
                        selectedCharacteristics={selectedCharacteristics}
                        onCharacteristicsChange={(characteristics) => {
                          setSelectedCharacteristics(characteristics);
                          setHasUnsavedChanges(true);
                        }}
                      />

                      <div className="space-y-2">
                        <Label htmlFor="interests" className="text-sm font-medium">Interests</Label>
                        <Input
                          id="interests"
                          value={interestsInput}
                          onChange={(e) => {
                            setInterestsInput(e.target.value);
                            setHasUnsavedChanges(true);
                          }}
                          placeholder="e.g., Art, Music, Travel, Literature"
                          className="h-11"
                        />
                        <p className="text-xs text-muted-foreground">Separate multiple interests with commas</p>
                      </div>
                    </CardContent>
                  </Card>

                  {/* SEO Preview Section */}
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Globe className="h-5 w-5 text-primary" />
                        SEO Integration
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ModelSEOPreview 
                        model={{
                          id: model?.id || 'new',
                          name: formData.name,
                          location: formData.location || undefined,
                          characteristics: selectedCharacteristics,
                          description: formData.description || undefined,
                          image: formData.image || undefined,
                          services: formData.services || undefined,
                          price: formData.price || undefined,
                          availability: formData.availability || undefined
                        }} 
                      />
                    </CardContent>
                  </Card>

                  {/* Visibility Status Section */}
                  <Card>
                    <CardHeader className="pb-4">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Eye className="h-5 w-5 text-primary" />
                        Visibility Status
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="p-4 rounded-lg bg-muted/50 border">
                        <div className="flex items-center gap-3 mb-3">
                          <Badge 
                            variant={
                              visibilityType === 'public' ? 'default' : 
                              visibilityType === 'members_only' ? 'secondary' : 
                              'outline'
                            }
                            className="text-sm"
                          >
                            {visibilityType === 'public' && '🌍 Public'}
                            {visibilityType === 'members_only' && '🔒 Members Only'}
                            {visibilityType === 'mixed' && '⚡ Mixed Visibility'}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          {visibilityType === 'public' && (
                            <p>✓ All photos will be visible to everyone</p>
                          )}
                          {visibilityType === 'members_only' && (
                            <p>✓ All photos will be visible only to logged-in members</p>
                          )}
                          {visibilityType === 'mixed' && (
                            <p>✓ Some photos are public, others are members-only</p>
                          )}
                          <p className="text-xs opacity-70">
                            Status is automatically determined based on photo visibility settings.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Form Actions */}
                  <div className="flex flex-col sm:flex-row justify-end gap-3 pt-6 border-t">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={handleClose}
                      disabled={loading}
                      className="order-2 sm:order-1"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={loading || !formData.name?.trim()}
                      className="order-1 sm:order-2 min-w-32"
                    >
                      {loading ? (
                        <div className="flex items-center gap-2">
                          <LoadingSpinner size={16} text="" />
                          <span>Saving...</span>
                        </div>
                      ) : (
                        model ? 'Update Model' : 'Create Model'
                      )}
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};