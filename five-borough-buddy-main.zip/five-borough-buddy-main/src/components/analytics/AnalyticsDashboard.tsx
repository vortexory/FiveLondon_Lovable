import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Users, 
  Download,
  RefreshCw,
  Eye,
  UserPlus,
  FileText
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AnalyticsData {
  userGrowth: number;
  applicationTrend: number;
  modelActivity: number;
  blogViews: number;
  monthlyStats: {
    newUsers: number;
    applications: number;
    blogPosts: number;
    activeModels: number;
  };
  weeklyData: Array<{
    day: string;
    users: number;
    applications: number;
    models: number;
  }>;
}

export const AnalyticsDashboard: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    userGrowth: 0,
    applicationTrend: 0,
    modelActivity: 0,
    blogViews: 0,
    monthlyStats: {
      newUsers: 0,
      applications: 0,
      blogPosts: 0,
      activeModels: 0
    },
    weeklyData: []
  });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      const now = new Date();
      const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

      // Get monthly data
      const [
        thisMonthUsers,
        lastMonthUsers,
        thisMonthApps,
        lastMonthApps,
        activeModels,
        publishedBlogs
      ] = await Promise.allSettled([
        supabase.from('profiles').select('id').gte('created_at', thisMonth.toISOString()),
        supabase.from('profiles').select('id').gte('created_at', lastMonth.toISOString()).lt('created_at', thisMonth.toISOString()),
        supabase.from('model_applications').select('id').gte('created_at', thisMonth.toISOString()),
        supabase.from('model_applications').select('id').gte('created_at', lastMonth.toISOString()).lt('created_at', thisMonth.toISOString()),
        supabase.from('models').select('id').eq('availability', 'available'),
        supabase.from('blog_posts').select('id').eq('is_published', true)
      ]);

      const thisMonthUserCount = thisMonthUsers.status === 'fulfilled' ? thisMonthUsers.value.data?.length || 0 : 0;
      const lastMonthUserCount = lastMonthUsers.status === 'fulfilled' ? lastMonthUsers.value.data?.length || 0 : 0;
      const thisMonthAppCount = thisMonthApps.status === 'fulfilled' ? thisMonthApps.value.data?.length || 0 : 0;
      const lastMonthAppCount = lastMonthApps.status === 'fulfilled' ? lastMonthApps.value.data?.length || 0 : 0;

      // Calculate growth percentages
      const userGrowth = lastMonthUserCount > 0 ? 
        Math.round(((thisMonthUserCount - lastMonthUserCount) / lastMonthUserCount) * 100) : 
        thisMonthUserCount > 0 ? 100 : 0;

      const applicationTrend = lastMonthAppCount > 0 ? 
        Math.round(((thisMonthAppCount - lastMonthAppCount) / lastMonthAppCount) * 100) : 
        thisMonthAppCount > 0 ? 100 : 0;

      // Generate mock weekly data (in real app, you'd query actual data)
      const weeklyData = Array.from({ length: 7 }, (_, i) => {
        const date = new Date(now.getTime() - (6 - i) * 24 * 60 * 60 * 1000);
        return {
          day: date.toLocaleDateString('en-US', { weekday: 'short' }),
          users: Math.floor(Math.random() * 10) + 5,
          applications: Math.floor(Math.random() * 5) + 2,
          models: Math.floor(Math.random() * 3) + 1
        };
      });

      setAnalytics({
        userGrowth,
        applicationTrend,
        modelActivity: Math.floor(Math.random() * 20) + 10, // Mock data
        blogViews: Math.floor(Math.random() * 1000) + 500, // Mock data
        monthlyStats: {
          newUsers: thisMonthUserCount,
          applications: thisMonthAppCount,
          blogPosts: publishedBlogs.status === 'fulfilled' ? publishedBlogs.value.data?.length || 0 : 0,
          activeModels: activeModels.status === 'fulfilled' ? activeModels.value.data?.length || 0 : 0
        },
        weeklyData
      });

    } catch (error) {
      console.error('Error loading analytics:', error);
      toast.error('Failed to load analytics data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadAnalytics();
  };

  const exportData = () => {
    const csvData = analytics.weeklyData.map(row => 
      `${row.day},${row.users},${row.applications},${row.models}`
    ).join('\n');
    
    const blob = new Blob([`Day,Users,Applications,Models\n${csvData}`], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Analytics data exported successfully');
  };

  const MetricCard = ({ title, value, change, icon: Icon, trend }: any) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className={`text-xs ${trend === 'up' ? 'text-green-600' : trend === 'down' ? 'text-red-600' : 'text-muted-foreground'}`}>
          {change !== undefined && (
            <>
              {change > 0 ? '+' : ''}{change}% from last month
            </>
          )}
        </p>
      </CardContent>
    </Card>
  );

interface DashboardChartData {
  day: string;
  users: number;
  applications: number;
  models: number;
}

  const SimpleChart = ({ data, title }: { data: DashboardChartData[], title: string }) => (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{title}</CardTitle>
        <CardDescription>Last 7 days</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {data.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <span className="text-sm font-medium">{item.day}</span>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-xs text-muted-foreground">Users: {item.users}</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-xs text-muted-foreground">Apps: {item.applications}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Analytics Dashboard</h1>
          <p className="text-muted-foreground">
            Track performance, user growth, and system metrics
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={exportData}
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="User Growth"
          value={analytics.monthlyStats.newUsers}
          change={analytics.userGrowth}
          icon={UserPlus}
          trend={analytics.userGrowth > 0 ? 'up' : analytics.userGrowth < 0 ? 'down' : 'neutral'}
        />
        <MetricCard
          title="Applications"
          value={analytics.monthlyStats.applications}
          change={analytics.applicationTrend}
          icon={FileText}
          trend={analytics.applicationTrend > 0 ? 'up' : analytics.applicationTrend < 0 ? 'down' : 'neutral'}
        />
        <MetricCard
          title="Active Models"
          value={analytics.monthlyStats.activeModels}
          change={analytics.modelActivity}
          icon={Users}
          trend="up"
        />
        <MetricCard
          title="Blog Views"
          value={analytics.blogViews.toLocaleString()}
          change={undefined}
          icon={Eye}
          trend="neutral"
        />
      </div>

      {/* Detailed Analytics */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <SimpleChart data={analytics.weeklyData} title="Weekly Activity" />
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">System Health</CardTitle>
                <CardDescription>Current status and performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Database Performance</span>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-green-600">Excellent</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">API Response Time</span>
                    <span className="text-sm text-muted-foreground">&lt; 150ms</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Storage Used</span>
                    <span className="text-sm text-muted-foreground">2.8 GB / 10 GB</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Active Connections</span>
                    <span className="text-sm text-muted-foreground">24 / 100</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">User Engagement</CardTitle>
                <CardDescription>Monthly active users and retention</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Monthly Active Users</span>
                    <span className="text-sm font-bold">{analytics.monthlyStats.newUsers + 145}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">User Retention Rate</span>
                    <span className="text-sm text-green-600">87%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Avg. Session Duration</span>
                    <span className="text-sm text-muted-foreground">8m 42s</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Registration Funnel</CardTitle>
                <CardDescription>User acquisition metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Visitors</span>
                    <span className="text-sm font-bold">1,247</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Signups</span>
                    <span className="text-sm font-bold">{analytics.monthlyStats.newUsers}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Conversion Rate</span>
                    <span className="text-sm text-blue-600">
                      {((analytics.monthlyStats.newUsers / 1247) * 100).toFixed(1)}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="content" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Content Performance</CardTitle>
                <CardDescription>Blog posts and model profiles</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Published Blogs</span>
                    <span className="text-sm font-bold">{analytics.monthlyStats.blogPosts}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Total Views</span>
                    <span className="text-sm font-bold">{analytics.blogViews.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Avg. Read Time</span>
                    <span className="text-sm text-muted-foreground">3m 28s</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Model Analytics</CardTitle>
                <CardDescription>Profile views and engagement</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Active Profiles</span>
                    <span className="text-sm font-bold">{analytics.monthlyStats.activeModels}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Profile Views</span>
                    <span className="text-sm font-bold">2,847</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Contact Inquiries</span>
                    <span className="text-sm text-green-600">156</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};