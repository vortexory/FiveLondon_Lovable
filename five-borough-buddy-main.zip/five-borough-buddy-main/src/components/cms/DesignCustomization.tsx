import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  Palette, 
  Type, 
  Save, 
  RefreshCw,
  Eye,
  Paintbrush
} from 'lucide-react';
import { LoadingSpinner } from '@/components/LoadingSpinner';

interface DesignSettings {
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  text_color: string;
  background_color: string;
  button_primary_bg: string;
  button_primary_text: string;
  button_secondary_bg: string;
  button_secondary_text: string;
}

interface ButtonTexts {
  cta_primary: string;
  cta_secondary: string;
  learn_more: string;
  contact_us: string;
  view_models: string;
  book_now: string;
  get_started: string;
  read_more: string;
}

export const DesignCustomization: React.FC = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  const [designSettings, setDesignSettings] = useState<DesignSettings>({
    primary_color: '#1a365d',
    secondary_color: '#2d3748',
    accent_color: '#e53e3e',
    text_color: '#2d3748',
    background_color: '#ffffff',
    button_primary_bg: '#1a365d',
    button_primary_text: '#ffffff',
    button_secondary_bg: '#e2e8f0',
    button_secondary_text: '#2d3748'
  });

  const [buttonTexts, setButtonTexts] = useState<ButtonTexts>({
    cta_primary: 'Get Started',
    cta_secondary: 'Learn More',
    learn_more: 'Learn More',
    contact_us: 'Contact Us',
    view_models: 'View Our Models',
    book_now: 'Book Now',
    get_started: 'Get Started',
    read_more: 'Read More'
  });

  useEffect(() => {
    fetchDesignSettings();
  }, []);

  const fetchDesignSettings = async () => {
    try {
      // Use content_items to store design settings temporarily
      const { data: designData, error: designError } = await supabase
        .from('content_items')
        .select('*')
        .eq('slug', 'design-settings')
        .maybeSingle();

      const { data: buttonData, error: buttonError } = await supabase
        .from('content_items')
        .select('*')
        .eq('slug', 'button-texts')
        .maybeSingle();

      if (designData && !designError && designData.content && typeof designData.content === 'object') {
        setDesignSettings(prev => ({ ...prev, ...(designData.content as any) }));
      }
      
      if (buttonData && !buttonError && buttonData.content && typeof buttonData.content === 'object') {
        setButtonTexts(prev => ({ ...prev, ...(buttonData.content as any) }));
      }
    } catch (error) {
      console.error('Error fetching design settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveDesignSettings = async () => {
    setSaving(true);
    try {
      // Check if design settings exist
      const { data: existingDesign } = await supabase
        .from('content_items')
        .select('id')
        .eq('slug', 'design-settings')
        .maybeSingle();

      const { data: existingButton } = await supabase
        .from('content_items')
        .select('id')
        .eq('slug', 'button-texts')
        .maybeSingle();

      // Save or update design settings
      if (existingDesign) {
        const { error: designError } = await supabase
          .from('content_items')
          .update({
            content: designSettings as any,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingDesign.id);
        
        if (designError) throw designError;
      } else {
        const { error: designError } = await supabase
          .from('content_items')
          .insert({
            title: 'Design Settings',
            slug: 'design-settings',
            content: designSettings as any,
            status: 'published'
          });
        
        if (designError) throw designError;
      }

      // Save or update button texts
      if (existingButton) {
        const { error: buttonError } = await supabase
          .from('content_items')
          .update({
            content: buttonTexts as any,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingButton.id);
        
        if (buttonError) throw buttonError;
      } else {
        const { error: buttonError } = await supabase
          .from('content_items')
          .insert({
            title: 'Button Texts',
            slug: 'button-texts',
            content: buttonTexts as any,
            status: 'published'
          });
        
        if (buttonError) throw buttonError;
      }

      // Apply CSS variables to root element
      applyDesignToCSS();

      toast({
        title: "Settings saved",
        description: "Design customization settings have been updated successfully."
      });
    } catch (error) {
      console.error('Error saving design settings:', error);
      toast({
        title: "Save failed",
        description: "Failed to save design settings. Please try again.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const applyDesignToCSS = () => {
    const root = document.documentElement;
    root.style.setProperty('--primary', designSettings.primary_color);
    root.style.setProperty('--secondary', designSettings.secondary_color);
    root.style.setProperty('--accent', designSettings.accent_color);
    root.style.setProperty('--background', designSettings.background_color);
    root.style.setProperty('--foreground', designSettings.text_color);
  };

  const resetToDefaults = () => {
    setDesignSettings({
      primary_color: '#1a365d',
      secondary_color: '#2d3748',
      accent_color: '#e53e3e',
      text_color: '#2d3748',
      background_color: '#ffffff',
      button_primary_bg: '#1a365d',
      button_primary_text: '#ffffff',
      button_secondary_bg: '#e2e8f0',
      button_secondary_text: '#2d3748'
    });

    setButtonTexts({
      cta_primary: 'Get Started',
      cta_secondary: 'Learn More',
      learn_more: 'Learn More',
      contact_us: 'Contact Us',
      view_models: 'View Our Models',
      book_now: 'Book Now',
      get_started: 'Get Started',
      read_more: 'Read More'
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner text="Loading design settings..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Design Customization</h2>
          <p className="text-muted-foreground">
            Customize your website's colors, button texts, and overall design
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={resetToDefaults}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Reset to Defaults
          </Button>
          <Button onClick={saveDesignSettings} disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="colors" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="colors" className="flex items-center gap-2">
            <Palette className="w-4 h-4" />
            Colors & Theme
          </TabsTrigger>
          <TabsTrigger value="buttons" className="flex items-center gap-2">
            <Type className="w-4 h-4" />
            Button Texts
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Live Preview
          </TabsTrigger>
        </TabsList>

        <TabsContent value="colors" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Primary Colors */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Paintbrush className="w-5 h-5" />
                  Primary Colors
                </CardTitle>
                <CardDescription>
                  Main brand colors used throughout the website
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="primary_color">Primary Color</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="primary_color"
                        type="color"
                        value={designSettings.primary_color}
                        onChange={(e) => setDesignSettings(prev => ({
                          ...prev,
                          primary_color: e.target.value
                        }))}
                        className="w-16 h-10 p-1 border rounded"
                      />
                      <Input
                        value={designSettings.primary_color}
                        onChange={(e) => setDesignSettings(prev => ({
                          ...prev,
                          primary_color: e.target.value
                        }))}
                        placeholder="#1a365d"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="secondary_color">Secondary Color</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="secondary_color"
                        type="color"
                        value={designSettings.secondary_color}
                        onChange={(e) => setDesignSettings(prev => ({
                          ...prev,
                          secondary_color: e.target.value
                        }))}
                        className="w-16 h-10 p-1 border rounded"
                      />
                      <Input
                        value={designSettings.secondary_color}
                        onChange={(e) => setDesignSettings(prev => ({
                          ...prev,
                          secondary_color: e.target.value
                        }))}
                        placeholder="#2d3748"
                      />
                    </div>
                  </div>
                </div>
                <div>
                  <Label htmlFor="accent_color">Accent Color</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="accent_color"
                      type="color"
                      value={designSettings.accent_color}
                      onChange={(e) => setDesignSettings(prev => ({
                        ...prev,
                        accent_color: e.target.value
                      }))}
                      className="w-16 h-10 p-1 border rounded"
                    />
                    <Input
                      value={designSettings.accent_color}
                      onChange={(e) => setDesignSettings(prev => ({
                        ...prev,
                        accent_color: e.target.value
                      }))}
                      placeholder="#e53e3e"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Button Colors */}
            <Card>
              <CardHeader>
                <CardTitle>Button Styling</CardTitle>
                <CardDescription>
                  Customize button colors and appearance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Primary Button</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label htmlFor="button_primary_bg" className="text-xs">Background</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="button_primary_bg"
                          type="color"
                          value={designSettings.button_primary_bg}
                          onChange={(e) => setDesignSettings(prev => ({
                            ...prev,
                            button_primary_bg: e.target.value
                          }))}
                          className="w-12 h-8 p-1 border rounded"
                        />
                        <Input
                          value={designSettings.button_primary_bg}
                          onChange={(e) => setDesignSettings(prev => ({
                            ...prev,
                            button_primary_bg: e.target.value
                          }))}
                          className="text-xs"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="button_primary_text" className="text-xs">Text</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="button_primary_text"
                          type="color"
                          value={designSettings.button_primary_text}
                          onChange={(e) => setDesignSettings(prev => ({
                            ...prev,
                            button_primary_text: e.target.value
                          }))}
                          className="w-12 h-8 p-1 border rounded"
                        />
                        <Input
                          value={designSettings.button_primary_text}
                          onChange={(e) => setDesignSettings(prev => ({
                            ...prev,
                            button_primary_text: e.target.value
                          }))}
                          className="text-xs"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm font-medium mb-2 block">Secondary Button</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label htmlFor="button_secondary_bg" className="text-xs">Background</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="button_secondary_bg"
                          type="color"
                          value={designSettings.button_secondary_bg}
                          onChange={(e) => setDesignSettings(prev => ({
                            ...prev,
                            button_secondary_bg: e.target.value
                          }))}
                          className="w-12 h-8 p-1 border rounded"
                        />
                        <Input
                          value={designSettings.button_secondary_bg}
                          onChange={(e) => setDesignSettings(prev => ({
                            ...prev,
                            button_secondary_bg: e.target.value
                          }))}
                          className="text-xs"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="button_secondary_text" className="text-xs">Text</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="button_secondary_text"
                          type="color"
                          value={designSettings.button_secondary_text}
                          onChange={(e) => setDesignSettings(prev => ({
                            ...prev,
                            button_secondary_text: e.target.value
                          }))}
                          className="w-12 h-8 p-1 border rounded"
                        />
                        <Input
                          value={designSettings.button_secondary_text}
                          onChange={(e) => setDesignSettings(prev => ({
                            ...prev,
                            button_secondary_text: e.target.value
                          }))}
                          className="text-xs"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="buttons" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Button Text Customization</CardTitle>
              <CardDescription>
                Customize the text that appears on buttons throughout your website
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(buttonTexts).map(([key, value]) => (
                  <div key={key}>
                    <Label htmlFor={key}>
                      {key.split('_').map(word => 
                        word.charAt(0).toUpperCase() + word.slice(1)
                      ).join(' ')}
                    </Label>
                    <Input
                      id={key}
                      value={value}
                      onChange={(e) => setButtonTexts(prev => ({
                        ...prev,
                        [key]: e.target.value
                      }))}
                      placeholder={`Enter ${key.replace('_', ' ')} text`}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Live Preview</CardTitle>
              <CardDescription>
                Preview how your design changes will look on the website
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6 p-6 border rounded-lg bg-background">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold" style={{ color: designSettings.primary_color }}>
                    Website Preview
                  </h3>
                  <Badge>Live Preview</Badge>
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <Button 
                      style={{
                        backgroundColor: designSettings.button_primary_bg,
                        color: designSettings.button_primary_text
                      }}
                    >
                      {buttonTexts.cta_primary}
                    </Button>
                    <Button 
                      variant="outline"
                      style={{
                        backgroundColor: designSettings.button_secondary_bg,
                        color: designSettings.button_secondary_text,
                        borderColor: designSettings.secondary_color
                      }}
                    >
                      {buttonTexts.cta_secondary}
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold mb-2" style={{ color: designSettings.secondary_color }}>
                        Sample Content
                      </h4>
                      <p className="text-sm" style={{ color: designSettings.text_color }}>
                        This is how your text content will appear with the selected colors.
                      </p>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button size="sm" style={{
                        backgroundColor: designSettings.button_primary_bg,
                        color: designSettings.button_primary_text
                      }}>
                        {buttonTexts.contact_us}
                      </Button>
                      <Button size="sm" style={{
                        backgroundColor: designSettings.button_primary_bg,
                        color: designSettings.button_primary_text
                      }}>
                        {buttonTexts.view_models}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};