import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { DataTable } from '@/components/DataTable';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  ArrowUp, 
  ArrowDown,
  Image as ImageIcon,
  Eye,
  EyeOff,
  Save,
  Monitor,
  Smartphone,
  Settings
} from 'lucide-react';
import { ImageUpload } from '@/components/ImageUpload';
import { LoadingSpinner } from '@/components/LoadingSpinner';

interface HeroSlide {
  id: string;
  title: string;
  subtitle?: string | null;
  image_url: string;
  image_url_mobile?: string | null;
  button_text?: string | null;
  button_link?: string | null;
  order_index: number;
  active: boolean | null;
  created_at: string;
  updated_at: string;
}

interface HeroSettings {
  id: string;
  auto_play: boolean | null;
  slide_duration: number | null;
  show_dots: boolean | null;
  overlay_opacity: number | null;
  description?: string | null;
  updated_at: string;
}

export const EnhancedHeroManagement: React.FC = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [slides, setSlides] = useState<HeroSlide[]>([]);
  const [settings, setSettings] = useState<HeroSettings | null>(null);
  const [isSlideDialogOpen, setIsSlideDialogOpen] = useState(false);
  const [editingSlide, setEditingSlide] = useState<HeroSlide | null>(null);
  const [actionLoading, setActionLoading] = useState<Record<string, boolean>>({});
  
  const [slideForm, setSlideForm] = useState({
    title: '',
    subtitle: '',
    image_url: '',
    image_url_mobile: '',
    button_text: 'View Our Models',
    button_link: '/models',
    active: true
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [slidesResponse, settingsResponse] = await Promise.all([
        supabase
          .from('hero_slides')
          .select('*')
          .order('order_index', { ascending: true }),
        supabase
          .from('hero_settings')
          .select('*')
          .single()
      ]);

      if (slidesResponse.error) throw slidesResponse.error;
      if (settingsResponse.error && settingsResponse.error.code !== 'PGRST116') {
        throw settingsResponse.error;
      }

      setSlides((slidesResponse.data || []).map(slide => ({
        ...slide,
        active: slide.active ?? true
      })));
      
      if (settingsResponse.data) {
        setSettings({
          ...settingsResponse.data,
          auto_play: settingsResponse.data.auto_play ?? true,
          slide_duration: settingsResponse.data.slide_duration ?? 5000,
          show_dots: settingsResponse.data.show_dots ?? true,
          overlay_opacity: settingsResponse.data.overlay_opacity ?? 30
        });
      }
    } catch (error) {
      console.error('Error fetching hero data:', error);
      toast({
        title: "Loading error",
        description: "Failed to load hero data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveSlide = async () => {
    const actionKey = editingSlide ? `edit_${editingSlide.id}` : 'create';
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));

    try {
      const slideData = {
        title: slideForm.title,
        subtitle: slideForm.subtitle || null,
        image_url: slideForm.image_url,
        image_url_mobile: slideForm.image_url_mobile || null,
        button_text: slideForm.button_text || null,
        button_link: slideForm.button_link || null,
        active: slideForm.active,
        order_index: editingSlide ? editingSlide.order_index : slides.length
      };

      if (editingSlide) {
        const { error } = await supabase
          .from('hero_slides')
          .update(slideData)
          .eq('id', editingSlide.id);

        if (error) throw error;
        
        toast({
          title: "Slide updated",
          description: "Hero slide has been updated successfully"
        });
      } else {
        const { error } = await supabase
          .from('hero_slides')
          .insert(slideData);

        if (error) throw error;
        
        toast({
          title: "Slide created",
          description: "New hero slide has been created successfully"
        });
      }

      closeSlideDialog();
      fetchData();
    } catch (error) {
      console.error('Error saving slide:', error);
      toast({
        title: "Save failed",
        description: "Failed to save hero slide",
        variant: "destructive"
      });
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  const deleteSlide = async (slide: HeroSlide) => {
    if (!confirm('Are you sure you want to delete this slide?')) return;

    const actionKey = `delete_${slide.id}`;
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));

    try {
      const { error } = await supabase
        .from('hero_slides')
        .delete()
        .eq('id', slide.id);

      if (error) throw error;

      toast({
        title: "Slide deleted",
        description: "Hero slide has been deleted successfully"
      });
      fetchData();
    } catch (error) {
      console.error('Error deleting slide:', error);
      toast({
        title: "Delete failed",
        description: "Failed to delete hero slide",
        variant: "destructive"
      });
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  const toggleSlideActive = async (slide: HeroSlide) => {
    const actionKey = `toggle_${slide.id}`;
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));

    try {
      const { error } = await supabase
        .from('hero_slides')
        .update({ active: !slide.active })
        .eq('id', slide.id);

      if (error) throw error;

      toast({
        title: slide.active ? "Slide deactivated" : "Slide activated",
        description:` Hero slide has been ${slide.active ? 'deactivated' : 'activated'}`
      });
      fetchData();
    } catch (error) {
      console.error('Error toggling slide:', error);
      toast({
        title: "Toggle failed",
        description: "Failed to toggle slide status",
        variant: "destructive"
      });
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  const reorderSlide = async (slide: HeroSlide, direction: 'up' | 'down') => {
    const actionKey = `reorder_${slide.id}`;
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));

    try {
      const currentIndex = slides.findIndex(s => s.id === slide.id);
      const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;

      if (targetIndex < 0 || targetIndex >= slides.length) return;

      const updates = [
        {
          id: slide.id,
          order_index: slides[targetIndex].order_index
        },
        {
          id: slides[targetIndex].id,
          order_index: slide.order_index
        }
      ];

      for (const update of updates) {
        const { error } = await supabase
          .from('hero_slides')
          .update({ order_index: update.order_index })
          .eq('id', update.id);

        if (error) throw error;
      }

      fetchData();
    } catch (error) {
      console.error('Error reordering slide:', error);
      toast({
        title: "Reorder failed",
        description: "Failed to reorder slide",
        variant: "destructive"
      });
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  const saveSettings = async () => {
    if (!settings) return;

    setActionLoading(prev => ({ ...prev, settings: true }));

    try {
      const { error } = await supabase
        .from('hero_settings')
        .upsert(settings, { onConflict: 'id' });

      if (error) throw error;

      toast({
        title: "Settings saved",
        description: "Hero settings have been updated successfully"
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "Save failed",
        description: "Failed to save hero settings",
        variant: "destructive"
      });
    } finally {
      setActionLoading(prev => ({ ...prev, settings: false }));
    }
  };

  const openSlideDialog = (slide?: HeroSlide) => {
    if (slide) {
      setEditingSlide(slide);
      setSlideForm({
        title: slide.title,
        subtitle: slide.subtitle || '',
        image_url: slide.image_url,
        image_url_mobile: slide.image_url_mobile || '',
        button_text: slide.button_text || 'View Our Models',
        button_link: slide.button_link || '/models',
        active: slide.active ?? true
      });
    } else {
      setEditingSlide(null);
      setSlideForm({
        title: '',
        subtitle: '',
        image_url: '',
        image_url_mobile: '',
        button_text: 'View Our Models',
        button_link: '/models',
        active: true
      });
    }
    setIsSlideDialogOpen(true);
  };

  const closeSlideDialog = () => {
    setIsSlideDialogOpen(false);
    setEditingSlide(null);
  };

  const slideColumns = [
    {
      key: 'order_index',
      header: 'Order',
      render: (slide: HeroSlide) => (
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm">{slide.order_index}</span>
          <div className="flex flex-col gap-1">
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0"
              onClick={() => reorderSlide(slide, 'up')}
              disabled={actionLoading[`reorder_${slide.id}`] || slides.findIndex(s => s.id === slide.id) === 0}
            >
              <ArrowUp className="w-3 h-3" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0"
              onClick={() => reorderSlide(slide, 'down')}
              disabled={actionLoading[`reorder_${slide.id}`] || slides.findIndex(s => s.id === slide.id) === slides.length - 1}
            >
              <ArrowDown className="w-3 h-3" />
            </Button>
          </div>
        </div>
      )
    },
    {
      key: 'media_preview',
      header: 'Preview',
      render: (slide: HeroSlide) => (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Monitor className="w-3 h-3" />
            <span className="text-xs text-muted-foreground">Desktop</span>
          </div>
          <div className="w-16 h-10 rounded overflow-hidden bg-muted flex items-center justify-center">
            {slide.image_url ? (
              <img 
                src={slide.image_url} 
                alt={slide.title} 
                className="w-full h-full object-cover" 
              />
            ) : (
              <ImageIcon className="w-4 h-4 text-muted-foreground" />
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <Smartphone className="w-3 h-3" />
            <span className="text-xs text-muted-foreground">Mobile</span>
          </div>
          <div className="w-10 h-10 rounded overflow-hidden bg-muted flex items-center justify-center">
            {slide.image_url_mobile || slide.image_url ? (
              <img 
                src={slide.image_url_mobile || slide.image_url} 
                alt={slide.title} 
                className="w-full h-full object-cover" 
              />
            ) : (
              <ImageIcon className="w-4 h-4 text-muted-foreground" />
            )}
          </div>
        </div>
      )
    },
    {
      key: 'title',
      header: 'Title',
      render: (slide: HeroSlide) => (
        <div>
          <div className="font-medium">{slide.title}</div>
          {slide.subtitle && (
            <div className="text-sm text-muted-foreground">{slide.subtitle}</div>
          )}
        </div>
      )
    },
    {
      key: 'status',
      header: 'Status',
      render: (slide: HeroSlide) => (
        <Button
          size="sm"
          variant={slide.active ? "default" : "secondary"}
          onClick={() => toggleSlideActive(slide)}
          disabled={actionLoading[`toggle_${slide.id}`]}
          className="flex items-center gap-1"
        >
          {slide.active ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
          {slide.active ? 'Active' : 'Inactive'}
        </Button>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (slide: HeroSlide) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => openSlideDialog(slide)}
            disabled={actionLoading[`edit_${slide.id}`]}
          >
            <Edit3 className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteSlide(slide)}
            disabled={actionLoading[`delete_${slide.id}`]}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner text="Loading hero settings..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Hero Settings</h2>
          <p className="text-muted-foreground">
            Configure hero slides with main and mobile-optimized versions
          </p>
        </div>
        <Button onClick={() => openSlideDialog()}>
          <Plus className="w-4 h-4 mr-2" />
          Add Slide
        </Button>
      </div>

      <Tabs defaultValue="slides" className="space-y-6">
        <TabsList>
          <TabsTrigger value="slides">Hero Slides</TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="slides" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Hero Slides</CardTitle>
              <CardDescription>
                Manage your hero slides with desktop and mobile optimized versions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DataTable
                data={slides}
                columns={slideColumns}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Hero Section Settings</CardTitle>
              <CardDescription>
                Configure how the hero section behaves and appears
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {settings && (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="auto_play">Auto-play slides</Label>
                        <Switch
                          id="auto_play"
                          checked={settings.auto_play ?? true}
                          onCheckedChange={(checked) => 
                            setSettings(prev => prev ? { ...prev, auto_play: checked } : null)
                          }
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="slide_duration">Slide Duration (milliseconds)</Label>
                        <Input
                          id="slide_duration"
                          type="number"
                          value={settings.slide_duration ?? 5000}
                          onChange={(e) => 
                            setSettings(prev => prev ? { ...prev, slide_duration: parseInt(e.target.value) || 5000 } : null)
                          }
                          min="1000"
                          max="30000"
                          step="500"
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="show_dots">Show navigation dots</Label>
                        <Switch
                          id="show_dots"
                          checked={settings.show_dots ?? true}
                          onCheckedChange={(checked) => 
                            setSettings(prev => prev ? { ...prev, show_dots: checked } : null)
                          }
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="overlay_opacity">Overlay Opacity (%)</Label>
                        <Input
                          id="overlay_opacity"
                          type="number"
                          value={settings.overlay_opacity ?? 30}
                          onChange={(e) => 
                            setSettings(prev => prev ? { ...prev, overlay_opacity: parseInt(e.target.value) || 30 } : null)
                          }
                          min="0"
                          max="100"
                          step="5"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button 
                      onClick={saveSettings}
                      disabled={actionLoading.settings}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      {actionLoading.settings ? 'Saving...' : 'Save Settings'}
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Slide Dialog */}
      <Dialog open={isSlideDialogOpen} onOpenChange={setIsSlideDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingSlide ? 'Edit Hero Slide' : 'Create Hero Slide'}
            </DialogTitle>
            <DialogDescription>
              Configure your hero slide with main image and optional mobile version
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="slide_title">Title</Label>
                <Input
                  id="slide_title"
                  value={slideForm.title}
                  onChange={(e) => setSlideForm(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter slide title"
                />
              </div>
              <div>
                <Label htmlFor="slide_subtitle">Subtitle</Label>
                <Input
                  id="slide_subtitle"
                  value={slideForm.subtitle}
                  onChange={(e) => setSlideForm(prev => ({ ...prev, subtitle: e.target.value }))}
                  placeholder="Enter slide subtitle (optional)"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="button_text">Button Text</Label>
                <Input
                  id="button_text"
                  value={slideForm.button_text}
                  onChange={(e) => setSlideForm(prev => ({ ...prev, button_text: e.target.value }))}
                  placeholder="Button text"
                />
              </div>
              <div>
                <Label htmlFor="button_link">Button Link</Label>
                <Input
                  id="button_link"
                  value={slideForm.button_link}
                  onChange={(e) => setSlideForm(prev => ({ ...prev, button_link: e.target.value }))}
                  placeholder="/models"
                />
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-lg font-semibold">Hero Images</h3>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Desktop/Main Image */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Monitor className="w-4 h-4" />
                      Main Image
                    </CardTitle>
                    <CardDescription>
                      Primary hero image (1920x1080px recommended)
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ImageUpload
                      value={slideForm.image_url}
                      onChange={(url: string) => setSlideForm(prev => ({ ...prev, image_url: url }))}
                      bucket="website-images"
                    />
                  </CardContent>
                </Card>

                {/* Mobile Image (Optional) */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Smartphone className="w-4 h-4" />
                      Mobile Image (Optional)
                    </CardTitle>
                    <CardDescription>
                      Optimized for mobile devices (768x1024px recommended)
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ImageUpload
                      value={slideForm.image_url_mobile}
                      onChange={(url: string) => setSlideForm(prev => ({ ...prev, image_url_mobile: url }))}
                      bucket="website-images"
                    />
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Switch
                  id="slide_active"
                  checked={slideForm.active}
                  onCheckedChange={(checked) => setSlideForm(prev => ({ ...prev, active: checked }))}
                />
                <Label htmlFor="slide_active">Active</Label>
              </div>
              
              <div className="flex items-center gap-2">
                <Button variant="outline" onClick={closeSlideDialog}>
                  Cancel
                </Button>
                <Button 
                  onClick={saveSlide}
                  disabled={actionLoading[editingSlide ? `edit_${editingSlide.id}` : 'create']}
                >
                  {actionLoading[editingSlide ? `edit_${editingSlide.id}` : 'create'] ? (
                    <LoadingSpinner size={16} text={editingSlide ? 'Updating...' : 'Creating...'} />
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      {editingSlide ? 'Update Slide' : 'Create Slide'}
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};