import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Search, 
  TrendingUp, 
  Save,
  Globe,
  Plus
} from 'lucide-react';

interface SEOData {
  id: string;
  page_path: string;
  meta_title: string;
  meta_description: string;
  meta_keywords: string[];
  og_title?: string | null;
  og_description?: string | null;
  og_image?: string | null;
  canonical_url?: string | null;
  seo_score?: number;
  twitter_title?: string | null;
  twitter_description?: string | null;
  twitter_image?: string | null;
  structured_data?: any;
  is_active?: boolean | null;
}

export const SEOManager: React.FC = () => {
  const [seoData, setSeoData] = useState<SEOData[]>([]);
  const [selectedPage, setSelectedPage] = useState<string>('/');
  const [currentSEO, setCurrentSEO] = useState<Partial<SEOData>>({});
  const [keywords, setKeywords] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [customPages, setCustomPages] = useState<{ path: string; title: string }[]>([]);
  const [newPagePath, setNewPagePath] = useState('');
  const [newPageTitle, setNewPageTitle] = useState('');

  const commonPages = [
    { path: '/', title: 'Homepage' },
    { path: '/about', title: 'About Us' },
    { path: '/services', title: 'Services' },
    { path: '/models', title: 'Models' },
    { path: '/contact', title: 'Contact' },
    { path: '/faq', title: 'FAQ' },
    { path: '/blog', title: 'Blog' },
    { path: '/privacy', title: 'Privacy Policy' },
    { path: '/terms', title: 'Terms of Service' }
  ];

  useEffect(() => {
    fetchSEOData();
    fetchCustomPages();
  }, []);

  const fetchCustomPages = async () => {
    try {
      const { data, error } = await supabase
        .from('content_items')
        .select('slug, title')
        .neq('slug', 'homepage');

      if (error) throw error;
      
      const pages = (data || []).map(item => ({
        path: `/${item.slug}`,
        title: item.title
      }));
      
      setCustomPages(pages);
    } catch (error) {
      console.error('Error fetching custom pages:', error);
    }
  };

  const addCustomPage = () => {
    if (!newPagePath.trim() || !newPageTitle.trim()) {
      toast.error('Please enter both page path and title');
      return;
    }

    const path = newPagePath.startsWith('/') ? newPagePath : `/${newPagePath}`;
    const allPages = [...commonPages, ...customPages];
    
    if (allPages.some(page => page.path === path)) {
      toast.error('Page path already exists');
      return;
    }

    setCustomPages(prev => [...prev, { path, title: newPageTitle }]);
    setNewPagePath('');
    setNewPageTitle('');
    toast.success('Custom page added');
  };


  useEffect(() => {
    const pageData = seoData.find(item => item.page_path === selectedPage);
    if (pageData) {
      setCurrentSEO(pageData);
      setKeywords(pageData.meta_keywords?.join(', ') || '');
    } else {
      setCurrentSEO({ page_path: selectedPage });
      setKeywords('');
    }
  }, [selectedPage, seoData]);

  const fetchSEOData = async () => {
    try {
      const { data, error } = await supabase
        .from('page_seo')
        .select('*')
        .eq('is_active', true);

      if (error) throw error;
      
      const mappedData = (data || []).map(item => ({
        id: item.id,
        page_path: item.page_path,
        meta_title: item.meta_title || '',
        meta_description: item.meta_description || '',
        meta_keywords: item.meta_keywords || [],
        og_title: item.og_title,
        og_description: item.og_description,
        og_image: item.og_image,
        canonical_url: item.canonical_url,
        seo_score: item.seo_score || 0,
        twitter_title: item.twitter_title,
        twitter_description: item.twitter_description,
        twitter_image: item.twitter_image,
        structured_data: item.structured_data,
        is_active: item.is_active ?? true
      }));
      
      setSeoData(mappedData);
    } catch (error) {
      console.error('Error fetching SEO data:', error);
      toast.error('Failed to fetch SEO data');
    } finally {
      setLoading(false);
    }
  };

  const saveSEOData = async () => {
    setSaving(true);
    try {
      const seoPayload = {
        page_path: selectedPage,
        meta_title: currentSEO.meta_title || '',
        meta_description: currentSEO.meta_description || '',
        meta_keywords: keywords.split(',').map(k => k.trim()).filter(Boolean),
        og_title: currentSEO.og_title,
        og_description: currentSEO.og_description,
        og_image: currentSEO.og_image,
        canonical_url: currentSEO.canonical_url,
        twitter_title: currentSEO.twitter_title,
        twitter_description: currentSEO.twitter_description,
        twitter_image: currentSEO.twitter_image,
        structured_data: currentSEO.structured_data,
        is_active: currentSEO.is_active !== false,
        seo_score: calculateSEOScore()
      };

      const existingPage = seoData.find(item => item.page_path === selectedPage);
      
      if (existingPage) {
        const { error } = await supabase
          .from('page_seo')
          .update(seoPayload)
          .eq('id', existingPage.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('page_seo')
          .insert(seoPayload);

        if (error) throw error;
      }

      toast.success('SEO data saved successfully');
      fetchSEOData();
    } catch (error) {
      console.error('Error saving SEO data:', error);
      toast.error('Failed to save SEO data');
    } finally {
      setSaving(false);
    }
  };

  const calculateSEOScore = (): number => {
    let score = 0;
    
    if (currentSEO.meta_title) {
      score += 25;
      if (currentSEO.meta_title.length >= 30 && currentSEO.meta_title.length <= 60) {
        score += 15;
      }
    }

    if (currentSEO.meta_description) {
      score += 25;
      if (currentSEO.meta_description.length >= 120 && currentSEO.meta_description.length <= 160) {
        score += 15;
      }
    }

    if (keywords.length > 0) {
      score += 10;
    }

    if (currentSEO.og_title && currentSEO.og_description) {
      score += 10;
    }

    return Math.min(score, 100);
  };

  const getSEOScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getSEOScoreBadge = (score: number) => {
    if (score >= 80) return 'bg-green-100 text-green-800 border-green-200';
    if (score >= 60) return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    return 'bg-red-100 text-red-800 border-red-200';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            SEO Management
          </CardTitle>
          <CardDescription>
            Optimize your website's search engine visibility with comprehensive SEO tools
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Page Management */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Page Management</CardTitle>
                <CardDescription>
                  Manage SEO for existing pages and add custom pages
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium">Website Pages</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 mt-2">
                    {commonPages.map((page) => {
                      const hasData = seoData.some(item => item.page_path === page.path);
                      const pageData = seoData.find(item => item.page_path === page.path);
                      
                      return (
                        <Button
                          key={page.path}
                          variant={selectedPage === page.path ? 'default' : 'outline'}
                          size="sm"
                          className="flex flex-col h-auto py-3 text-left"
                          onClick={() => setSelectedPage(page.path)}
                        >
                          <div className="flex items-center gap-2 w-full">
                            <Globe className="w-3 h-3 flex-shrink-0" />
                            <span className="font-medium text-xs truncate">{page.title}</span>
                          </div>
                          {hasData && pageData?.seo_score ? (
                            <Badge 
                              className={`mt-1 text-xs self-start ${getSEOScoreBadge(pageData.seo_score)}`}
                            >
                              {pageData.seo_score}%
                            </Badge>
                          ) : (
                            <span className="text-xs text-muted-foreground mt-1 self-start">Not optimized</span>
                          )}
                        </Button>
                      );
                    })}
                  </div>
                </div>

                <div className="border-t pt-4">
                  <Label className="text-sm font-medium">Add Custom Page</Label>
                  <div className="flex gap-2 mt-2">
                    <Input
                      placeholder="Page path (e.g., /gallery)"
                      value={newPagePath}
                      onChange={(e) => setNewPagePath(e.target.value)}
                      className="flex-1"
                    />
                    <Input
                      placeholder="Page title"
                      value={newPageTitle}
                      onChange={(e) => setNewPageTitle(e.target.value)}
                      className="flex-1"
                    />
                    <Button onClick={addCustomPage} size="sm">
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* SEO Score */}
            <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">SEO Score</h3>
                    <p className="text-sm text-muted-foreground">
                      Current optimization level for {selectedPage}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className={`text-3xl font-bold ${getSEOScoreColor(calculateSEOScore())}`}>
                      {calculateSEOScore()}%
                    </div>
                    <TrendingUp className="w-6 h-6 ml-auto text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Basic SEO Fields */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Basic SEO</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="meta-title">Meta Title</Label>
                    <Input
                      id="meta-title"
                      value={currentSEO.meta_title || ''}
                      onChange={(e) => setCurrentSEO(prev => ({ ...prev, meta_title: e.target.value }))}
                      placeholder="Page title for search engines"
                      maxLength={60}
                    />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>Recommended: 30-60 characters</span>
                      <span>{(currentSEO.meta_title || '').length}/60</span>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="meta-description">Meta Description</Label>
                    <Textarea
                      id="meta-description"
                      value={currentSEO.meta_description || ''}
                      onChange={(e) => setCurrentSEO(prev => ({ ...prev, meta_description: e.target.value }))}
                      placeholder="Brief description of the page content"
                      maxLength={160}
                      rows={3}
                    />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>Recommended: 120-160 characters</span>
                      <span>{(currentSEO.meta_description || '').length}/160</span>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="keywords">Keywords</Label>
                    <Input
                      id="keywords"
                      value={keywords}
                      onChange={(e) => setKeywords(e.target.value)}
                      placeholder="keyword1, keyword2, keyword3"
                    />
                  </div>

                  <div>
                    <Label htmlFor="canonical-url">Canonical URL</Label>
                    <Input
                      id="canonical-url"
                      value={currentSEO.canonical_url || ''}
                      onChange={(e) => setCurrentSEO(prev => ({ ...prev, canonical_url: e.target.value }))}
                      placeholder="https://yourdomain.com/page"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Open Graph (Social Media)</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="og-title">OG Title</Label>
                    <Input
                      id="og-title"
                      value={currentSEO.og_title || ''}
                      onChange={(e) => setCurrentSEO(prev => ({ ...prev, og_title: e.target.value }))}
                      placeholder="Title for social media shares"
                    />
                  </div>

                  <div>
                    <Label htmlFor="og-description">OG Description</Label>
                    <Textarea
                      id="og-description"
                      value={currentSEO.og_description || ''}
                      onChange={(e) => setCurrentSEO(prev => ({ ...prev, og_description: e.target.value }))}
                      placeholder="Description for social media shares"
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="og-image">OG Image URL</Label>
                    <Input
                      id="og-image"
                      value={currentSEO.og_image || ''}
                      onChange={(e) => setCurrentSEO(prev => ({ ...prev, og_image: e.target.value }))}
                      placeholder="https://yourdomain.com/image.jpg"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="flex justify-end">
              <Button onClick={saveSEOData} disabled={saving}>
                <Save className="w-4 h-4 mr-2" />
                {saving ? 'Saving...' : 'Save SEO Settings'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};