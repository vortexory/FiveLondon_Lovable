import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Upload, 
  X, 
  Image as ImageIcon, 
  CheckCircle, 
  AlertCircle,
  FolderOpen
} from 'lucide-react';

interface UploadedImage {
  file: File;
  url?: string;
  status: 'pending' | 'uploading' | 'success' | 'error';
  progress: number;
  error?: string;
}

export const BulkImageUpload: React.FC = () => {
  const [selectedFiles, setSelectedFiles] = useState<UploadedImage[]>([]);
  const [uploading, setUploading] = useState(false);
  const [selectedBucket, setSelectedBucket] = useState('model-photos');

  const buckets = [
    { id: 'model-photos', name: 'Model Photos', description: 'Photos for model profiles and galleries' },
    { id: 'website-images', name: 'Website Images', description: 'General website images and content' },
    { id: 'blog-images', name: 'Blog Images', description: 'Images for blog posts and articles' }
  ];

  const handleFileSelection = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length !== files.length) {
      toast.warning(`${files.length - imageFiles.length} non-image files were skipped`);
    }

    const newImages: UploadedImage[] = imageFiles.map(file => ({
      file,
      status: 'pending',
      progress: 0
    }));

    setSelectedFiles(prev => [...prev, ...newImages]);
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const uploadSingleFile = async (image: UploadedImage, index: number): Promise<void> => {
    return new Promise(async (resolve, reject) => {
      try {
        // Update status to uploading
        setSelectedFiles(prev => 
          prev.map((img, i) => 
            i === index ? { ...img, status: 'uploading', progress: 0 } : img
          )
        );

        const fileExt = image.file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = fileName;

        // Simulate progress updates
        const progressInterval = setInterval(() => {
          setSelectedFiles(prev => 
            prev.map((img, i) => 
              i === index && img.progress < 90 
                ? { ...img, progress: img.progress + 10 } 
                : img
            )
          );
        }, 100);

        const { error: uploadError } = await supabase.storage
          .from(selectedBucket)
          .upload(filePath, image.file);

        clearInterval(progressInterval);

        if (uploadError) {
          throw uploadError;
        }

        const { data: { publicUrl } } = supabase.storage
          .from(selectedBucket)
          .getPublicUrl(filePath);

        // Update to success
        setSelectedFiles(prev => 
          prev.map((img, i) => 
            i === index 
              ? { ...img, status: 'success', progress: 100, url: publicUrl }
              : img
          )
        );

        resolve();
      } catch (error) {
        // Update to error
        setSelectedFiles(prev => 
          prev.map((img, i) => 
            i === index 
              ? { 
                  ...img, 
                  status: 'error', 
                  progress: 0, 
                  error: error instanceof Error ? error.message : 'Upload failed'
                }
              : img
          )
        );
        reject(error);
      }
    });
  };

  const uploadAllFiles = async () => {
    if (selectedFiles.length === 0) return;

    setUploading(true);
    const pendingFiles = selectedFiles
      .map((file, index) => ({ file, index }))
      .filter(({ file }) => file.status === 'pending');

    try {
      // Upload files in batches of 3 to avoid overwhelming the server
      const batchSize = 3;
      for (let i = 0; i < pendingFiles.length; i += batchSize) {
        const batch = pendingFiles.slice(i, i + batchSize);
        await Promise.allSettled(
          batch.map(({ file, index }) => uploadSingleFile(file, index))
        );
      }

      const successCount = selectedFiles.filter(f => f.status === 'success').length;
      const errorCount = selectedFiles.filter(f => f.status === 'error').length;

      if (successCount > 0) {
        toast.success(`Successfully uploaded ${successCount} images`);
      }
      if (errorCount > 0) {
        toast.error(`Failed to upload ${errorCount} images`);
      }
    } catch (error) {
      console.error('Bulk upload error:', error);
      toast.error('Bulk upload failed');
    } finally {
      setUploading(false);
    }
  };

  const clearAll = () => {
    setSelectedFiles([]);
  };

  const retryFailed = () => {
    setSelectedFiles(prev => 
      prev.map(file => 
        file.status === 'error' 
          ? { ...file, status: 'pending', progress: 0, error: undefined }
          : file
      )
    );
  };

  const getStatusIcon = (status: UploadedImage['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      case 'uploading':
        return <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />;
      default:
        return <ImageIcon className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: UploadedImage['status']) => {
    switch (status) {
      case 'success':
        return 'border-green-200 bg-green-50';
      case 'error':
        return 'border-red-200 bg-red-50';
      case 'uploading':
        return 'border-blue-200 bg-blue-50';
      default:
        return 'border-gray-200 bg-white';
    }
  };

  const pendingCount = selectedFiles.filter(f => f.status === 'pending').length;
  const uploadingCount = selectedFiles.filter(f => f.status === 'uploading').length;
  const successCount = selectedFiles.filter(f => f.status === 'success').length;
  const errorCount = selectedFiles.filter(f => f.status === 'error').length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FolderOpen className="w-5 h-5" />
            Bulk Image Upload
          </CardTitle>
          <CardDescription>
            Upload multiple images at once to your chosen storage bucket
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Bucket Selection */}
          <div>
            <Label htmlFor="bucket-select">Storage Bucket</Label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-2">
              {buckets.map((bucket) => (
                <Card
                  key={bucket.id}
                  className={`cursor-pointer transition-all ${
                    selectedBucket === bucket.id 
                      ? 'ring-2 ring-primary border-primary bg-primary/5' 
                      : 'hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedBucket(bucket.id)}
                >
                  <CardContent className="p-3">
                    <h4 className="font-medium text-sm">{bucket.name}</h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      {bucket.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* File Selection */}
          <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6">
            <div className="text-center">
              <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
              <div className="mt-4">
                <Label htmlFor="bulk-file-upload" className="cursor-pointer">
                  <div className="flex items-center justify-center">
                    <Button type="button" disabled={uploading}>
                      Select Images
                    </Button>
                  </div>
                </Label>
                <Input
                  id="bulk-file-upload"
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleFileSelection}
                  disabled={uploading}
                  className="sr-only"
                />
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Select multiple images to upload. PNG, JPG, WEBP supported.
              </p>
            </div>
          </div>

          {/* Upload Summary */}
          {selectedFiles.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline">
                Total: {selectedFiles.length}
              </Badge>
              {pendingCount > 0 && (
                <Badge variant="secondary">
                  Pending: {pendingCount}
                </Badge>
              )}
              {uploadingCount > 0 && (
                <Badge className="bg-blue-100 text-blue-800">
                  Uploading: {uploadingCount}
                </Badge>
              )}
              {successCount > 0 && (
                <Badge className="bg-green-100 text-green-800">
                  Success: {successCount}
                </Badge>
              )}
              {errorCount > 0 && (
                <Badge variant="destructive">
                  Failed: {errorCount}
                </Badge>
              )}
            </div>
          )}

          {/* Action Buttons */}
          {selectedFiles.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <Button 
                onClick={uploadAllFiles} 
                disabled={uploading || pendingCount === 0}
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload {pendingCount} Images
              </Button>
              {errorCount > 0 && (
                <Button variant="outline" onClick={retryFailed} disabled={uploading}>
                  Retry Failed
                </Button>
              )}
              <Button variant="outline" onClick={clearAll} disabled={uploading}>
                Clear All
              </Button>
            </div>
          )}

          {/* File List */}
          {selectedFiles.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Selected Images</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {selectedFiles.map((image, index) => (
                    <div
                      key={index}
                      className={`flex items-center gap-3 p-3 rounded-lg border ${getStatusColor(image.status)}`}
                    >
                      <div className="flex-shrink-0">
                        {getStatusIcon(image.status)}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">
                          {image.file.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {(image.file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                        {image.status === 'uploading' && (
                          <Progress value={image.progress} className="w-full h-2 mt-1" />
                        )}
                        {image.error && (
                          <p className="text-xs text-red-600 mt-1">{image.error}</p>
                        )}
                      </div>

                      {image.status === 'pending' && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeFile(index)}
                          disabled={uploading}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
};