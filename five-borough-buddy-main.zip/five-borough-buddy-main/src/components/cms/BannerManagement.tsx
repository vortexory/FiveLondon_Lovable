import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Monitor, Smartphone, Save, Edit, Upload, AlertCircle, CheckCircle2 } from 'lucide-react';
import { ImageUpload } from '@/components/ImageUpload';

interface SiteBanner {
  id: string;
  section: string;
  image_url: string;
  caption?: string | null;
  order_index: number | null;
  visibility: string | null;
  device_type: string | null;
  alt_text?: string | null;
  is_active: boolean | null;
  created_at: string;
}

export const BannerManagement: React.FC = () => {
  const [siteBanners, setSiteBanners] = useState<SiteBanner[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingBanner, setEditingBanner] = useState<string | null>(null);
  const [editingDevice, setEditingDevice] = useState<'desktop' | 'mobile' | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const [editForm, setEditForm] = useState({
    section: 'hero',
    caption: '',
    alt_text: '',
    image_url: '',
    visibility: 'public',
    is_active: true,
  });

  // Move useMemo to component level to avoid conditional hook calls
  const { desktopBanners, mobileBanners } = useMemo(() => ({
    desktopBanners: siteBanners.filter(b => b.device_type === 'desktop'),
    mobileBanners: siteBanners.filter(b => b.device_type === 'mobile')
  }), [siteBanners]);

  useEffect(() => {
    fetchSiteBanners();
  }, []);

  const fetchSiteBanners = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('site_banners')
        .select('*')
        .eq('section', 'hero')
        .order('device_type')
        .order('order_index');

      if (error) throw error;
      setSiteBanners(data || []);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch site banners",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const updateEditForm = useCallback((field: string, value: any) => {
    setEditForm(prev => ({
      ...prev,
      [field]: value
    }));
  }, []);

  const startEditing = useCallback((banner: SiteBanner, deviceType: 'desktop' | 'mobile') => {
    setEditingBanner(banner.id);
    setEditingDevice(deviceType);
    setEditForm({
      section: banner.section,
      caption: banner.caption || '',
      alt_text: banner.alt_text || '',
      image_url: banner.image_url,
      visibility: banner.visibility || 'public',
      is_active: banner.is_active ?? true,
    });
    setValidationErrors({});
    setIsModalOpen(true);
  }, []);

  const cancelEditing = useCallback(() => {
    setEditingBanner(null);
    setEditingDevice(null);
    setIsModalOpen(false);
    setEditForm({
      section: 'hero',
      caption: '',
      alt_text: '',
      image_url: '',
      visibility: 'public',
      is_active: true,
    });
    setValidationErrors({});
  }, []);

  const validateForm = useCallback(() => {
    const errors: Record<string, string> = {};

    if (!editForm.caption?.trim()) {
      errors.caption = 'Caption is required';
    }
    if (!editForm.alt_text?.trim()) {
      errors.alt_text = 'Description is required';
    }
    if (!editForm.image_url?.trim()) {
      errors.image_url = 'Image is required';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  }, [editForm]);

  const saveSiteBanner = useCallback(async () => {
    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    try {
      const bannerData = {
        section: editForm.section,
        caption: editForm.caption,
        alt_text: editForm.alt_text,
        image_url: editForm.image_url,
        device_type: editingDevice,
        visibility: editForm.visibility,
        is_active: editForm.is_active,
        order_index: 0,
      };

      if (editingBanner) {
        const { error } = await supabase
          .from('site_banners')
          .update(bannerData)
          .eq('id', editingBanner);
        
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('site_banners')
          .insert([bannerData]);
        
        if (error) throw error;
      }

      toast({
        title: "Success",
        description: `${editingDevice} banner updated successfully`,
      });
      
      cancelEditing();
      await fetchSiteBanners();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save banner. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }, [editForm, editingDevice, editingBanner, validateForm, toast, cancelEditing, fetchSiteBanners]);

  const renderBannersList = () => {
    if (loading) {
      return (
        <div className="space-y-3">
          <Skeleton className="h-32 w-full rounded-lg" />
          <Skeleton className="h-32 w-full rounded-lg" />
        </div>
      );
    }


    if (siteBanners.length === 0) {
      return (
        <div className="text-center py-12 border-2 border-dashed border-muted rounded-lg bg-muted/20">
          <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold text-muted-foreground mb-2">No hero banners found</h3>
          <p className="text-sm text-muted-foreground mb-6">
            Create your first hero banner to get started
          </p>
          <div className="flex gap-3 justify-center">
            <Button onClick={() => startEditing({ 
              id: '', section: 'hero', image_url: '', caption: null, alt_text: null, 
              order_index: null, visibility: null, device_type: null, is_active: null, created_at: ''
            }, 'desktop')} variant="outline">
              <Monitor className="w-4 h-4 mr-2" />
              Create Desktop Banner
            </Button>
            <Button onClick={() => startEditing({ 
              id: '', section: 'hero', image_url: '', caption: null, alt_text: null, 
              order_index: null, visibility: null, device_type: null, is_active: null, created_at: ''
            }, 'mobile')} variant="outline">
              <Smartphone className="w-4 h-4 mr-2" />
              Create Mobile Banner
            </Button>
          </div>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {desktopBanners.map((banner) => (
          <div key={banner.id} className="group relative overflow-hidden rounded-lg border bg-card p-6 transition-all duration-200 hover:shadow-lg">
            <div className="flex items-start gap-6">
              <div className="relative overflow-hidden rounded-lg">
                <div className="flex items-center gap-1 mb-2">
                  <Monitor className="w-4 h-4 text-blue-600" />
                  <span className="text-xs text-muted-foreground">Desktop</span>
                </div>
                <img
                  src={banner.image_url}
                  alt={banner.alt_text || 'Desktop banner'}
                  className="w-32 h-18 object-cover rounded transition-transform duration-200 group-hover:scale-105"
                />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <h4 className="font-semibold text-lg text-foreground">{banner.caption || 'Hero Banner'}</h4>
                  {(banner.is_active ?? true) && <CheckCircle2 className="w-5 h-5 text-green-500" />}
                </div>
                <p className="text-muted-foreground mb-3">{banner.alt_text}</p>
                <div className="flex items-center gap-3 mb-4">
                  <Badge variant={(banner.is_active ?? true) ? "default" : "secondary"}>
                    {(banner.is_active ?? true) ? "Active" : "Inactive"}
                  </Badge>
                  <Badge variant="outline">{banner.visibility}</Badge>
                </div>
                <div className="text-xs text-muted-foreground">
                  Order: {banner.order_index} | Created: {new Date(banner.created_at).toLocaleDateString()}
                </div>
              </div>
              
              <div className="flex items-center">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => startEditing(banner, 'desktop')}
                  disabled={editingBanner === banner.id}
                  className="hover:bg-blue-50 hover:text-blue-600 transition-colors duration-200"
                >
                  <Edit className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}

        {mobileBanners.map((banner) => (
          <div key={banner.id} className="group relative overflow-hidden rounded-lg border bg-card p-6 transition-all duration-200 hover:shadow-lg">
            <div className="flex items-start gap-6">
              <div className="relative overflow-hidden rounded-lg">
                <div className="flex items-center gap-1 mb-2">
                  <Smartphone className="w-4 h-4 text-purple-600" />
                  <span className="text-xs text-muted-foreground">Mobile</span>
                </div>
                <img
                  src={banner.image_url}
                  alt={banner.alt_text || 'Mobile banner'}
                  className="w-18 h-32 object-cover rounded transition-transform duration-200 group-hover:scale-105"
                />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <h4 className="font-semibold text-lg text-foreground">{banner.caption || 'Hero Banner'}</h4>
                  {(banner.is_active ?? true) && <CheckCircle2 className="w-5 h-5 text-green-500" />}
                </div>
                <p className="text-muted-foreground mb-3">{banner.alt_text}</p>
                <div className="flex items-center gap-3 mb-4">
                  <Badge variant={(banner.is_active ?? true) ? "default" : "secondary"}>
                    {(banner.is_active ?? true) ? "Active" : "Inactive"}
                  </Badge>
                  <Badge variant="outline">{banner.visibility}</Badge>
                </div>
                <div className="text-xs text-muted-foreground">
                  Order: {banner.order_index} | Created: {new Date(banner.created_at).toLocaleDateString()}
                </div>
              </div>
              
              <div className="flex items-center">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => startEditing(banner, 'mobile')}
                  disabled={editingBanner === banner.id}
                  className="hover:bg-purple-50 hover:text-purple-600 transition-colors duration-200"
                >
                  <Edit className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderEditModal = () => {
    return (
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <div className={`rounded-full p-2 ${editingDevice === 'desktop' ? 'bg-blue-50' : 'bg-purple-50'}`}>
                {editingDevice === 'desktop' ? (
                  <Monitor className="w-5 h-5 text-blue-600" />
                ) : (
                  <Smartphone className="w-5 h-5 text-purple-600" />
                )}
              </div>
              {editingBanner ? `Edit ${editingDevice} Banner` : `Create ${editingDevice} Banner`}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {Object.keys(validationErrors).length > 0 && (
              <Alert variant="destructive" className="animate-fade-in">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Please correct the following errors:
                  <ul className="mt-2 space-y-1">
                    {Object.entries(validationErrors).map(([field, error]) => (
                      <li key={field} className="text-sm">• {error}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="caption" className="text-sm font-medium">
                  Caption <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="caption"
                  value={editForm.caption}
                  onChange={(e) => {
                    updateEditForm('caption', e.target.value);
                    if (validationErrors.caption) {
                      setValidationErrors(prev => ({ ...prev, caption: '' }));
                    }
                  }}
                  placeholder="Enter banner caption"
                  className={validationErrors.caption ? 'border-destructive focus:border-destructive' : ''}
                />
                {validationErrors.caption && (
                  <p className="text-xs text-destructive mt-1">{validationErrors.caption}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="alt_text" className="text-sm font-medium">
                  Description <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="alt_text"
                  value={editForm.alt_text}
                  onChange={(e) => {
                    updateEditForm('alt_text', e.target.value);
                    if (validationErrors.alt_text) {
                      setValidationErrors(prev => ({ ...prev, alt_text: '' }));
                    }
                  }}
                  placeholder="Enter banner description"
                  className={validationErrors.alt_text ? 'border-destructive focus:border-destructive' : ''}
                />
                {validationErrors.alt_text && (
                  <p className="text-xs text-destructive mt-1">{validationErrors.alt_text}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Visibility</Label>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant={editForm.visibility === 'public' ? 'default' : 'outline'}
                    onClick={() => updateEditForm('visibility', 'public')}
                    className="flex-1"
                  >
                    Public
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={editForm.visibility === 'members' ? 'default' : 'outline'}
                    onClick={() => updateEditForm('visibility', 'members')}
                    className="flex-1"
                  >
                    Members Only
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-medium flex items-center gap-2">
                  Active Status
                </Label>
                <div className="flex items-center space-x-2 pt-2">
                  <Switch
                    checked={editForm.is_active}
                    onCheckedChange={(checked) => updateEditForm('is_active', checked)}
                  />
                  <span className="text-sm text-muted-foreground">
                    {editForm.is_active ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                {editingDevice === 'desktop' ? (
                  <Monitor className="w-4 h-4 text-blue-600" />
                ) : (
                  <Smartphone className="w-4 h-4 text-purple-600" />
                )}
                <h4 className="font-medium text-sm">{editingDevice} Image</h4>
                <Badge variant="outline" className="text-xs">
                  {editingDevice === 'desktop' ? '1920x1080' : '768x1024'}
                </Badge>
              </div>
              <ImageUpload
                bucket="banners"
                value={editForm.image_url}
                onChange={(url, _audience) => {
                  console.log('Banner image uploaded:', url);
                  updateEditForm('image_url', url);
                  if (validationErrors.image_url) {
                    setValidationErrors(prev => ({ ...prev, image_url: '' }));
                  }
                }}
                label=""
              />
              {validationErrors.image_url && (
                <p className="text-xs text-destructive mt-1">{validationErrors.image_url}</p>
              )}
            </div>

            <div className="flex justify-end gap-3 pt-6 border-t">
              <Button
                variant="outline"
                onClick={cancelEditing}
                disabled={saving}
              >
                Cancel
              </Button>
              <Button
                onClick={saveSiteBanner}
                disabled={saving}
                className="min-w-[100px]"
              >
                {saving ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Saving...
                  </div>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    {editingBanner ? 'Save Changes' : 'Create Banner'}
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Hero Banner Management</h1>
          <p className="text-muted-foreground mt-2">
            Manage your website hero slides with desktop and mobile versions
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-xs">
            Live Preview
          </Badge>
          <Button variant="outline" size="sm" onClick={fetchSiteBanners}>
            <Upload className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {renderEditModal()}

      <Card className="overflow-hidden">
        <CardHeader className="bg-muted/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="rounded-full bg-primary/10 p-2">
                <Upload className="w-5 h-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-xl">Hero Banners</CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  Your website's hero banners for desktop and mobile versions
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-sm font-medium text-foreground">
                  {siteBanners.length} Banner{siteBanners.length !== 1 ? 's' : ''}
                </div>
                <div className="text-xs text-muted-foreground">
                  {siteBanners.filter(s => s.is_active ?? true).length} Active
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-6">
          {renderBannersList()}
        </CardContent>
      </Card>
    </div>
  );
};