import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Upload, 
  X, 
  Image as ImageIcon, 
  CheckCircle, 
  AlertCircle,
  FolderOpen,
  Globe,
  Users,
  Eye
} from 'lucide-react';

interface UploadedImage {
  file: File;
  url?: string;
  status: 'pending' | 'uploading' | 'success' | 'error';
  progress: number;
  error?: string;
  visibility: 'public' | 'members_only';
  modelId?: string;
  caption?: string;
}

interface AdvancedImageUploadProps {
  modelId?: string;
  onUploadComplete?: (images: { url: string; visibility: 'public' | 'members_only'; caption?: string }[]) => void;
}

export const AdvancedImageUpload: React.FC<AdvancedImageUploadProps> = ({
  modelId,
  onUploadComplete
}) => {
  const [selectedFiles, setSelectedFiles] = useState<UploadedImage[]>([]);
  const [uploading, setUploading] = useState(false);
  const [selectedBucket] = useState('model-photos');
  const [globalVisibility, setGlobalVisibility] = useState<'public' | 'members_only' | 'mixed'>('public');
  const [selectedModels, setSelectedModels] = useState<string[]>(modelId ? [modelId] : []);
  const [availableModels, setAvailableModels] = useState<{ id: string; name: string }[]>([]);

  React.useEffect(() => {
    if (!modelId) {
      fetchAvailableModels();
    }
  }, [modelId]);

  const fetchAvailableModels = async () => {
    try {
      const { data, error } = await supabase
        .from('models')
        .select('id, name')
        .order('name');

      if (error) throw error;
      setAvailableModels(data || []);
    } catch (error) {
      console.error('Error fetching models:', error);
    }
  };

  const handleFileSelection = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length !== files.length) {
      toast.warning(`${files.length - imageFiles.length} non-image files were skipped`);
    }

    const newImages: UploadedImage[] = imageFiles.map(file => ({
      file,
      status: 'pending',
      progress: 0,
      visibility: globalVisibility === 'mixed' ? 'public' : globalVisibility,
      caption: ''
    }));

    setSelectedFiles(prev => [...prev, ...newImages]);
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const updateImageVisibility = (index: number, visibility: 'public' | 'members_only') => {
    setSelectedFiles(prev => 
      prev.map((img, i) => 
        i === index ? { ...img, visibility } : img
      )
    );
  };

  const updateImageCaption = (index: number, caption: string) => {
    setSelectedFiles(prev => 
      prev.map((img, i) => 
        i === index ? { ...img, caption } : img
      )
    );
  };

  const updateGlobalVisibility = (visibility: 'public' | 'members_only' | 'mixed') => {
    setGlobalVisibility(visibility);
    if (visibility !== 'mixed') {
      setSelectedFiles(prev => 
        prev.map(img => ({ ...img, visibility: visibility as 'public' | 'members_only' }))
      );
    }
  };

  const uploadSingleFile = async (image: UploadedImage, index: number): Promise<string> => {
    return new Promise(async (resolve, reject) => {
      try {
        // Update status to uploading
        setSelectedFiles(prev => 
          prev.map((img, i) => 
            i === index ? { ...img, status: 'uploading', progress: 0 } : img
          )
        );

        const fileExt = image.file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = fileName;

        // Simulate progress updates
        const progressInterval = setInterval(() => {
          setSelectedFiles(prev => 
            prev.map((img, i) => 
              i === index && img.progress < 90 
                ? { ...img, progress: img.progress + 10 } 
                : img
            )
          );
        }, 100);

        const { error: uploadError } = await supabase.storage
          .from(selectedBucket)
          .upload(filePath, image.file);

        clearInterval(progressInterval);

        if (uploadError) {
          throw uploadError;
        }

        const { data: { publicUrl } } = supabase.storage
          .from(selectedBucket)
          .getPublicUrl(filePath);

        // Update to success
        setSelectedFiles(prev => 
          prev.map((img, i) => 
            i === index 
              ? { ...img, status: 'success', progress: 100, url: publicUrl }
              : img
          )
        );

        resolve(publicUrl);
      } catch (error) {
        // Update to error
        setSelectedFiles(prev => 
          prev.map((img, i) => 
            i === index 
              ? { 
                  ...img, 
                  status: 'error', 
                  progress: 0, 
                  error: error instanceof Error ? error.message : 'Upload failed'
                }
              : img
          )
        );
        reject(error);
      }
    });
  };

  const uploadToGallery = async (imageUrl: string, visibility: 'public' | 'members_only', caption: string, targetModelId: string) => {
    try {
      // Get the current max order index
      const { data: existingPhotos, error: fetchError } = await supabase
        .from('model_gallery')
        .select('order_index')
        .eq('model_id', targetModelId)
        .order('order_index', { ascending: false })
        .limit(1);

      if (fetchError) throw fetchError;

      const maxOrderIndex = existingPhotos?.[0]?.order_index ?? -1;

      const { error: insertError } = await supabase
        .from('model_gallery')
        .insert({
          model_id: targetModelId,
          image_url: imageUrl,
          visibility,
          caption: caption || null,
          order_index: maxOrderIndex + 1
        });

      if (insertError) throw insertError;
    } catch (error) {
      console.error('Error adding to gallery:', error);
      throw error;
    }
  };

  const uploadAllFiles = async () => {
    if (selectedFiles.length === 0) return;

    if (selectedModels.length === 0) {
      toast.error('Please select at least one model to upload photos to');
      return;
    }

    setUploading(true);
    const pendingFiles = selectedFiles
      .map((file, index) => ({ file, index }))
      .filter(({ file }) => file.status === 'pending');

    try {
      const uploadPromises = pendingFiles.map(({ file, index }) => 
        uploadSingleFile(file, index)
      );

      const uploadedUrls = await Promise.allSettled(uploadPromises);
      
      // Process successful uploads
      const successfulUploads: { url: string; visibility: 'public' | 'members_only'; caption?: string }[] = [];
      
      for (let i = 0; i < uploadedUrls.length; i++) {
        const result = uploadedUrls[i];
        if (result.status === 'fulfilled') {
          const fileIndex = pendingFiles[i].index;
          const fileData = selectedFiles[fileIndex];
          
          // Add to gallery for each selected model
          for (const targetModelId of selectedModels) {
            await uploadToGallery(result.value, fileData.visibility, fileData.caption || '', targetModelId);
          }
          
          successfulUploads.push({
            url: result.value,
            visibility: fileData.visibility,
            caption: fileData.caption
          });
        }
      }

      const successCount = successfulUploads.length;
      const errorCount = pendingFiles.length - successCount;

      if (successCount > 0) {
        toast.success(`Successfully uploaded ${successCount} images to ${selectedModels.length} model(s)`);
        onUploadComplete?.(successfulUploads);
      }
      if (errorCount > 0) {
        toast.error(`Failed to upload ${errorCount} images`);
      }
    } catch (error) {
      console.error('Bulk upload error:', error);
      toast.error('Bulk upload failed');
    } finally {
      setUploading(false);
    }
  };

  const clearAll = () => {
    setSelectedFiles([]);
  };

  const retryFailed = () => {
    setSelectedFiles(prev => 
      prev.map(file => 
        file.status === 'error' 
          ? { ...file, status: 'pending', progress: 0, error: undefined }
          : file
      )
    );
  };

  const getStatusIcon = (status: UploadedImage['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      case 'uploading':
        return <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />;
      default:
        return <ImageIcon className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: UploadedImage['status']) => {
    switch (status) {
      case 'success':
        return 'border-green-200 bg-green-50';
      case 'error':
        return 'border-red-200 bg-red-50';
      case 'uploading':
        return 'border-blue-200 bg-blue-50';
      default:
        return 'border-gray-200 bg-white';
    }
  };

  const pendingCount = selectedFiles.filter(f => f.status === 'pending').length;
  const uploadingCount = selectedFiles.filter(f => f.status === 'uploading').length;
  const successCount = selectedFiles.filter(f => f.status === 'success').length;
  const errorCount = selectedFiles.filter(f => f.status === 'error').length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FolderOpen className="w-5 h-5" />
            Advanced Image Upload
          </CardTitle>
          <CardDescription>
            Upload multiple images with individual visibility controls and caption options
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Model Selection */}
          {!modelId && (
            <div>
              <Label>Select Models</Label>
              <div className="mt-2 space-y-2">
                {availableModels.map(model => (
                  <div key={model.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`model-${model.id}`}
                      checked={selectedModels.includes(model.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedModels(prev => [...prev, model.id]);
                        } else {
                          setSelectedModels(prev => prev.filter(id => id !== model.id));
                        }
                      }}
                    />
                    <Label htmlFor={`model-${model.id}`} className="text-sm">
                      {model.name}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Global Visibility Setting */}
          <div>
            <Label>Default Visibility</Label>
            <Select value={globalVisibility} onValueChange={updateGlobalVisibility}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="public">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    All Public
                  </div>
                </SelectItem>
                <SelectItem value="members_only">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    All Members Only
                  </div>
                </SelectItem>
                <SelectItem value="mixed">
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    Mixed (Set Individual)
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* File Selection */}
          <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6">
            <div className="text-center">
              <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
              <div className="mt-4">
                <Label htmlFor="advanced-file-upload" className="cursor-pointer">
                  <div className="flex items-center justify-center">
                    <Button type="button" disabled={uploading}>
                      Select Images
                    </Button>
                  </div>
                </Label>
                <Input
                  id="advanced-file-upload"
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleFileSelection}
                  disabled={uploading}
                  className="sr-only"
                />
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Select multiple images to upload. PNG, JPG, WEBP supported.
              </p>
            </div>
          </div>

          {/* Upload Summary */}
          {selectedFiles.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline">
                Total: {selectedFiles.length}
              </Badge>
              {pendingCount > 0 && (
                <Badge variant="secondary">
                  Pending: {pendingCount}
                </Badge>
              )}
              {uploadingCount > 0 && (
                <Badge className="bg-blue-100 text-blue-800">
                  Uploading: {uploadingCount}
                </Badge>
              )}
              {successCount > 0 && (
                <Badge className="bg-green-100 text-green-800">
                  Success: {successCount}
                </Badge>
              )}
              {errorCount > 0 && (
                <Badge variant="destructive">
                  Failed: {errorCount}
                </Badge>
              )}
            </div>
          )}

          {/* Action Buttons */}
          {selectedFiles.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <Button 
                onClick={uploadAllFiles} 
                disabled={uploading || pendingCount === 0 || selectedModels.length === 0}
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload {pendingCount} Images
              </Button>
              {errorCount > 0 && (
                <Button variant="outline" onClick={retryFailed} disabled={uploading}>
                  Retry Failed
                </Button>
              )}
              <Button variant="outline" onClick={clearAll} disabled={uploading}>
                Clear All
              </Button>
            </div>
          )}

          {/* File List */}
          {selectedFiles.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Selected Images</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {selectedFiles.map((image, index) => (
                    <div
                      key={index}
                      className={`flex items-start gap-4 p-4 rounded-lg border ${getStatusColor(image.status)}`}
                    >
                      <div className="flex-shrink-0">
                        {getStatusIcon(image.status)}
                      </div>
                      
                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium truncate">
                            {image.file.name}
                          </p>
                          <Badge variant={image.visibility === 'public' ? 'default' : 'secondary'}>
                            {image.visibility === 'public' ? 'Public' : 'Members Only'}
                          </Badge>
                        </div>
                        
                        <p className="text-xs text-muted-foreground">
                          {(image.file.size / 1024 / 1024).toFixed(2)} MB
                        </p>

                        {image.status === 'uploading' && (
                          <Progress value={image.progress} className="w-full h-2" />
                        )}

                        {image.error && (
                          <p className="text-xs text-red-600">{image.error}</p>
                        )}

                        {(image.status === 'pending' || image.status === 'error') && globalVisibility === 'mixed' && (
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant={image.visibility === 'public' ? 'default' : 'outline'}
                              onClick={() => updateImageVisibility(index, 'public')}
                              disabled={uploading}
                            >
                              <Globe className="w-3 h-3 mr-1" />
                              Public
                            </Button>
                            <Button
                              size="sm"
                              variant={image.visibility === 'members_only' ? 'default' : 'outline'}
                              onClick={() => updateImageVisibility(index, 'members_only')}
                              disabled={uploading}
                            >
                              <Users className="w-3 h-3 mr-1" />
                              Members
                            </Button>
                          </div>
                        )}

                        {(image.status === 'pending' || image.status === 'error') && (
                          <div>
                            <Input
                              placeholder="Add caption (optional)"
                              value={image.caption || ''}
                              onChange={(e) => updateImageCaption(index, e.target.value)}
                              disabled={uploading}
                              className="text-sm"
                            />
                          </div>
                        )}
                      </div>

                      {image.status === 'pending' && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeFile(index)}
                          disabled={uploading}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
};