import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ImageUpload } from '../ImageUpload';
import { 
  GripVertical, 
  Type, 
  Image as ImageIcon, 
  Plus, 
  Trash2, 
  MoveUp, 
  MoveDown,
  Monitor,
  Smartphone,
  Palette,
  Settings
} from 'lucide-react';

export interface ContentPart {
  id: string;
  type: 'text' | 'image' | 'hero';
  order: number;
  content?: string;
  title?: string;
  imageUrl?: string;
  imageUrlMobile?: string;
  caption?: string;
  buttonText?: string;
  buttonLink?: string;
  overlay?: boolean;
}

interface AdvancedContentEditorProps {
  parts: ContentPart[];
  onPartsChange: (parts: ContentPart[]) => void;
  pageType?: 'page' | 'hero';
}

export const AdvancedContentEditor: React.FC<AdvancedContentEditorProps> = ({ 
  parts, 
  onPartsChange,
  pageType = 'page'
}) => {
  const [draggedItem, setDraggedItem] = useState<number | null>(null);
  const [globalSettings, setGlobalSettings] = useState({
    primaryColor: '#000000',
    secondaryColor: '#666666',
    buttonStyle: 'default'
  });

  const addPart = (type: 'text' | 'image' | 'hero') => {
    const newPart: ContentPart = {
      id: `part-${Date.now()}`,
      type,
      order: parts.length + 1,
      content: type === 'text' ? '' : undefined,
      title: type !== 'image' ? '' : undefined,
      imageUrl: type !== 'text' ? '' : undefined,
      imageUrlMobile: type === 'hero' ? '' : undefined,
      caption: type === 'image' ? '' : undefined,
      buttonText: type === 'hero' ? 'Learn More' : undefined,
      buttonLink: type === 'hero' ? '#' : undefined,
      overlay: type === 'hero' ? true : undefined
    };
    onPartsChange([...parts, newPart]);
  };

  const updatePart = (partId: string, updates: Partial<ContentPart>) => {
    const updatedParts = parts.map(part => 
      part.id === partId ? { ...part, ...updates } : part
    );
    onPartsChange(updatedParts);
  };

  const removePart = (partId: string) => {
    const filteredParts = parts.filter(part => part.id !== partId);
    const reorderedParts = filteredParts.map((part, index) => ({
      ...part,
      order: index + 1
    }));
    onPartsChange(reorderedParts);
  };

  const movePart = (partId: string, direction: 'up' | 'down') => {
    const partIndex = parts.findIndex(part => part.id === partId);
    if (partIndex === -1) return;

    const newIndex = direction === 'up' ? partIndex - 1 : partIndex + 1;
    if (newIndex < 0 || newIndex >= parts.length) return;

    const reorderedParts = [...parts];
    [reorderedParts[partIndex], reorderedParts[newIndex]] = 
    [reorderedParts[newIndex], reorderedParts[partIndex]];

    reorderedParts.forEach((part, index) => {
      part.order = index + 1;
    });

    onPartsChange(reorderedParts);
  };

  const handleDragStart = (index: number) => {
    setDraggedItem(index);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, dropIndex: number) => {
    e.preventDefault();
    if (draggedItem === null) return;

    const reorderedParts = [...parts];
    const draggedPart = reorderedParts[draggedItem];
    reorderedParts.splice(draggedItem, 1);
    reorderedParts.splice(dropIndex, 0, draggedPart);

    reorderedParts.forEach((part, index) => {
      part.order = index + 1;
    });

    onPartsChange(reorderedParts);
    setDraggedItem(null);
  };

  return (
    <Tabs defaultValue="content" className="space-y-6">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="content">Content Parts</TabsTrigger>
        <TabsTrigger value="settings">Global Settings</TabsTrigger>
      </TabsList>

      <TabsContent value="content" className="space-y-6">
        {/* Add Part Buttons */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          <Button
            variant="outline"
            onClick={() => addPart('text')}
            className="h-20 flex-col"
          >
            <Type className="w-6 h-6 mb-2" />
            Add Text Part
          </Button>
          <Button
            variant="outline"
            onClick={() => addPart('image')}
            className="h-20 flex-col"
          >
            <ImageIcon className="w-6 h-6 mb-2" />
            Add Image Part
          </Button>
          {pageType === 'hero' && (
            <Button
              variant="outline"
              onClick={() => addPart('hero')}
              className="h-20 flex-col"
            >
              <Monitor className="w-6 h-6 mb-2" />
              Add Hero Banner
            </Button>
          )}
        </div>

        {/* Parts List */}
        <div className="space-y-4">
          {parts.map((part, index) => (
            <Card
              key={part.id}
              className="relative border-l-4 border-l-primary"
              draggable
              onDragStart={() => handleDragStart(index)}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, index)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
                    <Badge variant="outline" className="font-mono">
                      Part {part.order}
                    </Badge>
                    <Badge variant={
                      part.type === 'text' ? 'default' : 
                      part.type === 'hero' ? 'destructive' : 'secondary'
                    }>
                      {part.type === 'text' ? (
                        <>
                          <Type className="w-3 h-3 mr-1" />
                          Text Content
                        </>
                      ) : part.type === 'hero' ? (
                        <>
                          <Monitor className="w-3 h-3 mr-1" />
                          Hero Banner
                        </>
                      ) : (
                        <>
                          <ImageIcon className="w-3 h-3 mr-1" />
                          Image
                        </>
                      )}
                    </Badge>
                  </CardTitle>
                  <div className="flex items-center gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => movePart(part.id, 'up')}
                      disabled={index === 0}
                    >
                      <MoveUp className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => movePart(part.id, 'down')}
                      disabled={index === parts.length - 1}
                    >
                      <MoveDown className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removePart(part.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {part.type === 'text' ? (
                  <>
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Heading (Optional)</Label>
                      <Input
                        placeholder="Section heading..."
                        value={part.title || ''}
                        onChange={(e) => updatePart(part.id, { title: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Content</Label>
                      <Textarea
                        placeholder="Write your content here..."
                        value={part.content || ''}
                        onChange={(e) => updatePart(part.id, { content: e.target.value })}
                        rows={8}
                      />
                    </div>
                  </>
                ) : part.type === 'hero' ? (
                  <div className="space-y-6">
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Title</Label>
                      <Input
                        placeholder="Hero banner title..."
                        value={part.title || ''}
                        onChange={(e) => updatePart(part.id, { title: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Subtitle</Label>
                      <Textarea
                        placeholder="Hero banner subtitle..."
                        value={part.content || ''}
                        onChange={(e) => updatePart(part.id, { content: e.target.value })}
                        rows={3}
                      />
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium mb-2 flex items-center gap-2">
                          <Monitor className="w-4 h-4" />
                          Desktop Image
                        </Label>
                        <ImageUpload
                          bucket="hero-images"
                          value={part.imageUrl || ''}
                          onChange={(url) => updatePart(part.id, { imageUrl: url })}
                        />
                      </div>
                      <div>
                        <Label className="text-sm font-medium mb-2 flex items-center gap-2">
                          <Smartphone className="w-4 h-4" />
                          Mobile Image
                        </Label>
                        <ImageUpload
                          bucket="hero-images"
                          value={part.imageUrlMobile || ''}
                          onChange={(url) => updatePart(part.id, { imageUrlMobile: url })}
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium mb-2 block">Button Text</Label>
                        <Input
                          placeholder="Call to action text..."
                          value={part.buttonText || ''}
                          onChange={(e) => updatePart(part.id, { buttonText: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label className="text-sm font-medium mb-2 block">Button Link</Label>
                        <Input
                          placeholder="/contact or https://..."
                          value={part.buttonLink || ''}
                          onChange={(e) => updatePart(part.id, { buttonLink: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`overlay-${part.id}`}
                        checked={part.overlay || false}
                        onCheckedChange={(checked) => updatePart(part.id, { overlay: checked })}
                      />
                      <Label htmlFor={`overlay-${part.id}`}>Dark overlay</Label>
                    </div>
                  </div>
                ) : (
                  <>
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Image</Label>
                      <ImageUpload
                        bucket="models"
                        value={part.imageUrl || ''}
                        onChange={(url) => updatePart(part.id, { imageUrl: url })}
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-medium mb-2 block">Caption (Optional)</Label>
                      <Input
                        placeholder="Image caption or alt text..."
                        value={part.caption || ''}
                        onChange={(e) => updatePart(part.id, { caption: e.target.value })}
                      />
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {parts.length === 0 && (
          <Card className="border-dashed border-2">
            <CardContent className="flex flex-col items-center justify-center py-16 text-center">
              <Plus className="w-16 h-16 text-muted-foreground mb-4" />
              <h3 className="text-xl font-medium mb-2">No content parts added yet</h3>
              <p className="text-muted-foreground mb-6 max-w-md">
                Build your page by adding structured content parts. Each part can be reordered and edited independently.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                <Button variant="outline" onClick={() => addPart('text')}>
                  <Type className="w-4 h-4 mr-2" />
                  Add Text
                </Button>
                <Button variant="outline" onClick={() => addPart('image')}>
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Add Image
                </Button>
                {pageType === 'hero' && (
                  <Button variant="outline" onClick={() => addPart('hero')}>
                    <Monitor className="w-4 h-4 mr-2" />
                    Add Hero
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </TabsContent>

      <TabsContent value="settings">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="w-5 h-5" />
              Global Design Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium mb-2 block">Primary Color</Label>
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={globalSettings.primaryColor}
                    onChange={(e) => setGlobalSettings(prev => ({ 
                      ...prev, 
                      primaryColor: e.target.value 
                    }))}
                    className="w-20"
                  />
                  <Input
                    value={globalSettings.primaryColor}
                    onChange={(e) => setGlobalSettings(prev => ({ 
                      ...prev, 
                      primaryColor: e.target.value 
                    }))}
                    placeholder="#000000"
                    className="flex-1"
                  />
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium mb-2 block">Secondary Color</Label>
                <div className="flex gap-2">
                  <Input
                    type="color"
                    value={globalSettings.secondaryColor}
                    onChange={(e) => setGlobalSettings(prev => ({ 
                      ...prev, 
                      secondaryColor: e.target.value 
                    }))}
                    className="w-20"
                  />
                  <Input
                    value={globalSettings.secondaryColor}
                    onChange={(e) => setGlobalSettings(prev => ({ 
                      ...prev, 
                      secondaryColor: e.target.value 
                    }))}
                    placeholder="#666666"
                    className="flex-1"
                  />
                </div>
              </div>
            </div>
            
            <div>
              <Label className="text-sm font-medium mb-2 block">Button Style</Label>
              <Select 
                value={globalSettings.buttonStyle}
                onValueChange={(value) => setGlobalSettings(prev => ({ 
                  ...prev, 
                  buttonStyle: value 
                }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Default</SelectItem>
                  <SelectItem value="rounded">Rounded</SelectItem>
                  <SelectItem value="sharp">Sharp Corners</SelectItem>
                  <SelectItem value="pill">Pill Shape</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Card className="bg-muted/30">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Settings className="w-4 h-4" />
                  These settings will be applied globally across all content parts and can be overridden per part if needed.
                </div>
              </CardContent>
            </Card>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
};