import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Save, 
  Plus, 
  Trash2, 
  ArrowUp, 
  ArrowDown,
  Type,
  Image as ImageIcon,
  FileText,
  List,
  AlertCircle
} from 'lucide-react';
import { ImageUpload } from '@/components/ImageUpload';

interface ContentSection {
  id: string;
  type: 'hero' | 'text' | 'image' | 'list';
  title?: string;
  content?: string;
  image_url?: string;
  subtitle?: string;
  button_text?: string;
  button_link?: string;
  items?: string[];
}

interface PageEditorProps {
  pageSlug: string;
  contentItems: any[];
  onContentUpdate: () => void;
}

export const PageEditor: React.FC<PageEditorProps> = ({
  pageSlug,
  contentItems,
  onContentUpdate
}) => {
  const [content, setContent] = useState<any>(null);
  const [sections, setSections] = useState<ContentSection[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const pageContent = contentItems.find(item => item.slug === pageSlug);
    if (pageContent) {
      setContent(pageContent);
      setSections(pageContent.content?.sections || []);
    } else {
      setContent(null);
      setSections([]);
    }
  }, [pageSlug, contentItems]);

  const sectionTypes = [
    { type: 'hero', title: 'Hero Section', icon: Type, description: 'Main banner with title and subtitle' },
    { type: 'text', title: 'Text Content', icon: FileText, description: 'Paragraph text content' },
    { type: 'image', title: 'Image', icon: ImageIcon, description: 'Single image with caption' },
    { type: 'list', title: 'List', icon: List, description: 'Bulleted list of items' }
  ];

  const generateSectionId = () => `section_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  const addSection = (type: ContentSection['type']) => {
    const baseSection: ContentSection = {
      id: generateSectionId(),
      type,
      title: 'New Section Title',
      content: 'Add your content here...'
    };

    let newSection: ContentSection = { ...baseSection };

    switch (type) {
      case 'hero':
        newSection = {
          ...baseSection,
          subtitle: 'Add a subtitle',
          button_text: 'Learn More',
          button_link: '#',
          image_url: ''
        };
        break;
      case 'list':
        newSection = {
          ...baseSection,
          items: ['List item 1', 'List item 2', 'List item 3']
        };
        break;
      case 'image':
        newSection = {
          ...baseSection,
          title: 'Image Title',
          image_url: '',
          content: 'Image caption'
        };
        break;
    }

    setSections(prev => [...prev, newSection]);
  };

  const updateSection = (index: number, updatedSection: Partial<ContentSection>) => {
    setSections(prev => 
      prev.map((section, i) => 
        i === index ? { ...section, ...updatedSection } : section
      )
    );
  };

  const removeSection = (index: number) => {
    if (sections.length === 1) {
      toast.error('Cannot delete the last section');
      return;
    }
    setSections(prev => prev.filter((_, i) => i !== index));
  };

  const moveSection = (index: number, direction: 'up' | 'down') => {
    if (
      (direction === 'up' && index === 0) ||
      (direction === 'down' && index === sections.length - 1)
    ) {
      return;
    }

    const newSections = [...sections];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    [newSections[index], newSections[targetIndex]] = [newSections[targetIndex], newSections[index]];
    setSections(newSections);
  };

  const updateListItem = (sectionIndex: number, itemIndex: number, value: string) => {
    const section = sections[sectionIndex];
    const updatedItems = [...(section.items || [])];
    updatedItems[itemIndex] = value;
    updateSection(sectionIndex, { items: updatedItems });
  };

  const addListItem = (sectionIndex: number) => {
    const section = sections[sectionIndex];
    const updatedItems = [...(section.items || []), 'New item'];
    updateSection(sectionIndex, { items: updatedItems });
  };

  const removeListItem = (sectionIndex: number, itemIndex: number) => {
    const section = sections[sectionIndex];
    const updatedItems = (section.items || []).filter((_, i) => i !== itemIndex);
    updateSection(sectionIndex, { items: updatedItems });
  };

  const saveContent = async () => {
    setSaving(true);
    try {
      const contentData = {
        title: content?.title || `${pageSlug.charAt(0).toUpperCase() + pageSlug.slice(1)} Page`,
        slug: pageSlug,
        content: JSON.parse(JSON.stringify({ sections })),
        status: 'published'
      };

      if (content?.id) {
        const { error } = await supabase
          .from('content_items')
          .update(contentData)
          .eq('id', content.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('content_items')
          .insert(contentData);

        if (error) throw error;
      }

      toast.success('Content saved successfully');
      onContentUpdate();
    } catch (error) {
      console.error('Error saving content:', error);
      toast.error('Failed to save content');
    } finally {
      setSaving(false);
    }
  };

  if (sections.length === 0) {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          No content sections yet. Add your first section to get started.
          <div className="flex flex-wrap gap-2 mt-3">
            {sectionTypes.map((sectionType) => (
              <Button
                key={sectionType.type}
                size="sm"
                variant="outline"
                onClick={() => addSection(sectionType.type as ContentSection['type'])}
                className="flex items-center gap-2"
              >
                <sectionType.icon className="w-4 h-4" />
                {sectionType.title}
              </Button>
            ))}
          </div>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      {/* Section Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h3 className="font-semibold">Editing: {pageSlug.charAt(0).toUpperCase() + pageSlug.slice(1)}</h3>
          <p className="text-sm text-muted-foreground">{sections.length} section{sections.length !== 1 ? 's' : ''}</p>
        </div>
        <div className="flex items-center gap-2">
          <Select onValueChange={(value) => addSection(value as ContentSection['type'])}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Add Section" />
            </SelectTrigger>
            <SelectContent>
              {sectionTypes.map((sectionType) => (
                <SelectItem key={sectionType.type} value={sectionType.type}>
                  <div className="flex items-center gap-2">
                    <sectionType.icon className="w-4 h-4" />
                    {sectionType.title}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={saveContent} disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Saving...' : 'Save Page'}
          </Button>
        </div>
      </div>

      {/* Sections */}
      <div className="space-y-4">
        {sections.map((section, index) => {
          const sectionType = sectionTypes.find(type => type.type === section.type);
          
          return (
            <Card key={section.id} className="border-l-4 border-l-primary/30">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {sectionType && <sectionType.icon className="w-4 h-4" />}
                    <Badge variant="secondary">{section.type}</Badge>
                    <span className="text-sm text-muted-foreground">Section {index + 1}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => moveSection(index, 'up')}
                      disabled={index === 0}
                    >
                      <ArrowUp className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => moveSection(index, 'down')}
                      disabled={index === sections.length - 1}
                    >
                      <ArrowDown className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removeSection(index)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Title */}
                <div>
                  <Label htmlFor={`title-${index}`}>Title</Label>
                  <Input
                    id={`title-${index}`}
                    value={section.title || ''}
                    onChange={(e) => updateSection(index, { title: e.target.value })}
                    placeholder="Section title"
                  />
                </div>

                {/* Hero Section Fields */}
                {section.type === 'hero' && (
                  <>
                    <div>
                      <Label htmlFor={`subtitle-${index}`}>Subtitle</Label>
                      <Input
                        id={`subtitle-${index}`}
                        value={section.subtitle || ''}
                        onChange={(e) => updateSection(index, { subtitle: e.target.value })}
                        placeholder="Hero subtitle"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor={`button-text-${index}`}>Button Text</Label>
                        <Input
                          id={`button-text-${index}`}
                          value={section.button_text || ''}
                          onChange={(e) => updateSection(index, { button_text: e.target.value })}
                          placeholder="Button text"
                        />
                      </div>
                      <div>
                        <Label htmlFor={`button-link-${index}`}>Button Link</Label>
                        <Input
                          id={`button-link-${index}`}
                          value={section.button_link || ''}
                          onChange={(e) => updateSection(index, { button_link: e.target.value })}
                          placeholder="/contact"
                        />
                      </div>
                    </div>
                  </>
                )}

                {/* Content */}
                {section.type !== 'list' && (
                  <div>
                    <Label htmlFor={`content-${index}`}>Content</Label>
                    <Textarea
                      id={`content-${index}`}
                      value={section.content || ''}
                      onChange={(e) => updateSection(index, { content: e.target.value })}
                      placeholder="Add your content here..."
                      rows={4}
                    />
                  </div>
                )}

                {/* Image Upload */}
                {(section.type === 'image' || section.type === 'hero') && (
                  <div>
                    <Label>Image</Label>
                    <ImageUpload
                      value={section.image_url}
                      onChange={(url: string) => updateSection(index, { image_url: url })}
                      bucket="website-images"
                    />
                  </div>
                )}

                {/* List Items */}
                {section.type === 'list' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>List Items</Label>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => addListItem(index)}
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        Add Item
                      </Button>
                    </div>
                    {(section.items || []).map((item, itemIndex) => (
                      <div key={itemIndex} className="flex items-center gap-2">
                        <Input
                          value={item}
                          onChange={(e) => updateListItem(index, itemIndex, e.target.value)}
                          placeholder={`Item ${itemIndex + 1}`}
                        />
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeListItem(index, itemIndex)}
                          className="text-destructive"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};