import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AdvancedContentEditor, type ContentPart } from './AdvancedContentEditor';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  Save, 
  Eye, 
  Upload, 
  FileText, 
  AlertCircle
} from 'lucide-react';

interface ContentItem {
  id: string;
  title: string;
  slug: string;
  content: any;
  status: string;
  author_id?: string | null;
  created_at: string;
  updated_at: string;
  published_at?: string | null;
}

interface EnhancedPageEditorProps {
  pageSlug: string;
  contentItems: ContentItem[];
  onContentUpdate: () => void;
}

export const EnhancedPageEditor: React.FC<EnhancedPageEditorProps> = ({
  pageSlug,
  contentItems,
  onContentUpdate
}) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [currentItem, setCurrentItem] = useState<ContentItem | null>(null);
  const [parts, setParts] = useState<ContentPart[]>([]);
  const [pageSettings, setPageSettings] = useState({
    title: '',
    status: 'draft' as 'draft' | 'published',
    metaDescription: '',
    keywords: ''
  });

  // Load existing content when page changes
  useEffect(() => {
    loadPageContent();
  }, [pageSlug, contentItems]);

  const loadPageContent = async () => {
    setLoading(true);
    try {
      // Find existing content item
      const existingItem = contentItems.find(item => item.slug === pageSlug);
      
      if (existingItem) {
        setCurrentItem(existingItem);
        setPageSettings({
          title: existingItem.title,
          status: existingItem.status as 'draft' | 'published',
          metaDescription: existingItem.content?.seo?.description || '',
          keywords: existingItem.content?.seo?.keywords || ''
        });
        
        // Convert existing content to parts format
        if (existingItem.content?.parts) {
          setParts(existingItem.content.parts);
        } else if (existingItem.content?.sections) {
          // Convert old format to new parts format
          const convertedParts = existingItem.content.sections.map((section: any, index: number) => ({
            id: `part-${index}`,
            type: section.type || 'text',
            order: index + 1,
            title: section.title,
            content: section.content,
            imageUrl: section.imageUrl,
            imageUrlMobile: section.imageUrlMobile,
            caption: section.caption,
            buttonText: section.buttonText,
            buttonLink: section.buttonLink,
            overlay: section.overlay
          }));
          setParts(convertedParts);
        } else {
          setParts([]);
        }
      } else {
        // Create new page structure
        setCurrentItem(null);
        setPageSettings({
          title: pageSlug.charAt(0).toUpperCase() + pageSlug.slice(1).replace(/-/g, ' '),
          status: 'draft',
          metaDescription: '',
          keywords: ''
        });
        setParts([]);
      }
    } catch (error) {
      console.error('Error loading page content:', error);
      toast({
        description: 'Failed to load page content',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const saveContent = async (publish: boolean = false) => {
    setSaving(true);
    try {
      const contentData = {
        parts: parts as any,
        seo: {
          description: pageSettings.metaDescription,
          keywords: pageSettings.keywords
        },
        lastModified: new Date().toISOString()
      } as any;

      const updateData = {
        title: pageSettings.title,
        slug: pageSlug,
        content: contentData,
        status: publish ? 'published' : pageSettings.status,
        updated_at: new Date().toISOString(),
        ...(publish && { published_at: new Date().toISOString() })
      };

      if (currentItem) {
        // Update existing item
        const { error } = await supabase
          .from('content_items')
          .update(updateData)
          .eq('id', currentItem.id);

        if (error) throw error;
      } else {
        // Create new item
        const { error } = await supabase
          .from('content_items')
          .insert(updateData);

        if (error) throw error;
      }

      toast({
        description: publish ? 'Page published successfully' : 'Page saved successfully'
      });
      
      onContentUpdate();
    } catch (error) {
      console.error('Error saving content:', error);
      toast({
        description: 'Failed to save content',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const previewUrl = `/${pageSlug}`;

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <div className="text-center space-y-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="text-muted-foreground">Loading page content...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <Card>
        <CardHeader>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                {pageSettings.title}
              </CardTitle>
              <CardDescription>
                Editing page: /{pageSlug} • {parts.length} content parts
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={pageSettings.status === 'published' ? 'default' : 'secondary'}>
                {pageSettings.status}
              </Badge>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(previewUrl, '_blank')}
              >
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>
              <Button
                variant="outline"
                onClick={() => saveContent(false)}
                disabled={saving}
              >
                <Save className="w-4 h-4 mr-2" />
                Save Draft
              </Button>
              <Button
                onClick={() => saveContent(true)}
                disabled={saving}
              >
                <Upload className="w-4 h-4 mr-2" />
                {pageSettings.status === 'published' ? 'Update' : 'Publish'}
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="content" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="content">Content Editor</TabsTrigger>
          <TabsTrigger value="settings">Page Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="content">
          <Card>
            <CardHeader>
              <CardTitle>Content Parts</CardTitle>
              <CardDescription>
                Build your page using structured content parts that can be reordered and edited independently
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AdvancedContentEditor
                parts={parts}
                onPartsChange={setParts}
                pageType={pageSlug === 'homepage' ? 'hero' : 'page'}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <div className="grid gap-6">
            {/* Basic Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Settings</CardTitle>
                <CardDescription>
                  Configure page title, status, and visibility
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title">Page Title</Label>
                  <Input
                    id="title"
                    value={pageSettings.title}
                    onChange={(e) => setPageSettings(prev => ({ 
                      ...prev, 
                      title: e.target.value 
                    }))}
                    placeholder="Enter page title..."
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="published"
                    checked={pageSettings.status === 'published'}
                    onCheckedChange={(checked) => setPageSettings(prev => ({
                      ...prev,
                      status: checked ? 'published' : 'draft'
                    }))}
                  />
                  <Label htmlFor="published">Published</Label>
                </div>
              </CardContent>
            </Card>

            {/* SEO Settings */}
            <Card>
              <CardHeader>
                <CardTitle>SEO Settings</CardTitle>
                <CardDescription>
                  Optimize your page for search engines
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="meta-description">Meta Description</Label>
                  <Input
                    id="meta-description"
                    value={pageSettings.metaDescription}
                    onChange={(e) => setPageSettings(prev => ({ 
                      ...prev, 
                      metaDescription: e.target.value 
                    }))}
                    placeholder="Brief description for search results..."
                    maxLength={160}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {pageSettings.metaDescription.length}/160 characters
                  </p>
                </div>
                
                <div>
                  <Label htmlFor="keywords">Keywords</Label>
                  <Input
                    id="keywords"
                    value={pageSettings.keywords}
                    onChange={(e) => setPageSettings(prev => ({ 
                      ...prev, 
                      keywords: e.target.value 
                    }))}
                    placeholder="keyword1, keyword2, keyword3..."
                  />
                </div>
              </CardContent>
            </Card>

            {/* Page Preview */}
            <Card>
              <CardHeader>
                <CardTitle>Page Preview</CardTitle>
                <CardDescription>
                  How this page will appear in search results and social shares
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg p-4 space-y-2">
                  <div className="text-blue-600 text-sm">/{pageSlug}</div>
                  <div className="text-lg font-medium text-purple-600 hover:underline cursor-pointer">
                    {pageSettings.title || 'Page Title'}
                  </div>
                  <div className="text-sm text-gray-600">
                    {pageSettings.metaDescription || 'Meta description will appear here...'}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Save Status */}
      {saving && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Saving changes...
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
};