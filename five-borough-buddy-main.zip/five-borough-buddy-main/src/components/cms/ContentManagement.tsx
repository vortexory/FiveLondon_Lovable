import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { DataTable } from '@/components/DataTable';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  FileText, 
  Search, 
  Image as ImageIcon, 
  Edit3,
  Plus,
  Globe,
  BarChart3,
  Eye,
  Trash2
} from 'lucide-react';
import { EnhancedPageEditor } from './EnhancedPageEditor';
import { SEOManager } from './SEOManager';
import { BulkImageUpload } from './BulkImageUpload';

interface ContentItem {
  id: string;
  title: string;
  slug: string;
  content: any;
  status: string;
  author_id?: string | null;
  created_at: string;
  updated_at: string;
  published_at?: string | null;
}

interface ContentStats {
  totalPages: number;
  publishedPages: number;
  draftPages: number;
  totalSEOPages: number;
}

export const ContentManagement: React.FC = () => {
  const { toast } = useToast();
  const [contentItems, setContentItems] = useState<ContentItem[]>([]);
  const [selectedPage, setSelectedPage] = useState<string>('homepage');
  const [stats, setStats] = useState<ContentStats>({
    totalPages: 0,
    publishedPages: 0,
    draftPages: 0,
    totalSEOPages: 0
  });
  const [newPageTitle, setNewPageTitle] = useState('');
  const [newPageSlug, setNewPageSlug] = useState('');

  const pages = [
    { id: 'homepage', title: 'Homepage', icon: FileText, description: 'Main landing page' },
    { id: 'about', title: 'About Us', icon: FileText, description: 'Company information' },
    { id: 'services', title: 'Services', icon: FileText, description: 'Service offerings' },
    { id: 'contact', title: 'Contact', icon: FileText, description: 'Contact information' },
    { id: 'locations', title: 'London Locations', icon: FileText, description: 'Available locations' },
    { id: 'join-us', title: 'Join Us', icon: FileText, description: 'Recruitment page' },
    { id: 'privacy', title: 'Privacy Policy', icon: FileText, description: 'Privacy policy page' },
    { id: 'terms', title: 'Terms of Service', icon: FileText, description: 'Terms and conditions' }
  ];

  useEffect(() => {
    fetchContentItems();
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { data: contentData, error: contentError } = await supabase
        .from('content_items')
        .select('status');

      const { data: seoData, error: seoError } = await supabase
        .from('page_seo')
        .select('id');

      if (contentError || seoError) throw contentError || seoError;

      const published = (contentData || []).filter(item => item.status === 'published').length;
      const draft = (contentData || []).filter(item => item.status === 'draft').length;

      setStats({
        totalPages: (contentData || []).length,
        publishedPages: published,
        draftPages: draft,
        totalSEOPages: (seoData || []).length
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const fetchContentItems = async () => {
    try {
      const { data, error } = await supabase
        .from('content_items')
        .select('*')
        .order('updated_at', { ascending: false });

      if (error) throw error;
      
      const mappedData = (data || []).map(item => ({
        id: item.id,
        title: item.title,
        slug: item.slug,
        content: item.content,
        status: item.status,
        author_id: item.author_id,
        created_at: item.created_at || new Date().toISOString(),
        updated_at: item.updated_at || new Date().toISOString(),
        published_at: item.published_at
      }));
      
      setContentItems(mappedData);
      fetchStats();
    } catch (error) {
      console.error('Error fetching content:', error);
      toast({
        description: 'Failed to fetch content',
        variant: 'destructive'
      });
    }
  };

  const createNewPage = async () => {
    if (!newPageTitle.trim() || !newPageSlug.trim()) {
      toast({
        description: 'Please enter both title and slug',
        variant: 'destructive'
      });
      return;
    }

    const slug = newPageSlug.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-');
    
    // Check if slug already exists
    const existsInPages = pages.some(page => page.id === slug);
    const existsInContent = contentItems.some(item => item.slug === slug);
    
    if (existsInPages || existsInContent) {
      toast({
        description: 'A page with this slug already exists',
        variant: 'destructive'
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('content_items')
        .insert({
          title: newPageTitle,
          slug: slug,
          content: { sections: [] },
          status: 'draft'
        });

      if (error) throw error;

      toast({
        description: 'New page created successfully'
      });
      setNewPageTitle('');
      setNewPageSlug('');
      fetchContentItems();
      setSelectedPage(slug);
    } catch (error) {
      console.error('Error creating page:', error);
      toast({
        description: 'Failed to create page',
        variant: 'destructive'
      });
    }
  };

  const deleteContentItem = async (id: string) => {
    if (!confirm('Are you sure you want to delete this page? This action cannot be undone.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('content_items')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        description: 'Page deleted successfully'
      });
      fetchContentItems();
      
      // Reset selected page if the deleted page was selected
      const deletedItem = contentItems.find(item => item.id === id);
      if (deletedItem && selectedPage === deletedItem.slug) {
        setSelectedPage('homepage');
      }
    } catch (error) {
      console.error('Error deleting page:', error);
      toast({
        description: 'Failed to delete page',
        variant: 'destructive'
      });
    }
  };

  const contentColumns = [
    {
      key: 'title',
      header: 'Title',
      render: (item: ContentItem) => (
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-muted-foreground" />
          <span className="font-medium">{item.title}</span>
        </div>
      )
    },
    {
      key: 'slug',
      header: 'Slug',
      render: (item: ContentItem) => (
        <code className="text-xs bg-muted px-2 py-1 rounded">/{item.slug}</code>
      )
    },
    {
      key: 'status',
      header: 'Status',
      render: (item: ContentItem) => (
        <Badge variant={item.status === 'published' ? 'default' : 'secondary'}>
          {item.status}
        </Badge>
      )
    },
    {
      key: 'updated_at',
      header: 'Last Updated',
      render: (item: ContentItem) => (
        <div className="text-sm">
          <div>{new Date(item.updated_at).toLocaleDateString()}</div>
          <div className="text-muted-foreground text-xs">
            {new Date(item.updated_at).toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </div>
        </div>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (item: ContentItem) => (
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setSelectedPage(item.slug)}
          >
            <Edit3 className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteContentItem(item.id)}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">Content Management System</h1>
          <p className="text-muted-foreground">
            Manage all website content, pages, SEO settings, and media uploads
          </p>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" />
              <div>
                <p className="text-sm text-muted-foreground">Total Pages</p>
                <p className="text-2xl font-bold">{stats.totalPages}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-green-600" />
              <div>
                <p className="text-sm text-muted-foreground">Published</p>
                <p className="text-2xl font-bold">{stats.publishedPages}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Edit3 className="w-4 h-4 text-yellow-600" />
              <div>
                <p className="text-sm text-muted-foreground">Drafts</p>
                <p className="text-2xl font-bold">{stats.draftPages}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-purple-600" />
              <div>
                <p className="text-sm text-muted-foreground">SEO Optimized</p>
                <p className="text-2xl font-bold">{stats.totalSEOPages}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pages" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          <TabsTrigger value="pages" className="flex items-center gap-2">
            <Edit3 className="w-4 h-4" />
            Page Editor
          </TabsTrigger>
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Page Overview
          </TabsTrigger>
          <TabsTrigger value="seo" className="flex items-center gap-2">
            <Search className="w-4 h-4" />
            SEO Manager
          </TabsTrigger>
          <TabsTrigger value="media" className="flex items-center gap-2">
            <ImageIcon className="w-4 h-4" />
            Media Upload
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pages" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Page Editor</CardTitle>
              <CardDescription>
                Select a page to edit its content and layout, or create a new custom page
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Create New Page */}
              <Card className="bg-muted/30">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Create New Page
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row gap-3">
                    <Input
                      placeholder="Page title (e.g., 'Our Team')"
                      value={newPageTitle}
                      onChange={(e) => setNewPageTitle(e.target.value)}
                      className="flex-1"
                    />
                    <Input
                      placeholder="URL slug (e.g., 'our-team')"
                      value={newPageSlug}
                      onChange={(e) => setNewPageSlug(e.target.value)}
                      className="flex-1"
                    />
                    <Button onClick={createNewPage} className="whitespace-nowrap">
                      <Plus className="w-4 h-4 mr-2" />
                      Create Page
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Pre-built Pages */}
              <div>
                <h3 className="font-semibold mb-3">Pre-built Pages</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {pages.map((page) => {
                    const Icon = page.icon;
                    const hasContent = contentItems.some(item => item.slug === page.id);
                    
                    return (
                      <Card
                        key={page.id}
                        className={`cursor-pointer transition-all hover:shadow-md ${
                          selectedPage === page.id ? 'ring-2 ring-primary border-primary' : ''
                        }`}
                        onClick={() => setSelectedPage(page.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-3">
                              <Icon className="w-5 h-5 text-primary" />
                              <div>
                                <h4 className="font-medium">{page.title}</h4>
                                <p className="text-sm text-muted-foreground">{page.description}</p>
                              </div>
                            </div>
                            {!hasContent && (
                              <Badge variant="outline" className="text-xs">
                                New
                              </Badge>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>

              {/* Custom Pages */}
              {contentItems.filter(item => !pages.some(p => p.id === item.slug)).length > 0 && (
                <div>
                  <h3 className="font-semibold mb-3">Custom Pages</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {contentItems
                      .filter(item => !pages.some(p => p.id === item.slug))
                      .map((item) => (
                        <Card
                          key={item.id}
                          className={`cursor-pointer transition-all hover:shadow-md ${
                            selectedPage === item.slug ? 'ring-2 ring-primary border-primary' : ''
                          }`}
                          onClick={() => setSelectedPage(item.slug)}
                        >
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-3">
                                <Globe className="w-5 h-5 text-primary" />
                                <div>
                                  <h4 className="font-medium">{item.title}</h4>
                                  <p className="text-sm text-muted-foreground">/{item.slug}</p>
                                </div>
                              </div>
                              <Badge 
                                variant={item.status === 'published' ? 'default' : 'secondary'}
                                className="text-xs"
                              >
                                {item.status}
                              </Badge>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </div>
              )}

              {selectedPage && (
                <Card className="border-t-4 border-t-primary">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Edit3 className="w-5 h-5" />
                      Editing: {selectedPage.charAt(0).toUpperCase() + selectedPage.slice(1)}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                 <EnhancedPageEditor
                   pageSlug={selectedPage}
                   contentItems={contentItems}
                   onContentUpdate={fetchContentItems}
                 />
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Page Overview
              </CardTitle>
              <CardDescription>
                Manage all your website pages in one place
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DataTable
                data={contentItems}
                columns={contentColumns}
                emptyStateIcon={FileText}
                emptyStateTitle="No pages found"
                emptyStateDescription="Create your first page to get started."
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo">
          <SEOManager />
        </TabsContent>

        <TabsContent value="media">
          <BulkImageUpload />
        </TabsContent>
      </Tabs>
    </div>
  );
};