import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ImageUpload } from '@/components/ImageUpload';
import { BlockEditor, type BlockData } from '@/components/blocks/BlockEditor';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Eye, Save, X, Image as ImageIcon, FileText, Settings } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface BlogPost {
  id: string;
  title: string;
  content?: string | null;
  excerpt?: string | null;
  author?: string | null;
  category?: string | null;
  image?: string | null;
  image_local?: string | null;
  image_url_local?: string | null;
  is_published: boolean | null;
  created_at: string;
  updated_at: string;
  published_at?: string | null;
  slug: string;
  seo_keywords?: string | null;
  meta_description?: string | null;
  read_time?: number | null;
  service_keywords?: string[] | null;
  blocks?: BlockData[] | null;
}

interface BlogEditorData {
  title: string;
  content: string;
  excerpt: string;
  author: string;
  category: string;
  image: string;
  is_published: boolean;
  seo_keywords: string;
  meta_description: string;
  blocks: BlockData[];
}

interface BlogEditorProps {
  isOpen: boolean;
  onClose: () => void;
  post?: BlogPost | null;
  onSave: () => void;
}

export const BlogEditor: React.FC<BlogEditorProps> = ({
  isOpen,
  onClose,
  post,
  onSave
}) => {
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('content');
  const [formData, setFormData] = useState<BlogEditorData>({
    title: '',
    content: '',
    excerpt: '',
    author: '',
    category: '',
    image: '',
    is_published: false,
    seo_keywords: '',
    meta_description: '',
    blocks: []
  });

  // Helper function to convert blocks to HTML content for backward compatibility
  const blocksToHtml = (blocks: BlockData[]): string => {
    return blocks.map(block => {
      switch (block.type) {
        case 'text':
          let textHtml = block.content;
          if (block.title) {
            textHtml = `<h3>${block.title}</h3>\n${textHtml}`;
          }
          return textHtml;
        case 'image':
          let imageHtml = '';
          
          // Add title if present
          if ((block as any).title) {
            imageHtml += `<h3 style="margin-bottom: 16px; font-size: 18px; font-weight: 600;">${(block as any).title}</h3>\n`;
          }
          
          let imgHtml = `<img src="${block.content}" alt="${block.alt || ''}" style="width: 100%; height: auto; border-radius: 8px;" />`;
          let figureContent = imgHtml;
          
          // Add caption and description
          if (block.caption || block.description) {
            let captionHtml = '';
            if (block.caption) {
              captionHtml += `<strong style="display: block; margin-bottom: 4px;">${block.caption}</strong>`;
            }
            if (block.description) {
              captionHtml += `<span style="color: #666; font-size: 14px;">${block.description}</span>`;
            }
            figureContent = `<figure style="margin: 20px 0;">${imgHtml}<figcaption style="margin-top: 12px; text-align: center; font-style: italic;">${captionHtml}</figcaption></figure>`;
          }
          
          imageHtml += figureContent;
          return imageHtml;
        default:
          return '';
      }
    }).join('\n\n');
  };

  useEffect(() => {
    if (post) {
      // Try to load blocks first, fall back to content
      let blocks: BlockData[] = [];
      
      if (post.blocks && Array.isArray(post.blocks)) {
        blocks = post.blocks;
      } else if (post.content) {
        // Convert existing content to a single text block
        blocks = [{
          id: `block-${Date.now()}`,
          type: 'text',
          content: post.content,
          order: 1
        }];
      }

      setFormData({
        title: post.title || '',
        content: post.content || '',
        excerpt: post.excerpt || '',
        author: post.author || '',
        category: post.category || '',
        image: post.image || post.image_local || post.image_url_local || '',
        is_published: !!post.is_published,
        seo_keywords: post.seo_keywords || '',
        meta_description: post.meta_description || '',
        blocks
      });
    } else {
      setFormData({
        title: '',
        content: '',
        excerpt: '',
        author: '',
        category: '',
        image: '',
        is_published: false,
        seo_keywords: '',
        meta_description: '',
        blocks: []
      });
    }
  }, [post]);

  const calculateReadTime = (content: string): number => {
    if (!content) return 1;
    const wordsPerMinute = 200;
    const words = content.trim().split(/\s+/).length;
    return Math.ceil(words / wordsPerMinute) || 1;
  };

  const generateSlug = (title: string): string => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  };

  const handleSave = async () => {
    if (!formData.title.trim()) {
      toast.error('Title is required');
      return;
    }

    if (formData.blocks.length === 0) {
      toast.error('At least one content block is required');
      return;
    }

    setSaving(true);

    try {
      const slug = generateSlug(formData.title);
      const htmlContent = blocksToHtml(formData.blocks);
      const readTime = calculateReadTime(htmlContent);

interface BlogPostData {
  title: string;
  content: string;
  blocks: any[];
  excerpt?: string | null;
  author?: string | null;
  category?: string | null;
  image?: string | null;
  image_url_local?: string | null;
  image_local?: string | null;
  slug: string;
  read_time?: number | null;
  meta_description?: string | null;
  seo_keywords?: string | null;
  service_keywords?: string[] | null;
  is_published: boolean;
  updated_at?: string;
  published_at?: string | null;
}

      const saveData: BlogPostData = {
        title: formData.title,
        content: htmlContent, // Keep for backward compatibility
        blocks: formData.blocks, // New structured content
        excerpt: formData.excerpt || null,
        author: formData.author || null,
        category: formData.category || null,
        image: formData.image || null,
        // Store both the image URL and local reference for consistency
        image_url_local: formData.image && formData.image.includes('supabase') ? formData.image : null,
        image_local: formData.image && formData.image.includes('supabase') ? formData.image.split('/').pop() : null,
        is_published: formData.is_published,
        seo_keywords: formData.seo_keywords || null,
        meta_description: formData.meta_description || null,
        slug,
        read_time: readTime,
        updated_at: new Date().toISOString()
      };

      if (post) {
        // Update existing post
        if (formData.is_published && !post.is_published) {
          saveData.published_at = new Date().toISOString();
        } else if (!formData.is_published && post.is_published) {
          saveData.published_at = null;
        }

        const { error } = await supabase
          .from('blog_posts')
          .update(saveData)
          .eq('id', post.id);

        if (error) throw error;
        toast.success('Blog post updated successfully');
      } else {
        // Create new post
        if (formData.is_published) {
          saveData.published_at = new Date().toISOString();
        }

        const { error } = await supabase
          .from('blog_posts')
          .insert(saveData);

        if (error) throw error;
        toast.success('Blog post created successfully');
      }

      onSave();
      onClose();
    } catch (error: any) {
      console.error('Error saving blog post:', error);
      toast.error(`Failed to ${post ? 'update' : 'create'} blog post`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl h-[90vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            {post ? 'Edit Blog Post' : 'Create New Blog Post'}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="grid w-full grid-cols-4 flex-shrink-0">
            <TabsTrigger value="content" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Content
            </TabsTrigger>
            <TabsTrigger value="media" className="flex items-center gap-2">
              <ImageIcon className="w-4 h-4" />
              Media
            </TabsTrigger>
            <TabsTrigger value="seo" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              SEO
            </TabsTrigger>
            <TabsTrigger value="preview" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Preview
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-hidden">
            <TabsContent value="content" className="h-full overflow-y-auto p-4 space-y-4">
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Enter an engaging blog post title"
                  className="text-lg"
                />
              </div>

              <div>
                <Label htmlFor="excerpt">Excerpt</Label>
                <Textarea
                  id="excerpt"
                  value={formData.excerpt}
                  onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                  placeholder="Write a compelling excerpt that will appear in previews and search results"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="author">Author</Label>
                  <Input
                    id="author"
                    value={formData.author}
                    onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                    placeholder="Author name"
                  />
                </div>
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    placeholder="e.g., News, Tips, Reviews"
                  />
                </div>
              </div>

              <div>
                <Label className="text-base font-medium">Content Blocks *</Label>
                <p className="text-sm text-muted-foreground mb-4">
                  Build your blog post using text and image blocks. Drag to reorder.
                </p>
                <BlockEditor
                  blocks={formData.blocks}
                  onChange={(blocks) => setFormData({ ...formData, blocks })}
                />
              </div>
            </TabsContent>

            <TabsContent value="media" className="h-full overflow-y-auto p-4 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Featured Image</CardTitle>
                </CardHeader>
                <CardContent>
                  <ImageUpload
                    bucket="blog-images"
                    value={formData.image}
                    onChange={(url) => setFormData({ ...formData, image: url })}
                    label="Upload Featured Image"
                  />
                  <p className="text-sm text-muted-foreground mt-2">
                    Choose an eye-catching image that represents your blog post. Recommended size: 1200x630px.
                  </p>
                  {formData.image && (
                    <div className="mt-4">
                      <img
                        src={formData.image}
                        alt="Featured image preview"
                        className="w-full max-w-md rounded-lg border"
                      />
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="seo" className="h-full overflow-y-auto p-4 space-y-4">
              <div>
                <Label htmlFor="meta-description">Meta Description</Label>
                <Textarea
                  id="meta-description"
                  value={formData.meta_description}
                  onChange={(e) => setFormData({ ...formData, meta_description: e.target.value })}
                  placeholder="Write a compelling meta description for search engines (150-160 characters)"
                  rows={3}
                />
                <div className="text-sm text-muted-foreground mt-1">
                  {formData.meta_description.length}/160 characters
                </div>
              </div>

              <div>
                <Label htmlFor="seo-keywords">SEO Keywords</Label>
                <Input
                  id="seo-keywords"
                  value={formData.seo_keywords}
                  onChange={(e) => setFormData({ ...formData, seo_keywords: e.target.value })}
                  placeholder="Enter keywords separated by commas"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Add relevant keywords that people might search for to find this post.
                </p>
              </div>

              <div>
                <Label>URL Slug</Label>
                <div className="p-3 bg-muted rounded-md">
                  <code className="text-sm">
                    /blog/{generateSlug(formData.title) || 'your-post-title'}
                  </code>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="preview" className="h-full overflow-y-auto p-4">
              <Card className="flex-1">
                <CardHeader>
                  <div className="space-y-2">
                    <CardTitle className="text-2xl">
                      {formData.title || 'Your Blog Post Title'}
                    </CardTitle>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      {formData.author && <span>By {formData.author}</span>}
                      {formData.category && (
                        <Badge variant="outline">{formData.category}</Badge>
                      )}
                      <span>{calculateReadTime(formData.content)} min read</span>
                    </div>
                    {formData.excerpt && (
                      <p className="text-muted-foreground italic">
                        {formData.excerpt}
                      </p>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {formData.image && (
                    <div className="w-full h-64 rounded-lg mb-6 overflow-hidden bg-muted">
                      <img
                        src={formData.image}
                        alt="Featured"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  {!formData.image && (
                    <div className="w-full h-64 rounded-lg mb-6 overflow-hidden bg-muted flex flex-col items-center justify-center text-muted-foreground">
                      <ImageIcon className="w-12 h-12 mb-2" />
                      <p className="text-sm">No featured image</p>
                      <p className="text-xs">Upload an image in the Media tab</p>
                    </div>
                  )}
                  <div className="prose prose-slate max-w-none prose-headings:text-foreground prose-p:text-foreground prose-strong:text-foreground prose-ul:text-foreground prose-ol:text-foreground prose-li:text-foreground prose-a:text-primary hover:prose-a:text-primary/80">
                    {formData.blocks.length > 0 ? (
                      <div className="space-y-6">
                        {formData.blocks.map((block, index) => (
                          <div key={block.id} className="border-l-2 border-muted pl-4">
                            <div className="text-xs text-muted-foreground mb-2 font-medium">
                              Part {index + 1} - {block.type === 'text' ? 'Text' : 'Image'}
                            </div>
                            {block.type === 'text' ? (
                              <div>
                                {(block as any).title && (
                                  <h3 className="text-lg font-semibold mb-3">{(block as any).title}</h3>
                                )}
                                <div dangerouslySetInnerHTML={{ __html: block.content }} />
                              </div>
                            ) : (
                              <div>
                                {(block as any).title && (
                                  <h3 className="text-lg font-semibold mb-3">{(block as any).title}</h3>
                                )}
                                {block.content && (
                                  <div>
                                    <img
                                      src={block.content}
                                      alt={(block as any).alt || 'Blog image'}
                                      className="w-full rounded-lg mb-3"
                                    />
                                    {(block.caption || block.description) && (
                                      <div className="text-center text-sm">
                                        {block.caption && (
                                          <div className="font-medium mb-1">{block.caption}</div>
                                        )}
                                        {block.description && (
                                          <div className="text-muted-foreground">{block.description}</div>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                )}
                                {(block as any).caption && (
                                  <p className="text-sm text-muted-foreground mt-2 italic">
                                    {(block as any).caption}
                                  </p>
                                )}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-muted-foreground">No content blocks added yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>

        <div className="flex items-center justify-between pt-4 border-t flex-shrink-0">
          <div className="flex items-center space-x-2">
            <Switch
              id="publish"
              checked={formData.is_published}
              onCheckedChange={(checked) => setFormData({ ...formData, is_published: checked })}
            />
            <Label htmlFor="publish">
              {formData.is_published ? 'Published' : 'Draft'}
            </Label>
          </div>
          
          <div className="flex space-x-2">
            <Button variant="outline" onClick={onClose} disabled={saving}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saving || !formData.title.trim() || formData.blocks.length === 0}>
              {saving ? (
                <LoadingSpinner size={16} text={`${post ? 'Updating' : 'Creating'}...`} />
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {post ? 'Update Post' : 'Create Post'}
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};