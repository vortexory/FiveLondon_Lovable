import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DataTable } from '@/components/DataTable';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Users,
  UserCheck,
  UserX,
  Edit,
  Trash2,
  Shield,
  ShieldCheck,
  Clock
} from 'lucide-react';

interface Profile {
  id: string;
  email?: string | null;
  role: string | null;
  status: string | null;
  approved_at?: string | null;
  requested_at?: string | null;
  approved_by?: string | null;
  created_at: string;
  updated_at: string;
}

export const UserManagement: React.FC = () => {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<{ [key: string]: boolean }>({});
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProfiles((data || []).map(profile => ({
        ...profile,
        email: profile.email ?? undefined,
        role: profile.role ?? 'user',
        status: profile.status ?? 'pending',
        approved_at: profile.approved_at ?? undefined,
        requested_at: profile.requested_at ?? undefined,
        approved_by: profile.approved_by ?? undefined
      })));
    } catch (error: any) {
      console.error('Error fetching profiles:', error);
      toast.error('Failed to fetch user profiles');
    } finally {
      setLoading(false);
    }
  };

interface ProfileUpdateData {
  status: string;
  updated_at: string;
  approved_at?: string;
}

  const updateUserStatus = async (profileId: string, newStatus: string) => {
    setActionLoading({ [`status_${profileId}`]: true });

    try {
      const updateData: ProfileUpdateData = {
        status: newStatus,
        updated_at: new Date().toISOString()
      };

      if (newStatus === 'approved') {
        updateData.approved_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('profiles')
        .update(updateData)
        .eq('id', profileId);

      if (error) throw error;
      
      toast.success(`User ${newStatus} successfully`);
      await fetchProfiles();
    } catch (error: any) {
      console.error('Error updating user status:', error);
      toast.error('Failed to update user status');
    } finally {
      setActionLoading({ [`status_${profileId}`]: false });
    }
  };

  const updateUserRole = async (profileId: string, newRole: string) => {
    setActionLoading({ [`role_${profileId}`]: true });

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ 
          role: newRole,
          updated_at: new Date().toISOString()
        })
        .eq('id', profileId);

      if (error) throw error;
      
      toast.success(`User role updated to ${newRole}`);
      await fetchProfiles();
    } catch (error: any) {
      console.error('Error updating user role:', error);
      toast.error('Failed to update user role');
    } finally {
      setActionLoading({ [`role_${profileId}`]: false });
    }
  };

  const deleteUser = async (profile: Profile) => {
    if (!confirm(`Are you sure you want to delete user ${profile.email}? This action cannot be undone.`)) {
      return;
    }

    setActionLoading({ [`delete_${profile.id}`]: true });

    try {
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', profile.id);

      if (error) throw error;
      
      toast.success('User deleted successfully');
      await fetchProfiles();
    } catch (error: any) {
      console.error('Error deleting user:', error);
      toast.error('Failed to delete user');
    } finally {
      setActionLoading({ [`delete_${profile.id}`]: false });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'default';
      case 'pending': return 'secondary';
      case 'rejected': return 'destructive';
      default: return 'outline';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'destructive';
      case 'super_admin': return 'destructive';
      case 'team': return 'default';
      default: return 'secondary';
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin':
      case 'super_admin':
        return <ShieldCheck className="w-3 h-3" />;
      case 'team':
        return <Shield className="w-3 h-3" />;
      default:
        return <Users className="w-3 h-3" />;
    }
  };

  const openDetailsDialog = (profile: Profile) => {
    setSelectedProfile(profile);
    setIsDetailsDialogOpen(true);
  };

  const columns = [
    {
      key: 'email',
      header: 'Email',
      render: (profile: Profile) => (
        <span className="font-medium">{profile.email || 'No email'}</span>
      )
    },
    {
      key: 'role',
      header: 'Role',
      render: (profile: Profile) => (
        <Badge variant={getRoleColor(profile.role ?? 'user')} className="flex items-center gap-1">
          {getRoleIcon(profile.role ?? 'user')}
          {profile.role ?? 'user'}
        </Badge>
      )
    },
    {
      key: 'status',
      header: 'Status',
      render: (profile: Profile) => (
        <Badge variant={getStatusColor(profile.status ?? 'pending')}>
          {profile.status ?? 'pending'}
        </Badge>
      )
    },
    {
      key: 'created_at',
      header: 'Joined',
      render: (profile: Profile) => (
        <div className="text-sm">
          <div>{new Date(profile.created_at).toLocaleDateString()}</div>
          <div className="text-muted-foreground">
            {new Date(profile.created_at).toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </div>
        </div>
      )
    },
    {
      key: 'approved_at',
      header: 'Approved',
      render: (profile: Profile) => (
        profile.approved_at ? (
          <div className="text-sm">
            <div>{new Date(profile.approved_at).toLocaleDateString()}</div>
          </div>
        ) : (
          <span className="text-muted-foreground text-sm">Not approved</span>
        )
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (profile: Profile) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => openDetailsDialog(profile)}
          >
            <Edit className="w-3 h-3" />
          </Button>
          
          {profile.status === 'pending' && (
            <div className="flex gap-1">
              <Button
                size="sm"
                variant="default"
                onClick={() => updateUserStatus(profile.id, 'approved')}
                disabled={actionLoading[`status_${profile.id}`]}
                title="Approve User"
              >
                <UserCheck className="w-3 h-3" />
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={() => updateUserStatus(profile.id, 'rejected')}
                disabled={actionLoading[`status_${profile.id}`]}
                title="Reject User"
              >
                <UserX className="w-3 h-3" />
              </Button>
            </div>
          )}
          
          {profile.role === 'user' && profile.status === 'approved' && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => updateUserRole(profile.id, 'team')}
              disabled={actionLoading[`role_${profile.id}`]}
              title="Promote to Team"
            >
              <Shield className="w-3 h-3" />
            </Button>
          )}
          
          <Button
            size="sm"
            variant="destructive"
            onClick={() => deleteUser(profile)}
            disabled={actionLoading[`delete_${profile.id}`]}
            title="Delete User"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      )
    }
  ];

  const stats = {
    total: profiles.length,
    approved: profiles.filter(p => p.status === 'approved').length,
    pending: profiles.filter(p => p.status === 'pending').length,
    admins: profiles.filter(p => p.role === 'admin' || p.role === 'super_admin').length
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner size={32} text="Loading user management..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Users className="w-5 h-5" />
        <h2 className="text-2xl font-bold">User Management</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Total Users</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-green-600" />
              <div>
                <p className="text-sm text-muted-foreground">Approved</p>
                <p className="text-2xl font-bold">{stats.approved}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-yellow-600" />
              <div>
                <p className="text-sm text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold">{stats.pending}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-red-600" />
              <div>
                <p className="text-sm text-muted-foreground">Admins</p>
                <p className="text-2xl font-bold">{stats.admins}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User Profiles</CardTitle>
        </CardHeader>
        <CardContent>
          <DataTable
            data={profiles}
            columns={columns}
            emptyStateIcon={Users}
            emptyStateTitle="No users found"
            emptyStateDescription="Users will appear here when they register."
          />
        </CardContent>
      </Card>

      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
          </DialogHeader>
          
          {selectedProfile && (
            <div className="space-y-4">
              <div>
                <strong>Email:</strong> {selectedProfile.email || 'No email'}
              </div>
              <div className="flex items-center gap-2">
                <strong>Role:</strong> 
                <Badge variant={getRoleColor(selectedProfile.role ?? 'user')} className="flex items-center gap-1">
                  {getRoleIcon(selectedProfile.role ?? 'user')}
                  {selectedProfile.role ?? 'user'}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <strong>Status:</strong> 
                <Badge variant={getStatusColor(selectedProfile.status ?? 'pending')}>
                  {selectedProfile.status ?? 'pending'}
                </Badge>
              </div>
              <div>
                <strong>Joined:</strong> {new Date(selectedProfile.created_at).toLocaleString()}
              </div>
              {selectedProfile.approved_at && (
                <div>
                  <strong>Approved:</strong> {new Date(selectedProfile.approved_at).toLocaleString()}
                </div>
              )}
              
              <div className="flex gap-2 pt-4">
                {selectedProfile.role === 'user' && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      updateUserRole(selectedProfile.id, 'team');
                      setIsDetailsDialogOpen(false);
                    }}
                    disabled={actionLoading[`role_${selectedProfile.id}`]}
                  >
                    Promote to Team
                  </Button>
                )}
                
                {selectedProfile.role === 'team' && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      updateUserRole(selectedProfile.id, 'admin');
                      setIsDetailsDialogOpen(false);
                    }}
                    disabled={actionLoading[`role_${selectedProfile.id}`]}
                  >
                    Promote to Admin
                  </Button>
                )}
                
                {selectedProfile.status === 'pending' && (
                  <>
                    <Button
                      size="sm"
                      variant="default"
                      onClick={() => {
                        updateUserStatus(selectedProfile.id, 'approved');
                        setIsDetailsDialogOpen(false);
                      }}
                      disabled={actionLoading[`status_${selectedProfile.id}`]}
                    >
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => {
                        updateUserStatus(selectedProfile.id, 'rejected');
                        setIsDetailsDialogOpen(false);
                      }}
                      disabled={actionLoading[`status_${selectedProfile.id}`]}
                    >
                      Reject
                    </Button>
                  </>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};