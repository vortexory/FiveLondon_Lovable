import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { LoadingSpinner } from './LoadingSpinner';
import { EmptyState } from './EmptyState';
import type { LucideIcon } from 'lucide-react';

interface Column<T> {
  key: keyof T | string;
  header: string;
  render?: (item: T) => React.ReactNode;
  className?: string;
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  loading?: boolean;
  emptyStateIcon?: LucideIcon;
  emptyStateTitle?: string;
  emptyStateDescription?: string;
  emptyStateAction?: string;
  onEmptyStateAction?: () => void;
}

export function DataTable<T extends Record<string, any>>({
  data,
  columns,
  loading = false,
  emptyStateIcon,
  emptyStateTitle,
  emptyStateDescription,
  emptyStateAction,
  onEmptyStateAction
}: DataTableProps<T>) {
  if (loading) {
    return (
      <div className="py-12">
        <LoadingSpinner size={32} text="Loading data..." />
      </div>
    );
  }

  if (data.length === 0 && emptyStateIcon && emptyStateTitle && emptyStateDescription) {
    return (
      <EmptyState
        icon={emptyStateIcon}
        title={emptyStateTitle}
        description={emptyStateDescription}
        actionLabel={emptyStateAction}
        onAction={onEmptyStateAction}
      />
    );
  }

  return (
    <div className="w-full">
      <div className="overflow-x-auto mobile-scroll">
        <Table className="min-w-full">
          <TableHeader>
            <TableRow>
              {columns.map((column) => (
                <TableHead key={String(column.key)} className={column.className}>
                  {column.header}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((item, index) => (
              <TableRow key={item.id || index}>
                {columns.map((column) => (
                  <TableCell key={String(column.key)} className={column.className}>
                    {column.render ? column.render(item) : item[column.key]}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}