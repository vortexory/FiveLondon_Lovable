import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Search, X, Plus, ExternalLink } from 'lucide-react';

interface Characteristic {
  id: string;
  name: string;
  category: string | null;
  description: string | null;
  is_active: boolean;
  seo_path: string | null;
}

interface CharacteristicsSelectorProps {
  selectedCharacteristics: string[];
  onCharacteristicsChange: (characteristics: string[]) => void;
  label?: string;
}

export const CharacteristicsSelector: React.FC<CharacteristicsSelectorProps> = ({
  selectedCharacteristics,
  onCharacteristicsChange,
  label = "Characteristics"
}) => {
  const [characteristics, setCharacteristics] = useState<Characteristic[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    fetchCharacteristics();
  }, []);

  const fetchCharacteristics = async () => {
    try {
      const { data, error } = await supabase
        .from('characteristics')
        .select('*')
        .eq('is_active', true)
        .order('category, order_index, name');

      if (error) throw error;
      setCharacteristics(data || []);
    } catch (error: any) {
      console.error('Error fetching characteristics:', error);
      toast.error('Failed to load characteristics');
    } finally {
      setLoading(false);
    }
  };

  const toggleCharacteristic = (characteristicName: string) => {
    const isSelected = selectedCharacteristics.includes(characteristicName);
    
    if (isSelected) {
      onCharacteristicsChange(
        selectedCharacteristics.filter(name => name !== characteristicName)
      );
    } else {
      onCharacteristicsChange([...selectedCharacteristics, characteristicName]);
    }
  };

  const removeCharacteristic = (characteristicName: string) => {
    onCharacteristicsChange(
      selectedCharacteristics.filter(name => name !== characteristicName)
    );
  };

  const getCharacteristicSeoPath = (name: string): string | null => {
    const characteristic = characteristics.find(char => char.name === name);
    return characteristic?.seo_path || null;
  };

  const filteredCharacteristics = characteristics.filter(char => {
    const matchesSearch = char.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || (char.category || 'general') === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = Array.from(new Set(characteristics.map(char => char.category || 'general'))).sort();
  const groupedCharacteristics = categories.reduce((acc, category) => {
    acc[category] = filteredCharacteristics.filter(char => (char.category || 'general') === category);
    return acc;
  }, {} as Record<string, Characteristic[]>);

  if (loading) {
    return (
      <div className="space-y-2">
        <Label>{label}</Label>
        <div className="animate-pulse bg-muted rounded p-4 h-32"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <Label>{label}</Label>
        
        {/* Selected Characteristics */}
        {selectedCharacteristics.length > 0 && (
          <div className="mt-2 p-3 bg-muted/50 rounded-md">
            <div className="text-sm font-medium mb-2 flex items-center gap-2">
              Selected ({selectedCharacteristics.length}):
              <span className="text-xs text-green-600">✓ SEO Connected</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {selectedCharacteristics.map((name) => {
                const seoPath = getCharacteristicSeoPath(name);
                return (
                  <Badge key={name} variant="secondary" className="flex items-center gap-1">
                    {name}
                    {seoPath && (
                      <span title={`SEO Page: ${seoPath}`}>
                        <ExternalLink className="w-3 h-3 text-blue-500" />
                      </span>
                    )}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-4 w-4 p-0 hover:bg-destructive hover:text-destructive-foreground"
                      onClick={() => removeCharacteristic(name)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                );
              })}
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              These characteristics will automatically link to SEO pages on your main website
            </div>
          </div>
        )}

        {/* Search and Filter */}
        <div className="mt-2 space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              type="text"
              placeholder="Search characteristics..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant={selectedCategory === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory('all')}
            >
              All
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                type="button"
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="capitalize"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Available Characteristics */}
        <Card className="mt-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              Available Characteristics
              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                SEO Optimized
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {selectedCategory === 'all' ? (
              // Show grouped by category
              Object.entries(groupedCharacteristics).map(([category, chars]) => (
                chars.length > 0 && (
                  <div key={category} className="space-y-2">
                    <div className="text-sm font-medium capitalize text-muted-foreground flex items-center gap-2">
                      {category}
                      <span className="text-xs text-blue-600">
                        ({chars.filter(c => c.seo_path).length} SEO pages)
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {chars.map((char) => (
                        <Button
                          key={char.id}
                          type="button"
                          variant={selectedCharacteristics.includes(char.name) ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => toggleCharacteristic(char.name)}
                          className="text-xs flex items-center gap-1"
                          title={char.seo_path ? `SEO Page: ${char.seo_path}` : 'No SEO page configured'}
                        >
                          {selectedCharacteristics.includes(char.name) && (
                            <Plus className="w-3 h-3 mr-1 rotate-45" />
                          )}
                          {char.name}
                          {char.seo_path && (
                            <span>
                              <ExternalLink className="w-3 h-3 ml-1 text-blue-500" />
                            </span>
                          )}
                        </Button>
                      ))}
                    </div>
                  </div>
                )
              ))
            ) : (
              // Show filtered characteristics
              <div className="flex flex-wrap gap-2">
                {filteredCharacteristics.map((char) => (
                  <Button
                    key={char.id}
                    type="button"
                    variant={selectedCharacteristics.includes(char.name) ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => toggleCharacteristic(char.name)}
                    className="text-xs flex items-center gap-1"
                    title={char.seo_path ? `SEO Page: ${char.seo_path}` : 'No SEO page configured'}
                  >
                    {selectedCharacteristics.includes(char.name) && (
                      <Plus className="w-3 h-3 mr-1 rotate-45" />
                    )}
                    {char.name}
                    {char.seo_path && (
                      <span>
                        <ExternalLink className="w-3 h-3 ml-1 text-blue-500" />
                      </span>
                    )}
                  </Button>
                ))}
              </div>
            )}
            
            {filteredCharacteristics.length === 0 && (
              <div className="text-center py-4 text-muted-foreground">
                No characteristics found matching your search.
              </div>
            )}
          </CardContent>
        </Card>

        {/* SEO Information */}
        <div className="mt-2 p-3 bg-blue-50 rounded-md border border-blue-200">
          <div className="text-sm font-medium text-blue-900 mb-1">SEO Integration</div>
          <div className="text-xs text-blue-700">
            Selected characteristics automatically link to dedicated SEO pages on your main website 
            (e.g., /characteristics/blonde-escorts, /characteristics/vip-escorts). This improves search 
            engine visibility and helps users find models with specific characteristics.
          </div>
        </div>
      </div>
    </div>
  );
};