import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DataTable } from '@/components/DataTable';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { 
  Plus, 
  Edit, 
  Trash2, 
  ArrowUp, 
  ArrowDown, 
  Eye, 
  EyeOff,
  Save,
  X,
  HelpCircle
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface FAQ {
  id: string;
  question: string;
  answer: string;
  order_index: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface FAQFormData {
  question: string;
  answer: string;
  is_active: boolean;
}

export const FAQManagement: React.FC = () => {
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<{ [key: string]: boolean }>({});
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingFAQ, setEditingFAQ] = useState<FAQ | null>(null);
  const [formData, setFormData] = useState<FAQFormData>({
    question: '',
    answer: '',
    is_active: true
  });

  useEffect(() => {
    fetchFAQs();
  }, []);

  const fetchFAQs = async () => {
    try {
      const { data, error } = await supabase
        .from('faqs')
        .select('*')
        .order('order_index', { ascending: true });

      if (error) throw error;
      setFaqs(data || []);
    } catch (error: any) {
      console.error('Error fetching FAQs:', error);
      toast.error('Failed to load FAQs');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!formData.question.trim() || !formData.answer.trim()) {
      toast.error('Question and answer are required');
      return;
    }

    setActionLoading({ save: true });

    try {
      if (editingFAQ) {
        // Update existing FAQ
        const { error } = await supabase
          .from('faqs')
          .update({
            question: formData.question.trim(),
            answer: formData.answer.trim(),
            is_active: formData.is_active,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingFAQ.id);

        if (error) throw error;
        toast.success('FAQ updated successfully');
      } else {
        // Create new FAQ
        const maxOrderIndex = Math.max(...faqs.map(faq => faq.order_index), 0);
        
        const { error } = await supabase
          .from('faqs')
          .insert({
            question: formData.question.trim(),
            answer: formData.answer.trim(),
            is_active: formData.is_active,
            order_index: maxOrderIndex + 1
          });

        if (error) throw error;
        toast.success('FAQ created successfully');
      }

      await fetchFAQs();
      handleCloseDialog();
    } catch (error: any) {
      console.error('Error saving FAQ:', error);
      toast.error(`Failed to ${editingFAQ ? 'update' : 'create'} FAQ`);
    } finally {
      setActionLoading({ save: false });
    }
  };

  const handleDelete = async (faq: FAQ) => {
    if (!confirm('Are you sure you want to delete this FAQ?')) return;

    setActionLoading({ [`delete_${faq.id}`]: true });

    try {
      const { error } = await supabase
        .from('faqs')
        .delete()
        .eq('id', faq.id);

      if (error) throw error;
      
      toast.success('FAQ deleted successfully');
      await fetchFAQs();
    } catch (error: any) {
      console.error('Error deleting FAQ:', error);
      toast.error('Failed to delete FAQ');
    } finally {
      setActionLoading({ [`delete_${faq.id}`]: false });
    }
  };

  const handleToggleActive = async (faq: FAQ) => {
    setActionLoading({ [`toggle_${faq.id}`]: true });

    try {
      const { error } = await supabase
        .from('faqs')
        .update({ 
          is_active: !faq.is_active,
          updated_at: new Date().toISOString()
        })
        .eq('id', faq.id);

      if (error) throw error;
      
      toast.success(`FAQ ${!faq.is_active ? 'activated' : 'deactivated'} successfully`);
      await fetchFAQs();
    } catch (error: any) {
      console.error('Error toggling FAQ status:', error);
      toast.error('Failed to update FAQ status');
    } finally {
      setActionLoading({ [`toggle_${faq.id}`]: false });
    }
  };

  const handleReorder = async (faq: FAQ, direction: 'up' | 'down') => {
    const currentIndex = faqs.findIndex(f => f.id === faq.id);
    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    
    if (targetIndex < 0 || targetIndex >= faqs.length) return;

    setActionLoading({ [`reorder_${faq.id}`]: true });

    try {
      const targetFAQ = faqs[targetIndex];
      
      // Swap order indices
      const updates = [
        {
          id: faq.id,
          order_index: targetFAQ.order_index
        },
        {
          id: targetFAQ.id,
          order_index: faq.order_index
        }
      ];

      for (const update of updates) {
        const { error } = await supabase
          .from('faqs')
          .update({ 
            order_index: update.order_index,
            updated_at: new Date().toISOString()
          })
          .eq('id', update.id);

        if (error) throw error;
      }
      
      toast.success('FAQ order updated successfully');
      await fetchFAQs();
    } catch (error: any) {
      console.error('Error reordering FAQ:', error);
      toast.error('Failed to reorder FAQ');
    } finally {
      setActionLoading({ [`reorder_${faq.id}`]: false });
    }
  };

  const handleEdit = (faq: FAQ) => {
    setEditingFAQ(faq);
    setFormData({
      question: faq.question,
      answer: faq.answer,
      is_active: faq.is_active
    });
    setIsDialogOpen(true);
  };

  const handleAdd = () => {
    setEditingFAQ(null);
    setFormData({
      question: '',
      answer: '',
      is_active: true
    });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingFAQ(null);
    setFormData({
      question: '',
      answer: '',
      is_active: true
    });
  };

  const columns = [
    {
      key: 'order_index',
      header: 'Order',
      render: (faq: FAQ) => (
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm">{faq.order_index}</span>
          <div className="flex flex-col gap-1">
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0"
              onClick={() => handleReorder(faq, 'up')}
              disabled={actionLoading[`reorder_${faq.id}`] || faqs.findIndex(f => f.id === faq.id) === 0}
            >
              <ArrowUp className="w-3 h-3" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0"
              onClick={() => handleReorder(faq, 'down')}
              disabled={actionLoading[`reorder_${faq.id}`] || faqs.findIndex(f => f.id === faq.id) === faqs.length - 1}
            >
              <ArrowDown className="w-3 h-3" />
            </Button>
          </div>
        </div>
      )
    },
    {
      key: 'question',
      header: 'Question',
      render: (faq: FAQ) => (
        <div className="max-w-xs">
          <p className="font-medium text-sm truncate" title={faq.question}>
            {faq.question}
          </p>
        </div>
      )
    },
    {
      key: 'answer',
      header: 'Answer',
      render: (faq: FAQ) => (
        <div className="max-w-md">
          <p className="text-sm text-muted-foreground line-clamp-2" title={faq.answer}>
            {faq.answer}
          </p>
        </div>
      )
    },
    {
      key: 'is_active',
      header: 'Status',
      render: (faq: FAQ) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant={faq.is_active ? "default" : "secondary"}
            onClick={() => handleToggleActive(faq)}
            disabled={actionLoading[`toggle_${faq.id}`]}
            className="flex items-center gap-1"
          >
            {faq.is_active ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
            {faq.is_active ? 'Active' : 'Inactive'}
          </Button>
        </div>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (faq: FAQ) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleEdit(faq)}
            className="flex items-center gap-1"
          >
            <Edit className="w-3 h-3" />
            Edit
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => handleDelete(faq)}
            disabled={actionLoading[`delete_${faq.id}`]}
            className="flex items-center gap-1 text-destructive hover:text-destructive"
          >
            <Trash2 className="w-3 h-3" />
            Delete
          </Button>
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner size={32} text="Loading FAQs..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5" />
            <CardTitle>FAQ Settings</CardTitle>
          </div>
          <Button onClick={handleAdd} className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add FAQ
          </Button>
        </CardHeader>
        <CardContent>
          <DataTable
            data={faqs}
            columns={columns}
            emptyStateIcon={HelpCircle}
            emptyStateTitle="No FAQs found"
            emptyStateDescription="Click 'Add FAQ' to create your first FAQ."
            emptyStateAction="Add FAQ"
            onEmptyStateAction={handleAdd}
          />
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5" />
              {editingFAQ ? 'Edit FAQ' : 'Create New FAQ'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="question">Question *</Label>
              <Input
                id="question"
                value={formData.question}
                onChange={(e) => setFormData({ ...formData, question: e.target.value })}
                placeholder="Enter the frequently asked question"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="answer">Answer *</Label>
              <Textarea
                id="answer"
                value={formData.answer}
                onChange={(e) => setFormData({ ...formData, answer: e.target.value })}
                placeholder="Enter the detailed answer to this question"
                rows={6}
                className="mt-1"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
              <Label htmlFor="is_active">
                {formData.is_active ? 'Active (visible to users)' : 'Inactive (hidden from users)'}
              </Label>
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={handleCloseDialog}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button 
              onClick={handleSave} 
              disabled={actionLoading.save || !formData.question.trim() || !formData.answer.trim()}
            >
              {actionLoading.save ? (
                <LoadingSpinner size={16} text={`${editingFAQ ? 'Updating' : 'Creating'}...`} />
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {editingFAQ ? 'Update FAQ' : 'Create FAQ'}
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};