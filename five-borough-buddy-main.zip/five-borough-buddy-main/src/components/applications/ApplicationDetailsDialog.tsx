import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  User, 
  Mail, 
  Phone, 
  Calendar, 
  MapPin, 
  Ruler, 
  Camera,
  Video,
  Globe,
  Languages,
  GraduationCap,
  Briefcase,
  Heart,
  Shield,
  CheckCircle,
  XCircle,
  AlertTriangle
} from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

interface ModelApplication {
  id: string;
  full_name: string;
  email: string;
  phone?: string | null;
  age?: number | null;
  date_of_birth?: string | null;
  nationality?: string | null;
  languages?: string[] | null;
  height?: string | null;
  measurements?: string | null;
  dress_size?: string | null;
  shoe_size?: string | null;
  hair_color?: string | null;
  eye_color?: string | null;
  tattoos?: string | null;
  piercings?: string | null;
  modeling_experience?: string | null;
  escort_experience?: string | null;
  education?: string | null;
  profession?: string | null;
  interests?: string[] | null;
  instagram_handle?: string | null;
  photos?: string[] | null;
  videos?: string[] | null;
  motivation?: string | null;
  availability?: string | null;
  location_preference?: string | null;
  status: string;
  admin_notes?: string | null;
  created_at: string;
  reviewed_at?: string | null;
  reviewed_by?: string | null;
}

interface ApplicationDetailsDialogProps {
  application: ModelApplication | null;
  isOpen: boolean;
  onClose: () => void;
  onStatusChange: (id: string, status: string, notes?: string) => void;
}

export const ApplicationDetailsDialog: React.FC<ApplicationDetailsDialogProps> = ({
  application,
  isOpen,
  onClose,
  onStatusChange
}) => {
  const [adminNotes, setAdminNotes] = useState('');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (application) {
      setAdminNotes(application.admin_notes || '');
    }
  }, [application]);

  if (!application) return null;

  const handleStatusUpdate = async (newStatus: string) => {
    setUpdating(true);
    try {
      await onStatusChange(application.id, newStatus, adminNotes);
      onClose();
    } catch (error) {
      console.error('Error updating application:', error);
    } finally {
      setUpdating(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'default';
      case 'pending': return 'secondary';
      case 'rejected': return 'destructive';
      default: return 'outline';
    }
  };

  const calculateAge = (dateOfBirth: string) => {
    const today = new Date();
    const birth = new Date(dateOfBirth);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  const hasPhotos = application.photos && application.photos.length > 0;
  const hasVideos = application.videos && application.videos.length > 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <User className="w-6 h-6" />
            Model Application - {application.full_name}
            <Badge variant={getStatusColor(application.status)} className="ml-auto">
              {application.status.toUpperCase()}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="personal" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="personal">Personal</TabsTrigger>
            <TabsTrigger value="physical">Physical</TabsTrigger>
            <TabsTrigger value="experience">Experience</TabsTrigger>
            <TabsTrigger value="media">Media ({(application.photos?.length || 0) + (application.videos?.length || 0)})</TabsTrigger>
            <TabsTrigger value="review">Review</TabsTrigger>
          </TabsList>

          <TabsContent value="personal" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Basic Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Full Name:</span>
                    <span className="text-sm font-semibold">{application.full_name}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <Mail className="w-3 h-3" />
                      Email:
                    </span>
                    <span className="text-sm">{application.email}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      Phone:
                    </span>
                    <span className="text-sm">{application.phone || 'Not provided'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      Age:
                    </span>
                    <span className="text-sm">
                      {application.age || (application.date_of_birth ? calculateAge(application.date_of_birth) : 'Not provided')}
                      {application.date_of_birth && (
                        <span className="text-muted-foreground ml-1">
                          (DOB: {new Date(application.date_of_birth).toLocaleDateString()})
                        </span>
                      )}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <Globe className="w-3 h-3" />
                      Nationality:
                    </span>
                    <span className="text-sm">{application.nationality || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <Languages className="w-3 h-3" />
                      Languages:
                    </span>
                    <div className="text-sm text-right">
                      {application.languages?.length ? (
                        application.languages.map((lang, index) => (
                          <Badge key={index} variant="outline" className="text-xs ml-1">
                            {lang}
                          </Badge>
                        ))
                      ) : (
                        <span className="text-muted-foreground">Not specified</span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Location & Availability */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Location & Availability
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Location Preference:</span>
                    <span className="text-sm">{application.location_preference || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Availability:</span>
                    <span className="text-sm">{application.availability || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Instagram:</span>
                    <span className="text-sm">
                      {application.instagram_handle ? (
                        <a 
                          href={`https://instagram.com/${application.instagram_handle.replace('@', '')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        >
                          @{application.instagram_handle.replace('@', '')}
                        </a>
                      ) : (
                        'Not provided'
                      )}
                    </span>
                  </div>
                </CardContent>
              </Card>

              {/* Education & Profession */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GraduationCap className="w-4 h-4" />
                    Education & Profession
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Education:</span>
                    <span className="text-sm">{application.education || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium flex items-center gap-1">
                      <Briefcase className="w-3 h-3" />
                      Profession:
                    </span>
                    <span className="text-sm">{application.profession || 'Not specified'}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Interests */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="w-4 h-4" />
                    Interests & Hobbies
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {application.interests?.length ? (
                      application.interests.map((interest, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {interest}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-sm text-muted-foreground">No interests specified</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Motivation */}
            {application.motivation && (
              <Card>
                <CardHeader>
                  <CardTitle>Motivation & Expectations</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm leading-relaxed">{application.motivation}</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="physical" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Physical Measurements */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Ruler className="w-4 h-4" />
                    Physical Measurements
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Height:</span>
                    <span className="text-sm font-semibold">{application.height || 'Not provided'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Measurements:</span>
                    <span className="text-sm font-semibold">{application.measurements || 'Not provided'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Dress Size:</span>
                    <span className="text-sm">{application.dress_size || 'Not provided'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Shoe Size:</span>
                    <span className="text-sm">{application.shoe_size || 'Not provided'}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Physical Features */}
              <Card>
                <CardHeader>
                  <CardTitle>Physical Features</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Hair Color:</span>
                    <span className="text-sm">{application.hair_color || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Eye Color:</span>
                    <span className="text-sm">{application.eye_color || 'Not specified'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Tattoos:</span>
                    <span className="text-sm">{application.tattoos || 'None'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Piercings:</span>
                    <span className="text-sm">{application.piercings || 'None'}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="experience" className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              {/* Modeling Experience */}
              <Card>
                <CardHeader>
                  <CardTitle>Modeling Experience</CardTitle>
                </CardHeader>
                <CardContent>
                  {application.modeling_experience ? (
                    <p className="text-sm leading-relaxed">{application.modeling_experience}</p>
                  ) : (
                    <p className="text-sm text-muted-foreground">No modeling experience provided</p>
                  )}
                </CardContent>
              </Card>

              {/* Escort Experience */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Escort Experience
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {application.escort_experience ? (
                    <p className="text-sm leading-relaxed">{application.escort_experience}</p>
                  ) : (
                    <p className="text-sm text-muted-foreground">No escort experience provided</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="media" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Photos */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Camera className="w-4 h-4" />
                    Photos ({application.photos?.length || 0})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {hasPhotos ? (
                    <div className="grid grid-cols-2 gap-2">
                      {application.photos?.map((photo, index) => (
                        <div key={index} className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                          <img
                            src={photo}
                            alt={`Photo ${index + 1}`}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
                            onError={(e) => {
                              e.currentTarget.src = '/placeholder.svg';
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Camera className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">No photos provided</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Videos */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Video className="w-4 h-4" />
                    Videos ({application.videos?.length || 0})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {hasVideos ? (
                    <div className="space-y-2">
                      {application.videos?.map((video, index) => (
                        <div key={index} className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                          <video
                            src={video}
                            controls
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              e.currentTarget.poster = '/placeholder.svg';
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Video className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">No videos provided</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Media Summary */}
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Media Review Guidelines:</strong>
                <ul className="mt-2 space-y-1 text-sm">
                  <li>• Verify all photos are appropriate and of the applicant</li>
                  <li>• Check for image quality and professional appearance</li>
                  <li>• Ensure videos (if provided) are clear and appropriate</li>
                  <li>• Look for consistency across all media submissions</li>
                </ul>
              </AlertDescription>
            </Alert>
          </TabsContent>

          <TabsContent value="review" className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              {/* Application Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Application Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {new Date().getFullYear() - new Date(application.created_at).getFullYear() || 0}
                      </div>
                      <div className="text-xs text-muted-foreground">Days Since Application</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {application.photos?.length || 0}
                      </div>
                      <div className="text-xs text-muted-foreground">Photos Submitted</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">
                        {application.videos?.length || 0}
                      </div>
                      <div className="text-xs text-muted-foreground">Videos Submitted</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-600">
                        {application.languages?.length || 0}
                      </div>
                      <div className="text-xs text-muted-foreground">Languages</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Application Date:</span>
                      <span className="text-sm">{new Date(application.created_at).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Current Status:</span>
                      <Badge variant={getStatusColor(application.status)}>
                        {application.status.toUpperCase()}
                      </Badge>
                    </div>
                    {application.reviewed_at && (
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Last Reviewed:</span>
                        <span className="text-sm">{new Date(application.reviewed_at).toLocaleDateString()}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Admin Notes */}
              <Card>
                <CardHeader>
                  <CardTitle>Admin Notes & Review</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="admin-notes">Review Notes</Label>
                    <Textarea
                      id="admin-notes"
                      value={adminNotes}
                      onChange={(e) => setAdminNotes(e.target.value)}
                      placeholder="Add your review notes here..."
                      rows={4}
                    />
                  </div>

                  {application.status === 'pending' && (
                  <div className="flex gap-3 pt-4">
                    <Button
                      onClick={() => handleStatusUpdate('approved')}
                      disabled={updating}
                      className="flex-1"
                      variant="default"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      {updating ? 'Updating...' : 'Approve Application'}
                    </Button>
                    <Button
                      onClick={() => handleStatusUpdate('rejected')}
                      disabled={updating}
                      className="flex-1"
                      variant="destructive"
                    >
                      <XCircle className="w-4 h-4 mr-2" />
                      {updating ? 'Updating...' : 'Reject Application'}
                    </Button>
                  </div>
                  )}

                  {application.status !== 'pending' && (
                    <Alert>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        This application has been {application.status}.
                        {application.reviewed_at && ` Reviewed on ${new Date(application.reviewed_at).toLocaleDateString()}.`}
                      </AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};