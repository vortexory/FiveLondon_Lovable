import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { DataTable } from '@/components/DataTable';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ImageUpload } from '@/components/ImageUpload';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Settings as SettingsIcon,
  Plus,
  Edit,
  Trash2,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff,
  Image as ImageIcon
} from 'lucide-react';

interface PreferenceCategory {
  id: string;
  name: string;
  path: string;
  image_url: string;
  image_alt?: string | null;
  order_index: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const PreferenceCategoriesManagement: React.FC = () => {
  const [categories, setCategories] = useState<PreferenceCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<{ [key: string]: boolean }>({});
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<PreferenceCategory | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    path: '',
    image_url: '',
    image_alt: '',
    is_active: true
  });

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('preference_categories')
        .select('*')
        .order('order_index');

      if (error) throw error;
      setCategories(data || []);
    } catch (error: any) {
      console.error('Error fetching preference categories:', error);
      toast.error('Failed to fetch preference categories');
    } finally {
      setLoading(false);
    }
  };

  const saveCategory = async () => {
    console.log('saveCategory called with formData:', formData);
    
    // Check authentication first
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.log('User not authenticated');
      toast.error('You must be logged in to create categories');
      return;
    }
    console.log('User authenticated:', user.id);
    
    if (!formData.name.trim()) {
      console.log('Validation failed: name is empty');
      toast.error('Category name is required');
      return;
    }

    if (!formData.path.trim()) {
      console.log('Validation failed: path is empty');
      toast.error('URL path is required');
      return;
    }

    console.log('Starting save process...');
    setActionLoading(prev => ({ ...prev, save: true }));

    try {
      const categoryData = {
        name: formData.name.trim(),
        path: formData.path.trim(),
        image_url: formData.image_url || '',
        image_alt: formData.image_alt || null,
        is_active: formData.is_active,
        order_index: editingCategory ? editingCategory.order_index : categories.length
      };

      console.log('Category data to save:', categoryData);

      if (editingCategory) {
        console.log('Updating existing category:', editingCategory.id);
        const { error } = await supabase
          .from('preference_categories')
          .update(categoryData)
          .eq('id', editingCategory.id);
        if (error) {
          console.error('Update error:', error);
          throw error;
        }
        toast.success('Category updated successfully');
      } else {
        console.log('Creating new category');
        const { data, error } = await supabase
          .from('preference_categories')
          .insert(categoryData)
          .select();
        
        if (error) {
          console.error('Insert error:', error);
          throw error;
        }
        
        console.log('Category created successfully:', data);
        toast.success('Category created successfully');
      }

      await fetchCategories();
      closeDialog();
    } catch (error: any) {
      console.error('Error saving category:', error);
      if (error.message?.includes('row-level security policy')) {
        toast.error('Permission denied. You need admin privileges to manage categories.');
      } else if (error.message) {
        toast.error(`Failed to save category: ${error.message}`);
      } else {
        toast.error('Failed to save category');
      }
    } finally {
      console.log('Finishing save process');
      setActionLoading(prev => ({ ...prev, save: false }));
    }
  };

  const deleteCategory = async (category: PreferenceCategory) => {
    if (!confirm('Are you sure you want to delete this category?')) return;

    setActionLoading({ [`delete_${category.id}`]: true });

    try {
      const { error } = await supabase
        .from('preference_categories')
        .delete()
        .eq('id', category.id);

      if (error) throw error;
      toast.success('Category deleted successfully');
      await fetchCategories();
    } catch (error: any) {
      console.error('Error deleting category:', error);
      toast.error('Failed to delete category');
    } finally {
      setActionLoading({ [`delete_${category.id}`]: false });
    }
  };

  const toggleActive = async (category: PreferenceCategory) => {
    setActionLoading({ [`toggle_${category.id}`]: true });

    try {
      const { error } = await supabase
        .from('preference_categories')
        .update({ is_active: !category.is_active })
        .eq('id', category.id);

      if (error) throw error;
      toast.success(`Category ${!category.is_active ? 'activated' : 'deactivated'}`);
      await fetchCategories();
    } catch (error: any) {
      console.error('Error toggling category:', error);
      toast.error('Failed to update category');
    } finally {
      setActionLoading({ [`toggle_${category.id}`]: false });
    }
  };

  const reorderCategory = async (category: PreferenceCategory, direction: 'up' | 'down') => {
    const currentIndex = categories.findIndex(c => c.id === category.id);
    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    
    if (targetIndex < 0 || targetIndex >= categories.length) return;

    setActionLoading({ [`reorder_${category.id}`]: true });

    try {
      const targetCategory = categories[targetIndex];
      
      await Promise.all([
        supabase
          .from('preference_categories')
          .update({ order_index: targetCategory.order_index })
          .eq('id', category.id),
        supabase
          .from('preference_categories')
          .update({ order_index: category.order_index })
          .eq('id', targetCategory.id)
      ]);

      toast.success('Category order updated');
      await fetchCategories();
    } catch (error: any) {
      console.error('Error reordering category:', error);
      toast.error('Failed to reorder category');
    } finally {
      setActionLoading({ [`reorder_${category.id}`]: false });
    }
  };

  const openDialog = (category?: PreferenceCategory) => {
    if (category) {
      setEditingCategory(category);
      setFormData({
        name: category.name,
        path: category.path,
        image_url: category.image_url,
        image_alt: category.image_alt || '',
        is_active: category.is_active
      });
    } else {
      setEditingCategory(null);
      setFormData({
        name: '',
        path: '',
        image_url: '',
        image_alt: '',
        is_active: true
      });
    }
    setIsDialogOpen(true);
  };

  const closeDialog = () => {
    setIsDialogOpen(false);
    setEditingCategory(null);
  };

  const generatePath = (name: string) => {
    const path = '/characteristics/' + name.toLowerCase()
      .replace(/[^a-z0-9]/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
    setFormData(prev => ({ ...prev, path }));
  };

  const columns = [
    {
      key: 'order_index',
      header: 'Order',
      render: (category: PreferenceCategory) => (
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm">{category.order_index}</span>
          <div className="flex flex-col gap-1">
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0"
              onClick={() => reorderCategory(category, 'up')}
              disabled={actionLoading[`reorder_${category.id}`] || categories.findIndex(c => c.id === category.id) === 0}
            >
              <ArrowUp className="w-3 h-3" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0"
              onClick={() => reorderCategory(category, 'down')}
              disabled={actionLoading[`reorder_${category.id}`] || categories.findIndex(c => c.id === category.id) === categories.length - 1}
            >
              <ArrowDown className="w-3 h-3" />
            </Button>
          </div>
        </div>
      )
    },
    {
      key: 'image',
      header: 'Image',
      render: (category: PreferenceCategory) => (
        <div className="w-16 h-16 rounded overflow-hidden bg-muted flex items-center justify-center">
          {category.image_url ? (
            <img 
              src={category.image_url} 
              alt={category.image_alt || category.name} 
              className="w-full h-full object-cover" 
            />
          ) : (
            <ImageIcon className="w-6 h-6 text-muted-foreground" />
          )}
        </div>
      )
    },
    {
      key: 'name',
      header: 'Name',
      render: (category: PreferenceCategory) => (
        <div>
          <div className="font-medium">{category.name}</div>
          <div className="text-sm text-muted-foreground">{category.path}</div>
        </div>
      )
    },
    {
      key: 'status',
      header: 'Status',
      render: (category: PreferenceCategory) => (
        <Button
          size="sm"
          variant={category.is_active ? "default" : "secondary"}
          onClick={() => toggleActive(category)}
          disabled={actionLoading[`toggle_${category.id}`]}
          className="flex items-center gap-1"
        >
          {category.is_active ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
          {category.is_active ? 'Active' : 'Inactive'}
        </Button>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (category: PreferenceCategory) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => openDialog(category)}
          >
            <Edit className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => deleteCategory(category)}
            disabled={actionLoading[`delete_${category.id}`]}
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <LoadingSpinner size={32} text="Loading preference categories..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-2">
            <SettingsIcon className="w-5 h-5" />
            <CardTitle>Category Settings</CardTitle>
          </div>
          <Button onClick={() => openDialog()} className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Add Category
          </Button>
        </CardHeader>
        <CardContent>
          <DataTable
            data={categories}
            columns={columns}
            emptyStateIcon={SettingsIcon}
            emptyStateTitle="No preference categories found"
            emptyStateDescription="Click 'Add Category' to create your first preference category."
            emptyStateAction="Add Category"
            onEmptyStateAction={() => openDialog()}
          />
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingCategory ? 'Edit Preference Category' : 'Create Preference Category'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Category Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => {
                  const newName = e.target.value;
                  setFormData(prev => ({ ...prev, name: newName }));
                  if (!editingCategory) {
                    generatePath(newName);
                  }
                }}
                placeholder="Enter category name"
              />
            </div>

            <div>
              <Label>URL Path *</Label>
              <Input
                value={formData.path}
                onChange={(e) => setFormData(prev => ({ ...prev, path: e.target.value }))}
                placeholder="/characteristics/category-path"
              />
              <p className="text-sm text-muted-foreground mt-1">
                The URL path for this category (auto-generated from name)
              </p>
            </div>

            <div>
              <Label>Category Image</Label>
              <ImageUpload
                value={formData.image_url}
                onChange={(url: string) => setFormData(prev => ({ ...prev, image_url: url }))}
                bucket="preference-categories"
              />
            </div>

            <div>
              <Label>Image Alt Text</Label>
              <Input
                value={formData.image_alt}
                onChange={(e) => setFormData(prev => ({ ...prev, image_alt: e.target.value }))}
                placeholder="Alternative text for the image"
              />
              <p className="text-sm text-muted-foreground mt-1">
                Helps with accessibility and SEO
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
              />
              <Label>Active (visible to users)</Label>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={closeDialog}>
              Cancel
            </Button>
            <Button onClick={saveCategory} disabled={actionLoading.save}>
              {actionLoading.save ? 'Saving...' : editingCategory ? 'Update Category' : 'Create Category'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};