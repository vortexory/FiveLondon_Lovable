import React, { useState, useEffect } from 'react';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ImageIcon, Users, Globe, Eye } from 'lucide-react';
import { cn } from '@/lib/utils';

export type ModelVisibilityType = 'public' | 'members_only' | 'mixed';

interface ModelPhoto {
  id: string;
  image_url: string;
  visibility: 'public' | 'members_only';
  order_index: number;
}

interface ModelVisibilitySettingsProps {
  initialVisibilityType?: ModelVisibilityType;
  photos?: ModelPhoto[];
  onVisibilityChange: (visibilityType: ModelVisibilityType, photoVisibilities?: { [photoId: string]: 'public' | 'members_only' }) => void | Promise<void>;
  loading?: boolean;
}

export const ModelVisibilitySettings: React.FC<ModelVisibilitySettingsProps> = ({
  initialVisibilityType = 'public',
  photos = [],
  onVisibilityChange,
  loading = false
}) => {
  // Use local state that doesn't sync back automatically to prevent flickering
  const [selectedType, setSelectedType] = useState<ModelVisibilityType>(initialVisibilityType);
  const [photoVisibilities, setPhotoVisibilities] = useState<{ [photoId: string]: 'public' | 'members_only' }>({});

  // Sync with parent prop when it changes
  useEffect(() => {
    console.log('ModelVisibilitySettings: Syncing with database state:', initialVisibilityType);
    setSelectedType(initialVisibilityType);
  }, [initialVisibilityType]);

  // Initialize photo visibilities from existing photos
  useEffect(() => {
    const initialVisibilities: { [photoId: string]: 'public' | 'members_only' } = {};
    photos.forEach(photo => {
      initialVisibilities[photo.id] = photo.visibility;
    });
    setPhotoVisibilities(initialVisibilities);
  }, [photos]);

  const handleVisibilityTypeChange = async (type: ModelVisibilityType) => {
    console.log('ModelVisibilitySettings: User selected type:', type);
    
    // Update UI state immediately to prevent flickering
    setSelectedType(type);
    
    // Auto-set photo visibilities based on type with specific business logic
    const updatedVisibilities = { ...photoVisibilities };
    
    if (type === 'public') {
      // All photos public
      photos.forEach(photo => {
        updatedVisibilities[photo.id] = 'public';
      });
      setPhotoVisibilities(updatedVisibilities);
      console.log('Setting all photos to public:', updatedVisibilities);
    } else if (type === 'members_only') {
      // All photos members only
      photos.forEach(photo => {
        updatedVisibilities[photo.id] = 'members_only';
      });
      setPhotoVisibilities(updatedVisibilities);
      console.log('Setting all photos to members only:', updatedVisibilities);
    } else if (type === 'mixed') {
      // Mixed: First photo public (based on order_index), rest members only
      const sortedPhotos = [...photos].sort((a, b) => a.order_index - b.order_index);
      sortedPhotos.forEach((photo, index) => {
        updatedVisibilities[photo.id] = index === 0 ? 'public' : 'members_only';
      });
      setPhotoVisibilities(updatedVisibilities);
      console.log('Setting mixed visibility - first photo public, rest members only:', updatedVisibilities);
    }

    // Call backend function
    try {
      const result = onVisibilityChange(type, type === 'mixed' ? updatedVisibilities : undefined);
      if (result instanceof Promise) await result;
    } catch (error) {
      // Revert UI state on error
      console.error('Failed to update visibility, reverting UI state');
      setSelectedType(initialVisibilityType);
    }
  };

  const handlePhotoVisibilityChange = (photoId: string, visibility: 'public' | 'members_only') => {
    const updatedVisibilities = {
      ...photoVisibilities,
      [photoId]: visibility
    };
    setPhotoVisibilities(updatedVisibilities);
    onVisibilityChange(selectedType, updatedVisibilities);
  };

  const visibilityOptions = [
    {
      type: 'public' as ModelVisibilityType,
      title: 'Public Model',
      description: 'All photos visible to everyone',
      icon: Globe,
      color: 'bg-green-50 border-green-200 text-green-800',
      iconColor: 'text-green-600'
    },
    {
      type: 'mixed' as ModelVisibilityType,
      title: 'Mixed Visibility',
      description: 'Some photos public, some for members only',
      icon: Eye,
      color: 'bg-blue-50 border-blue-200 text-blue-800',
      iconColor: 'text-blue-600'
    },
    {
      type: 'members_only' as ModelVisibilityType,
      title: 'Members Only',
      description: 'All photos for members only',
      icon: Users,
      color: 'bg-purple-50 border-purple-200 text-purple-800',
      iconColor: 'text-purple-600'
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <Label className="text-base font-semibold mb-4 block">Model Photo Visibility</Label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {visibilityOptions.map((option) => {
            const Icon = option.icon;
            const isSelected = selectedType === option.type;
            
            return (
              <Card
                key={option.type}
                className={cn(
                  "cursor-pointer transition-all duration-200 hover:shadow-md",
                  isSelected 
                    ? "ring-2 ring-primary border-primary" 
                    : "hover:border-gray-300",
                  loading && "opacity-50 cursor-not-allowed"
                )}
                onClick={() => !loading && handleVisibilityTypeChange(option.type)}
              >
                <CardContent className="p-4 text-center">
                  <div className={cn(
                    "w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3",
                    isSelected ? "bg-primary/10" : "bg-gray-100"
                  )}>
                    <Icon className={cn(
                      "w-6 h-6",
                      isSelected ? "text-primary" : "text-gray-600"
                    )} />
                  </div>
                  <h3 className="font-semibold text-sm mb-1">{option.title}</h3>
                  <p className="text-xs text-gray-600">{option.description}</p>
                  {isSelected && (
                    <Badge variant="default" className="mt-2">
                      Selected
                    </Badge>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Individual Photo Visibility Controls for Mixed Models */}
      {selectedType === 'mixed' && photos.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <ImageIcon className="w-5 h-5" />
              Individual Photo Settings
            </CardTitle>
            <p className="text-sm text-gray-600">
              Set visibility for each photo individually. This is useful for models who don't show their face in public photos.
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {photos.map((photo, index) => (
                <div key={photo.id} className="space-y-3">
                  <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                    <img
                      src={photo.image_url}
                      alt={`Photo ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant={photoVisibilities[photo.id] === 'public' ? 'default' : 'outline'}
                      onClick={() => handlePhotoVisibilityChange(photo.id, 'public')}
                      className="flex-1 text-xs"
                    >
                      <Globe className="w-3 h-3 mr-1" />
                      Public
                    </Button>
                    <Button
                      size="sm"
                      variant={photoVisibilities[photo.id] === 'members_only' ? 'default' : 'outline'}
                      onClick={() => handlePhotoVisibilityChange(photo.id, 'members_only')}
                      className="flex-1 text-xs"
                    >
                      <Users className="w-3 h-3 mr-1" />
                      Members
                    </Button>
                  </div>
                  <Badge 
                    variant={photoVisibilities[photo.id] === 'public' ? 'default' : 'secondary'}
                    className="w-full justify-center text-xs"
                  >
                    {photoVisibilities[photo.id] === 'public' ? 'Public Photo' : 'Members Only'}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary */}
      <div className="bg-gray-50 p-4 rounded-lg">
        <h4 className="font-medium mb-2">Visibility Summary</h4>
        <div className="text-sm text-gray-600">
          {selectedType === 'public' && (
            <p>✅ All photos will be visible to everyone</p>
          )}
          {selectedType === 'members_only' && (
            <p>🔒 All photos will be visible to members only</p>
          )}
          {selectedType === 'mixed' && (
            <div>
              <p>📷 Mixed visibility model:</p>
              <ul className="mt-1 ml-4 space-y-1">
                <li>• Public photos: {Object.values(photoVisibilities).filter(v => v === 'public').length}</li>
                <li>• Members only: {Object.values(photoVisibilities).filter(v => v === 'members_only').length}</li>
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
