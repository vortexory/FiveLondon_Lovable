import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { User } from '@supabase/supabase-js';

// Define Session type based on Supabase auth response
type Session = {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  expires_at?: number;
  token_type: string;
  user: User;
};

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  userRole: string | null;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [userRole, setUserRole] = useState<string | null>(null);

  // Helper function to check if session is expired
  const isSessionExpired = (session: any): boolean => {
    if (!session?.expires_at) return false;
    
    // Convert expires_at to milliseconds if it's in seconds
    const expiryTime = session.expires_at > 9999999999 ? session.expires_at : session.expires_at * 1000;
    const currentTime = Date.now();
    
    // Session is expired if current time is past expiry time
    return currentTime >= expiryTime;
  };

  // Helper function to clear expired session
  const clearExpiredSession = async () => {
    try {
      // Clear local state first
      setUser(null);
      setSession(null);
      setIsAdmin(false);
      setIsSuperAdmin(false);
      setUserRole(null);
      setLoading(false);
      
      // Sign out from Supabase
      await supabase.auth.signOut({ scope: 'local' });
      
      // Clear localStorage manually as backup
      const keysToRemove = [
        'supabase.auth.token',
        'sb-jiegopvbwpyfohhfvmwo-auth-token',
        'sb-auth-token',
        'supabase-auth-token'
      ];
      
      keysToRemove.forEach(key => {
        localStorage.removeItem(key);
        sessionStorage.removeItem(key);
      });
      
      // Clear all supabase related items
      Object.keys(localStorage).forEach(key => {
        if (key.includes('supabase') || key.includes('sb-')) {
          localStorage.removeItem(key);
        }
      });
      
    } catch (error) {
      console.error('Error clearing expired session:', error);
      // Clear storage as fallback
      localStorage.clear();
      sessionStorage.clear();
    }
  };

  useEffect(() => {
    let isMounted = true;
    let sessionCheckInterval: NodeJS.Timeout | null = null;

    // Listen for auth changes first
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!isMounted) return;
      
      if (event === 'SIGNED_OUT' || !session) {
        setSession(null);
        setUser(null);
        setIsAdmin(false);
        setIsSuperAdmin(false);
        setUserRole(null);
        setLoading(false);
      } else if (session?.user && event !== 'TOKEN_REFRESHED') {
        // Skip expiry check for token refresh events
        if (isSessionExpired(session)) {
          await clearExpiredSession();
          return;
        }
        
        setSession(session as Session | null);
        setUser(session.user);
        
        // Check admin status asynchronously
        setTimeout(() => {
          if (isMounted && session.user) {
            checkAdminStatus(session.user.id);
          }
        }, 0);
        
        setLoading(false);
      } else if (session?.user && event === 'TOKEN_REFRESHED') {
        // For token refresh, just update the session without other checks
        setSession(session as Session | null);
        setUser(session.user);
      }
    });

    // Get initial session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!isMounted) return;
      
      if (session?.user) {
        // Check if session is expired
        if (isSessionExpired(session)) {
          await clearExpiredSession();
          return;
        }
        
        setSession(session as Session | null);
        setUser(session.user);
        await checkAdminStatus(session.user.id);
      } else {
        setSession(null);
        setUser(null);
        setIsAdmin(false);
        setIsSuperAdmin(false);
        setUserRole(null);
      }
      setLoading(false);
    });

    // Set up periodic session expiry check (every 10 minutes)
    sessionCheckInterval = setInterval(async () => {
      if (!isMounted) return;
      
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session && isSessionExpired(session)) {
          await clearExpiredSession();
        }
      } catch (error) {
        console.error('Error during periodic session check:', error);
      }
    }, 10 * 60 * 1000); // Check every 10 minutes

    return () => {
      isMounted = false;
      subscription.unsubscribe();
      if (sessionCheckInterval) {
        clearInterval(sessionCheckInterval);
      }
    };
  }, []);

  const checkAdminStatus = async (userId: string) => {
    try {
      // Force fresh data with no cache
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('role, status')
        .eq('id', userId)
        .maybeSingle(); // Use maybeSingle to handle case where no profile exists
      
      if (profileError) {
        console.error('Error checking profile:', profileError);
        setIsAdmin(false);
        setIsSuperAdmin(false);
        setUserRole(null);
        return;
      }
      
      if (!profile) {
        setIsAdmin(false);
        setIsSuperAdmin(false);
        setUserRole(null);
        return;
      }
      
      // Check roles and status
      const role = profile?.role || 'user';
      const isApproved = profile?.status === 'approved';
      const isValidAdmin = (role === 'admin' || role === 'super_admin') && isApproved;
      const isValidSuperAdmin = role === 'super_admin' && isApproved;
      
      setUserRole(role);
      setIsAdmin(isValidAdmin);
      setIsSuperAdmin(isValidSuperAdmin);
      
    } catch (error) {
      console.error('Error checking admin status:', error);
      setIsAdmin(false);
      setIsSuperAdmin(false);
      setUserRole(null);
    }
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { error };
  };

  const signOut = async () => {
    setLoading(true);
    
    try {
      // Clear all auth state immediately
      setUser(null);
      setSession(null);
      setIsAdmin(false);
      setIsSuperAdmin(false);
      setUserRole(null);
      
      // Sign out from Supabase
      await supabase.auth.signOut();
      
      // Clear any localStorage data if needed
      localStorage.removeItem('supabase.auth.token');
      
    } catch (error) {
      console.error('Error during sign out:', error);
    } finally {
      setLoading(false);
    }
  };

  const value = {
    user,
    session,
    loading,
    isAdmin,
    isSuperAdmin,
    userRole,
    signIn,
    signOut,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
