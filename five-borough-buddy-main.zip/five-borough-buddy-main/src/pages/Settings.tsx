import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FAQManagement } from '@/components/FAQManagement';
import { ReviewsManagement } from '@/components/ReviewsManagement';
import { GalleryManagement } from '@/components/GalleryManagement';
import { PreferenceCategoriesManagement } from '@/components/PreferenceCategoriesManagement';
import { SEOSettingsManagement } from '@/components/SEOSettingsManagement';
import { DesignCustomization } from '@/components/cms/DesignCustomization';
import { BannerManagement } from '@/components/cms/BannerManagement';
import { 
  HelpCircle, 
  Image, 
  Star, 
  Settings as SettingsIcon, 
  Search,
  Palette,
  Megaphone
} from 'lucide-react';

export const Settings: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Website Management</h1>
        <p className="text-muted-foreground">
          Manage and configure all aspects of your website content, appearance, and functionality.
        </p>
      </div>

      <Tabs defaultValue="banners" className="w-full">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 h-auto flex-wrap gap-1">
          <TabsTrigger value="banners" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <Megaphone className="w-4 h-4 sm:w-4 sm:h-4" />
            <span className="text-xs sm:text-sm">Banners</span>
          </TabsTrigger>
          <TabsTrigger value="gallery" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <Image className="w-4 h-4 sm:w-4 sm:h-4" />
            <span className="text-xs sm:text-sm">Gallery</span>
          </TabsTrigger>
          <TabsTrigger value="reviews" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <Star className="w-4 h-4 sm:w-4 sm:h-4" />
            <span className="text-xs sm:text-sm">Reviews</span>
          </TabsTrigger>
          <TabsTrigger value="faq" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <HelpCircle className="w-4 h-4 sm:w-4 sm:h-4" />
            <span className="text-xs sm:text-sm">FAQs</span>
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <SettingsIcon className="w-4 h-4 sm:w-4 sm:h-4" />
            <span className="text-xs sm:text-sm">Categories</span>
          </TabsTrigger>
          <TabsTrigger value="seo" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <Search className="w-4 h-4 sm:w-4 sm:h-4" />
            <span className="text-xs sm:text-sm">SEO</span>
          </TabsTrigger>
          <TabsTrigger value="design" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <Palette className="w-4 h-4 sm:w-4 sm:h-4" />
            <span className="text-xs sm:text-sm">Design</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="banners" className="mt-6">
          <BannerManagement />
        </TabsContent>
        
        <TabsContent value="gallery" className="mt-6">
          <GalleryManagement />
        </TabsContent>
        
        <TabsContent value="reviews" className="mt-6">
          <ReviewsManagement />
        </TabsContent>
        
        <TabsContent value="faq" className="mt-6">
          <FAQManagement />
        </TabsContent>
        
        <TabsContent value="categories" className="mt-6">
          <PreferenceCategoriesManagement />
        </TabsContent>
        
        <TabsContent value="seo" className="mt-6">
          <SEOSettingsManagement />
        </TabsContent>
        
        <TabsContent value="design" className="mt-6">
          <DesignCustomization />
        </TabsContent>
      </Tabs>
    </div>
  );
};