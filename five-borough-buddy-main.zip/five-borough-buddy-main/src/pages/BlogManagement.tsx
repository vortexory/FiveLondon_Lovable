import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Plus, Trash2, RefreshCw, Edit, ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { DataTable } from '@/components/DataTable';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { FilterBar } from '@/components/FilterBar';
import { BlogEditor } from '@/components/BlogEditor';

interface BlogPost {
  id: string;
  title: string;
  content?: string | null;
  excerpt?: string | null;
  author?: string | null;
  category?: string | null;
  image?: string | null;
  is_published: boolean | null;
  created_at: string;
  updated_at: string;
  published_at?: string | null;
  slug: string;
}

export const BlogManagement: React.FC = () => {
  const { toast } = useToast();
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [showAdvancedEditor, setShowAdvancedEditor] = useState(false);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);

  // Filter states
  const [filters, setFilters] = useState({
    search: '',
    status: '',
    category: '',
    author: '',
    dateFrom: '',
    dateTo: ''
  });

  const fetchPosts = async () => {
    try {
      setError(null);
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error: any) {
      console.error('Error fetching blog posts:', error);
      setError(error.message || 'Failed to fetch blog posts');
      toast({
        description: 'Failed to fetch blog posts',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  // Filter logic
  const filteredPosts = useMemo(() => {
    return posts.filter(post => {
      const matchesSearch = !filters.search || 
        post.title.toLowerCase().includes(filters.search.toLowerCase()) ||
        post.content?.toLowerCase().includes(filters.search.toLowerCase()) ||
        post.excerpt?.toLowerCase().includes(filters.search.toLowerCase());
      
      const matchesStatus = !filters.status || 
        (filters.status === 'published' && post.is_published) ||
        (filters.status === 'draft' && !post.is_published);
      
      const matchesCategory = !filters.category || 
        post.category?.toLowerCase() === filters.category.toLowerCase();
      
      const matchesAuthor = !filters.author || 
        post.author?.toLowerCase().includes(filters.author.toLowerCase());
      
      const postDate = new Date(post.created_at);
      const matchesDateFrom = !filters.dateFrom || 
        postDate >= new Date(filters.dateFrom);
      const matchesDateTo = !filters.dateTo || 
        postDate <= new Date(filters.dateTo + 'T23:59:59');
      
      return matchesSearch && matchesStatus && matchesCategory && matchesAuthor && matchesDateFrom && matchesDateTo;
    });
  }, [posts, filters]);

  // Get unique values for filter options
  const uniqueCategories = useMemo(() => {
    const categories = posts.map(post => post.category).filter(Boolean);
    return [...new Set(categories)].map(cat => ({ value: cat!, label: cat! }));
  }, [posts]);

  const uniqueAuthors = useMemo(() => {
    const authors = posts.map(post => post.author).filter(Boolean);
    return [...new Set(authors)].map(author => ({ value: author!, label: author! }));
  }, [posts]);

  const filterOptions = [
    {
      key: 'search',
      label: 'Search',
      type: 'search' as const,
      placeholder: 'Search by title, content, or excerpt...'
    },
    {
      key: 'status',
      label: 'Status',
      type: 'select' as const,
      options: [
        { value: 'published', label: 'Published' },
        { value: 'draft', label: 'Draft' }
      ]
    },
    {
      key: 'category',
      label: 'Category',
      type: 'select' as const,
      options: uniqueCategories
    },
    {
      key: 'author',
      label: 'Author',
      type: 'select' as const,
      options: uniqueAuthors
    },
    {
      key: 'dateFrom',
      label: 'From Date',
      type: 'date' as const
    },
    {
      key: 'dateTo',
      label: 'To Date',
      type: 'date' as const
    }
  ];

  const activeFiltersCount = Object.values(filters).filter(value => value !== '').length;

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      status: '',
      category: '',
      author: '',
      dateFrom: '',
      dateTo: ''
    });
  };

  const openBlogEditor = (post?: BlogPost) => {
    setEditingPost(post || null);
    setShowAdvancedEditor(true);
  };

  const deletePost = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this blog post? This action cannot be undone.')) {
      return;
    }

    try {
      setActionLoading(postId);
      
      // Optimistically update UI for immediate feedback
      setPosts(prev => prev.filter(post => post.id !== postId));
      
      const { error } = await supabase
        .from('blog_posts')
        .delete()
        .eq('id', postId);

      if (error) {
        console.error('Supabase delete error:', error);
        throw new Error(`Delete failed: ${error.message}`);
      }

      toast({
        description: 'Blog post deleted successfully'
      });
      
      // Refresh data to ensure consistency
      await fetchPosts();
    } catch (error: any) {
      console.error('Error deleting blog post:', error);
      
      // Log detailed error information
      console.error('Delete error details:', {
        postId,
        errorMessage: error.message,
        errorCode: error.code,
        errorDetails: error.details
      });
      
      toast({
        description: `Failed to delete blog post: ${error.message}`,
        variant: 'destructive'
      });
      
      // On error, refresh data to restore original state
      await fetchPosts();
    } finally {
      setActionLoading(null);
    }
  };

  const togglePublish = async (postId: string, currentStatus: boolean) => {
    try {
      setActionLoading(postId);
      const { error } = await supabase
        .from('blog_posts')
        .update({ 
          is_published: !currentStatus,
          published_at: !currentStatus ? new Date().toISOString() : null
        })
        .eq('id', postId);

      if (error) throw error;

      toast({
        description: `Blog post ${!currentStatus ? 'published' : 'unpublished'} successfully`
      });
      fetchPosts();
    } catch (error: any) {
      console.error('Error updating blog post:', error);
      toast({
        description: 'Failed to update blog post',
        variant: 'destructive'
      });
    } finally {
      setActionLoading(null);
    }
  };


  const columns = [
    {
      key: 'image',
      header: 'Image',
      render: (post: BlogPost) => {
        // Get the image URL from various possible fields
        const imageUrl = (post as any).image_url_local || post.image || (post as any).image_local;
        const hasValidImage = imageUrl && (
          imageUrl.startsWith('http://') || 
          imageUrl.startsWith('https://') || 
          imageUrl.startsWith('data:')
        );

        return (
          <div className="w-16 h-16 rounded-lg overflow-hidden bg-muted flex items-center justify-center">
            {hasValidImage ? (
              <img 
                src={imageUrl} 
                alt={post.title || 'Blog post image'}
                className="w-full h-full object-cover"
                onError={(e) => {
                  // Fallback to placeholder on error
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const placeholder = target.parentElement?.querySelector('.image-placeholder');
                  if (placeholder) {
                    (placeholder as HTMLElement).style.display = 'flex';
                  }
                }}
              />
            ) : null}
            <div 
              className={`w-full h-full flex items-center justify-center text-muted-foreground image-placeholder ${hasValidImage ? 'hidden' : ''}`}
            >
              <ImageIcon className="w-6 h-6" />
            </div>
          </div>
        );
      }
    },
    {
      key: 'title',
      header: 'Title',
      render: (post: BlogPost) => (
        <div className="max-w-xs">
          <div className="font-medium truncate">{post.title}</div>
          {post.excerpt && (
            <div className="text-sm text-muted-foreground truncate">
              {post.excerpt}
            </div>
          )}
        </div>
      )
    },
    {
      key: 'author',
      header: 'Author',
      render: (post: BlogPost) => post.author || 'Unknown'
    },
    {
      key: 'category',
      header: 'Category',
      render: (post: BlogPost) => (
        <Badge variant="outline">
          {post.category || 'Uncategorized'}
        </Badge>
      )
    },
    {
      key: 'status',
      header: 'Status',
      render: (post: BlogPost) => (
        <Badge variant={post.is_published ? 'default' : 'secondary'}>
          {post.is_published ? 'Published' : 'Draft'}
        </Badge>
      )
    },
    {
      key: 'created_at',
      header: 'Created',
      render: (post: BlogPost) => (
        <div className="text-sm">
          <div>{new Date(post.created_at).toLocaleDateString()}</div>
          <div className="text-muted-foreground">
            {new Date(post.created_at).toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </div>
        </div>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (post: BlogPost) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => openBlogEditor(post)}
            disabled={!!actionLoading}
            title="Edit Blog Post"
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => togglePublish(post.id, !!post.is_published)}
            disabled={actionLoading === post.id}
          >
            {post.is_published ? 'Unpublish' : 'Publish'}
          </Button>
          <Button
            size="sm"
            variant="destructive"
            onClick={() => deletePost(post.id)}
            disabled={actionLoading === post.id}
          >
            {actionLoading === post.id ? (
              <LoadingSpinner size={16} text="" />
            ) : (
              <Trash2 className="w-4 h-4" />
            )}
          </Button>
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Blog Management</h1>
          <p className="text-muted-foreground">
            Manage blog posts, categories, and content
          </p>
        </div>
        <LoadingSpinner size={32} text="Loading blog posts..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Blog Management</h1>
          <p className="text-muted-foreground">
            Manage blog posts, categories, and content
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            onClick={fetchPosts}
            disabled={loading}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button
            onClick={() => openBlogEditor()}
          >
            <Plus className="w-4 h-4 mr-2" />
            New Blog Post
          </Button>

          {/* Advanced Blog Editor */}
          <BlogEditor
            isOpen={showAdvancedEditor}
            onClose={() => setShowAdvancedEditor(false)}
            post={editingPost}
            onSave={() => {
              fetchPosts();
              setShowAdvancedEditor(false);
              setEditingPost(null);
            }}
          />
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <FilterBar
        filters={filters}
        onFilterChange={handleFilterChange}
        onClearFilters={clearFilters}
        filterOptions={filterOptions}
        activeFiltersCount={activeFiltersCount}
      />

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Blog Posts ({filteredPosts.length})
            {activeFiltersCount > 0 && (
              <Badge variant="outline" className="ml-2">
                Filtered from {posts.length}
              </Badge>
            )}
          </CardTitle>
          <CardDescription>
            Create, edit, and manage your blog content
          </CardDescription>
        </CardHeader>
        <CardContent>
          <DataTable
            data={filteredPosts}
            columns={columns}
            emptyStateIcon={FileText}
            emptyStateTitle={filteredPosts.length === 0 && posts.length > 0 ? "No posts match filters" : "No blog posts yet"}
            emptyStateDescription={filteredPosts.length === 0 && posts.length > 0 ? "Try adjusting your search criteria or clear filters" : "Get started by creating your first blog post to engage with your audience"}
            emptyStateAction="Create Blog Post"
            onEmptyStateAction={() => openBlogEditor()}
          />
        </CardContent>
      </Card>
    </div>
  );
};
