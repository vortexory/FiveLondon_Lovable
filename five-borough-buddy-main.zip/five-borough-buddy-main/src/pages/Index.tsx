import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Users, FileText, Settings } from 'lucide-react';

export const Index: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <Shield className="h-8 w-8 text-gray-900" />
                <span className="ml-2 text-xl font-bold text-gray-900">Five London</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Link to="/login">
                <Button variant="outline">Admin Login</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 sm:text-6xl">
            Five London
          </h1>
          <p className="mt-6 text-lg leading-8 text-gray-600 max-w-2xl mx-auto">
            Premium administration panel for managing content, users, and business operations.
          </p>
          
          <div className="mt-10 flex items-center justify-center gap-x-6">
            <Link to="/login">
              <Button size="lg" className="bg-gray-900 hover:bg-gray-800">
                <Shield className="w-4 h-4 mr-2" />
                Access Admin Panel
              </Button>
            </Link>
          </div>
        </div>

        {/* Features Grid */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="text-center">
            <CardHeader>
              <Users className="h-12 w-12 text-gray-600 mx-auto mb-4" />
              <CardTitle>User Management</CardTitle>
              <CardDescription>
                Manage user accounts, permissions, and access levels
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <FileText className="h-12 w-12 text-gray-600 mx-auto mb-4" />
              <CardTitle>Content Management</CardTitle>
              <CardDescription>
                Create and manage blog posts, models, and website content
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Settings className="h-12 w-12 text-gray-600 mx-auto mb-4" />
              <CardTitle>System Settings</CardTitle>
              <CardDescription>
                Configure system settings, SEO, and administrative preferences
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Status Section */}
        <div className="mt-16">
          <Card>
            <CardHeader>
              <CardTitle className="text-center">System Status</CardTitle>
              <CardDescription className="text-center">
                Current operational status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center space-x-4">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Database: Online</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">API: Operational</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Security: Active</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-sm text-gray-500">
            <p>&copy; 2025 Five London. All rights reserved.</p>
            <p className="mt-2">Secure administrative access for authorized personnel only.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};