import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, UserCheck, Eye, Trash2, CheckCircle, RefreshCw, Plus, Edit, Globe, ChevronDown, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { DataTable } from '@/components/DataTable';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { FilterBar } from '@/components/FilterBar';
import { ModelForm } from '@/components/ModelForm';
import { ModelGalleryManager } from '@/components/ModelGalleryManager';
import { ModelVisibilitySettings } from '@/components/ModelVisibilitySettings';

interface Model {
  id: string;
  name: string;
  location?: string | null;
  age?: number | null;
  availability?: string | null;
  created_at: string;
  members_only: boolean | null;
  visibility_type?: string | null;
  all_photos_public?: boolean | null;
  face_visible?: boolean | null;
  description?: string | null;
  height?: string | null;
  measurements?: string | null;
  hair?: string | null;
  eyes?: string | null;
  nationality?: string | null;
  education?: string | null;
  price?: string | null;
  services?: string[] | null;
  characteristics?: string[] | null;
  interests?: string[] | null;
}

interface ModelApplication {
  id: string;
  full_name: string;
  email: string;
  age?: number | null;
  status: string;
  created_at: string;
  nationality?: string | null;
  languages?: string[] | null;
}

export const ModelManagement: React.FC = () => {
  const { toast } = useToast();
  const [models, setModels] = useState<Model[]>([]);
  const [applications, setApplications] = useState<ModelApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [isModelFormOpen, setIsModelFormOpen] = useState(false);
  const [editingModel, setEditingModel] = useState<Model | null>(null);
  const [galleryModel, setGalleryModel] = useState<Model | null>(null);
  const [visibilityModel, setVisibilityModel] = useState<Model | null>(null);

  // Filter states
  const [filters, setFilters] = useState({
    search: '',
    status: '',
    modelType: '',
    dateFrom: '',
    dateTo: ''
  });

  const fetchModels = async () => {
    try {
      setError(null);
      console.log('Fetching models...');
      
      const { data, error } = await supabase
        .from('models')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching models:', error);
        throw error;
      }
      
      console.log('Models fetched successfully:', data?.length || 0, 'records');
      setModels(data || []);
    } catch (error: any) {
      console.error('Error fetching models:', error);
      setError(error.message || 'Failed to fetch models');
      toast({
        description: 'Failed to fetch models',
        variant: 'destructive'
      });
      setModels([]); // Clear models on error to avoid stale data
    }
  };

  const fetchApplications = async () => {
    try {
      const { data, error } = await supabase
        .from('model_applications')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setApplications(data || []);
    } catch (error: any) {
      console.error('Error fetching applications:', error);
      toast({
        description: 'Failed to fetch applications',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    Promise.all([fetchModels(), fetchApplications()]);
  }, []);

  // Filter logic
  const filteredModels = useMemo(() => {
    return models.filter(model => {
      const matchesSearch = !filters.search || 
        model.name.toLowerCase().includes(filters.search.toLowerCase()) ||
        model.location?.toLowerCase().includes(filters.search.toLowerCase());
      
      const matchesType = !filters.modelType || 
        (filters.modelType === 'members' && model.members_only) ||
        (filters.modelType === 'public' && !model.members_only);
      
      const modelDate = new Date(model.created_at);
      const matchesDateFrom = !filters.dateFrom || 
        modelDate >= new Date(filters.dateFrom);
      const matchesDateTo = !filters.dateTo || 
        modelDate <= new Date(filters.dateTo + 'T23:59:59');
      
      return matchesSearch && matchesType && matchesDateFrom && matchesDateTo;
    });
  }, [models, filters]);

  const filteredApplications = useMemo(() => {
    return applications.filter(app => {
      const matchesSearch = !filters.search || 
        app.full_name.toLowerCase().includes(filters.search.toLowerCase()) ||
        app.email.toLowerCase().includes(filters.search.toLowerCase());
      
      const matchesStatus = !filters.status || app.status === filters.status;
      
      const appDate = new Date(app.created_at);
      const matchesDateFrom = !filters.dateFrom || 
        appDate >= new Date(filters.dateFrom);
      const matchesDateTo = !filters.dateTo || 
        appDate <= new Date(filters.dateTo + 'T23:59:59');
      
      return matchesSearch && matchesStatus && matchesDateFrom && matchesDateTo;
    });
  }, [applications, filters]);

  const filterOptions = [
    {
      key: 'search',
      label: 'Search',
      type: 'search' as const,
      placeholder: 'Search by name, email, or location...'
    },
    {
      key: 'status',
      label: 'Application Status',
      type: 'select' as const,
      options: [
        { value: 'pending', label: 'Pending' },
        { value: 'approved', label: 'Approved' },
        { value: 'rejected', label: 'Rejected' }
      ]
    },
    {
      key: 'modelType',
      label: 'Model Type',
      type: 'select' as const,
      options: [
        { value: 'public', label: 'Public' },
        { value: 'members', label: 'Members Only' }
      ]
    },
    {
      key: 'dateFrom',
      label: 'From Date',
      type: 'date' as const
    },
    {
      key: 'dateTo',
      label: 'To Date',
      type: 'date' as const
    }
  ];

  const activeFiltersCount = Object.values(filters).filter(value => value !== '').length;

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      status: '',
      modelType: '',
      dateFrom: '',
      dateTo: ''
    });
  };

  const updateApplicationStatus = async (appId: string, newStatus: string) => {
    try {
      setActionLoading(appId);
      const { error } = await supabase
        .from('model_applications')
        .update({ 
          status: newStatus,
          reviewed_at: new Date().toISOString()
        })
        .eq('id', appId);

      if (error) throw error;
      
      toast({
        description: `Application ${newStatus} successfully`
      });
      fetchApplications();
    } catch (error: any) {
      console.error('Error updating application:', error);
      toast({
        description: 'Failed to update application',
        variant: 'destructive'
      });
    } finally {
      setActionLoading(null);
    }
  };

  const handleMixedVisibilityClick = async (model: Model) => {
    try {
      // First set the model to mixed visibility
      await updateVisibilityStatus(model.id, 'mixed');
      // Then open the gallery manager
      setGalleryModel({ ...model, visibility_type: 'mixed' });
    } catch (error) {
      console.error('Error setting mixed visibility:', error);
    }
  };

  const updateVisibilityStatus = async (modelId: string, visibilityType: 'public' | 'mixed' | 'members_only') => {
    try {
      setActionLoading(modelId);
      console.log('Updating visibility status for model:', modelId, 'to:', visibilityType);
      
      // If setting to public or members_only, update all photos to match
      if (visibilityType !== 'mixed') {
        const photoVisibility = visibilityType === 'public' ? 'public' : 'members_only';
        
        // Update all photos for this model
        const { error: photosError } = await supabase
          .from('model_gallery')
          .update({ visibility: photoVisibility })
          .eq('model_id', modelId);

        if (photosError) {
          console.error('Error updating photo visibility:', photosError);
          throw photosError;
        }
      }

      // Update the model
      const { error: modelError } = await supabase
        .from('models')
        .update({
          visibility_type: visibilityType,
          members_only: visibilityType === 'members_only',
          all_photos_public: visibilityType === 'public',
          face_visible: visibilityType !== 'mixed'
        })
        .eq('id', modelId);

      if (modelError) {
        console.error('Error updating model:', modelError);
        throw modelError;
      }

      // After updating, check actual photo visibility and adjust model status accordingly
      const actualStatus = await updateModelStatusFromAllPhotos(modelId);
      
      // Refresh models to show updated status
      await fetchModels();
      
      // Show the final status that was determined by checking all photos
      const finalStatusLabels = {
        'public': 'Public',
        'mixed': 'Mixed Visibility',
        'members_only': 'Members Only'
      };

      if (actualStatus && actualStatus !== visibilityType) {
        toast({
          description: `Photos updated, model automatically set to ${finalStatusLabels[actualStatus]} based on actual photo visibility`
        });
      } else {
        toast({
          description: `Model visibility updated to ${finalStatusLabels[visibilityType]}`
        });
      }
      
    } catch (error: any) {
      console.error('Error updating visibility status:', error);
      toast({
        description: error.message || 'Failed to update model status',
        variant: 'destructive'
      });
    } finally {
      setActionLoading(null);
    }
  };

  const updateModelStatusFromAllPhotos = async (modelId: string) => {
    try {
      // Fetch all photos for this model
      const { data: allPhotos } = await supabase
        .from('model_gallery')
        .select('visibility')
        .eq('model_id', modelId);

      console.log(`Checking ${allPhotos?.length || 0} photos for model ${modelId}`);

      if (!allPhotos || allPhotos.length === 0) {
        // No photos, set to public
        await supabase
          .from('models')
          .update({
            visibility_type: 'public',
            members_only: false,
            all_photos_public: true,
            face_visible: true
          })
          .eq('id', modelId);
        console.log('Model updated to public (no photos)');
        return 'public';
      }

      // Determine visibility type based on all photos
      const publicCount = allPhotos.filter(photo => photo.visibility === 'public').length;
      const membersOnlyCount = allPhotos.filter(photo => photo.visibility === 'members_only').length;
      
      let finalVisibilityType: 'public' | 'mixed' | 'members_only';
      if (publicCount === allPhotos.length) {
        finalVisibilityType = 'public';
      } else if (membersOnlyCount === allPhotos.length) {
        finalVisibilityType = 'members_only';
      } else {
        finalVisibilityType = 'mixed';
      }

      // Update model with determined visibility type
      await supabase
        .from('models')
        .update({
          visibility_type: finalVisibilityType,
          members_only: finalVisibilityType === 'members_only',
          all_photos_public: finalVisibilityType === 'public',
          face_visible: finalVisibilityType !== 'mixed'
        })
        .eq('id', modelId);

      console.log(`Model ${modelId} status updated to: ${finalVisibilityType} based on ${allPhotos.length} photos (${publicCount} public, ${membersOnlyCount} members only)`);
      
      return finalVisibilityType;
    } catch (error) {
      console.error('Error updating model status from photos:', error);
      return null;
    }
  };

  const getVisibilityIcon = (visibilityType: string) => {
    switch (visibilityType) {
      case 'public': return Globe;
      case 'mixed': return Eye;
      case 'members_only': return Users;
      default: return Globe;
    }
  };

  const getVisibilityColor = (visibilityType: string) => {
    switch (visibilityType) {
      case 'public': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'mixed': return 'text-gray-600 bg-gray-50 border-gray-200';
      case 'members_only': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const deleteModel = async (modelId: string) => {
    if (!confirm('Are you sure you want to delete this model? This action cannot be undone.')) {
      return;
    }

    try {
      setActionLoading(modelId);
      
      console.log('Starting model deletion process for:', modelId);
      
      // Delete related records with proper error handling
      try {
        const { error } = await supabase.from('model_gallery').delete().eq('model_id', modelId);
        if (error) console.warn('Gallery deletion warning:', error);
      } catch (e) {
        console.warn('Gallery deletion failed (non-blocking):', e);
      }

      try {
        const { error } = await supabase.from('model_reviews').delete().eq('model_id', modelId);
        if (error) console.warn('Reviews deletion warning:', error);
      } catch (e) {
        console.warn('Reviews deletion failed (non-blocking):', e);
      }

      try {
        const { error } = await supabase.from('homepage_carousel').delete().eq('model_id', modelId);
        if (error) console.warn('Carousel deletion warning:', error);
      } catch (e) {
        console.warn('Carousel deletion failed (non-blocking):', e);
      }

      try {
        const { error } = await supabase.from('public_gallery').delete().eq('model_id', modelId);
        if (error) console.warn('Public gallery deletion warning:', error);
      } catch (e) {
        console.warn('Public gallery deletion failed (non-blocking):', e);
      }
      
      // Now delete the main model record
      console.log('Deleting main model record...');
      const { error } = await supabase
        .from('models')
        .delete()
        .eq('id', modelId);

      if (error) {
        console.error('Model deletion failed:', error);
        throw new Error(`Failed to delete model: ${error.message}`);
      }
      
      console.log('Model deleted successfully from database');
      
      // Remove from local state only after successful deletion
      setModels(prev => prev.filter(model => model.id !== modelId));
      
      toast({
        description: 'Model deleted successfully'
      });
      
    } catch (error: any) {
      console.error('Error deleting model:', error);
      
      toast({
        description: `Failed to delete model: ${error.message}`,
        variant: 'destructive'
      });
      
      // Refresh data to restore original state on error
      await fetchModels();
    } finally {
      setActionLoading(null);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'default';
      case 'pending': return 'secondary';
      case 'rejected': return 'destructive';
      default: return 'outline';
    }
  };

  const modelColumns = [
    {
      key: 'name',
      header: 'Name',
      render: (model: Model) => (
        <span className="font-medium">{model.name}</span>
      )
    },
    {
      key: 'location',
      header: 'Location',
      render: (model: Model) => model.location || 'N/A'
    },
    {
      key: 'age',
      header: 'Age',
      render: (model: Model) => model.age || 'N/A'
    },
    {
      key: 'availability',
      header: 'Availability',
      render: (model: Model) => model.availability || 'N/A'
    },
    {
      key: 'type',
      header: 'Visibility',
      render: (model: Model) => {
        const visibilityType = model.visibility_type || (model.members_only ? 'members_only' : 'public');
        const Icon = getVisibilityIcon(visibilityType);
        const statusLabels = {
          'public': 'Public',
          'mixed': 'Mixed',
          'members_only': 'Members Only'
        };
        
        return (
          <Badge variant="outline" className={getVisibilityColor(visibilityType)}>
            <Icon className="w-3 h-3 mr-1" />
            {statusLabels[visibilityType as keyof typeof statusLabels]}
          </Badge>
        );
      }
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (model: Model) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setGalleryModel(model)}
            disabled={actionLoading === model.id}
            title="Add Photos"
          >
            <Camera className="w-4 h-4" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                size="sm"
                variant="outline"
                disabled={actionLoading === model.id}
                className="min-w-0"
              >
                {React.createElement(getVisibilityIcon(model.visibility_type || (model.members_only ? 'members_only' : 'public')), { 
                  className: "w-4 h-4 mr-1" 
                })}
                <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem 
                onClick={() => updateVisibilityStatus(model.id, 'public')}
                className="text-blue-600"
              >
                <Globe className="w-4 h-4 mr-2" />
                Public
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => handleMixedVisibilityClick(model)}
                className="text-gray-600"
              >
                <Eye className="w-4 h-4 mr-2" />
                Mixed
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => updateVisibilityStatus(model.id, 'members_only')}
                className="text-red-600"
              >
                <Users className="w-4 h-4 mr-2" />
                Members Only
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button
            size="sm"
            variant="outline"
            onClick={() => handleEditModel(model)}
            disabled={actionLoading === model.id}
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="destructive"
            onClick={() => deleteModel(model.id)}
            disabled={actionLoading === model.id}
          >
            {actionLoading === model.id ? (
              <LoadingSpinner size={16} text="" />
            ) : (
              <Trash2 className="w-4 h-4" />
            )}
          </Button>
        </div>
      )
    }
  ];

  const applicationColumns = [
    {
      key: 'full_name',
      header: 'Name',
      render: (app: ModelApplication) => (
        <span className="font-medium">{app.full_name}</span>
      )
    },
    {
      key: 'email',
      header: 'Email',
      render: (app: ModelApplication) => app.email
    },
    {
      key: 'age',
      header: 'Age',
      render: (app: ModelApplication) => app.age || 'N/A'
    },
    {
      key: 'status',
      header: 'Status',
      render: (app: ModelApplication) => (
        <Badge variant={getStatusColor(app.status)}>
          {app.status}
        </Badge>
      )
    },
    {
      key: 'created_at',
      header: 'Submitted',
      render: (app: ModelApplication) => (
        new Date(app.created_at).toLocaleDateString()
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (app: ModelApplication) => (
        <div className="flex items-center gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button
                size="sm"
                variant="outline"
              >
                <Eye className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Application Details</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <strong>Name:</strong> {app.full_name}
                </div>
                <div>
                  <strong>Email:</strong> {app.email}
                </div>
                <div>
                  <strong>Age:</strong> {app.age || 'Not specified'}
                </div>
                <div>
                  <strong>Nationality:</strong> {app.nationality || 'Not specified'}
                </div>
                <div>
                  <strong>Languages:</strong> {app.languages?.join(', ') || 'Not specified'}
                </div>
                <div className="flex items-center gap-2">
                  <strong>Status:</strong> 
                  <Badge variant={getStatusColor(app.status)}>
                    {app.status}
                  </Badge>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          {app.status === 'pending' && (
            <div className="flex items-center gap-1">
              <Button
                size="sm"
                variant="default"
                onClick={() => updateApplicationStatus(app.id, 'approved')}
                disabled={actionLoading === app.id}
              >
                <CheckCircle className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={() => updateApplicationStatus(app.id, 'rejected')}
                disabled={actionLoading === app.id}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
              {actionLoading === app.id && (
                <LoadingSpinner size={16} text="" />
              )}
            </div>
          )}
        </div>
      )
    }
  ];

  const refreshData = async () => {
    setLoading(true);
    await Promise.all([fetchModels(), fetchApplications()]);
  };

  const handleGalleryVisibilityChange = async () => {
    // Just refresh data without updating galleryModel state
    // This allows the gallery to close properly after changes are applied
    await refreshData();
  };

  const handleCreateModel = () => {
    setEditingModel(null);
    setIsModelFormOpen(true);
  };

  const handleEditModel = (model: Model) => {
    setEditingModel(model);
    setIsModelFormOpen(true);
  };

  const handleModelFormClose = () => {
    setIsModelFormOpen(false);
    setEditingModel(null);
  };

  const handleModelSave = () => {
    refreshData();
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Model Management</h1>
          <p className="text-muted-foreground">
            Manage models, applications, and profiles
          </p>
        </div>
        <LoadingSpinner size={32} text="Loading model data..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Model Management</h1>
          <p className="text-muted-foreground">
            Manage models, applications, and profiles
          </p>
        </div>
        <Button 
          variant="outline" 
          onClick={refreshData}
          disabled={loading}
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <FilterBar
        filters={filters}
        onFilterChange={handleFilterChange}
        onClearFilters={clearFilters}
        filterOptions={filterOptions}
        activeFiltersCount={activeFiltersCount}
      />

      <div className="grid grid-cols-1 gap-6">
        {/* Active Models */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Active Models ({filteredModels.length})
                  {activeFiltersCount > 0 && (
                    <Badge variant="outline" className="ml-2">
                      Filtered from {models.length}
                    </Badge>
                  )}
                </CardTitle>
                <CardDescription>
                  Manage existing model profiles
                </CardDescription>
              </div>
              <Button onClick={handleCreateModel}>
                <Plus className="w-4 h-4 mr-2" />
                Add Model
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <DataTable
              data={filteredModels}
              columns={modelColumns}
              emptyStateIcon={Users}
              emptyStateTitle={filteredModels.length === 0 && models.length > 0 ? "No models match filters" : "No models yet"}
              emptyStateDescription={filteredModels.length === 0 && models.length > 0 ? "Try adjusting your search criteria" : "Model profiles will appear here when they are added to the platform"}
            />
          </CardContent>
        </Card>

        {/* Applications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserCheck className="h-5 w-5" />
              Model Applications ({filteredApplications.length})
              {activeFiltersCount > 0 && (
                <Badge variant="outline" className="ml-2">
                  Filtered from {applications.length}
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              Review model application submissions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DataTable
              data={filteredApplications}
              columns={applicationColumns}
              emptyStateIcon={UserCheck}
              emptyStateTitle={filteredApplications.length === 0 && applications.length > 0 ? "No applications match filters" : "No applications"}
              emptyStateDescription={filteredApplications.length === 0 && applications.length > 0 ? "Try adjusting your search criteria" : "Model applications will appear here when submitted through the application form"}
            />
          </CardContent>
        </Card>
      </div>

      <ModelForm
        isOpen={isModelFormOpen}
        onClose={handleModelFormClose}
        model={editingModel}
        onSave={handleModelSave}
      />

      {galleryModel && (
        <ModelGalleryManager
          modelId={galleryModel.id}
          modelName={galleryModel.name}
          initialVisibilityType={
            galleryModel.visibility_type === 'public' ? 'public' :
            galleryModel.visibility_type === 'members_only' ? 'members_only' :
            galleryModel.visibility_type === 'mixed' ? 'mixed' :
            galleryModel.members_only ? 'members_only' : 'public'
          }
          onClose={() => setGalleryModel(null)}
          onVisibilityChange={handleGalleryVisibilityChange}
          mixedModeOnly={true}
        />
      )}

      {/* Model Visibility Settings Dialog */}
      {visibilityModel && (
        <Dialog open={!!visibilityModel} onOpenChange={() => setVisibilityModel(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Mixed Visibility Settings - {visibilityModel.name}</DialogTitle>
            </DialogHeader>
            <ModelVisibilitySettings
              initialVisibilityType="mixed"
              photos={[]} // TODO: Load gallery photos when implementing photo visibility
              onVisibilityChange={(visibilityType, photoVisibilities) => {
                console.log('Visibility changed:', visibilityType, photoVisibilities);
                // TODO: Update individual photo visibilities in the database
                setVisibilityModel(null);
              }}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};
