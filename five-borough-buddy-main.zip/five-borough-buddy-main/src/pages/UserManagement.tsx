import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { UserCheck, Users, Check, X, RefreshCw, Plus, UserPlus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { DataTable } from '@/components/DataTable';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { FilterBar } from '@/components/FilterBar';

interface Profile {
  id: string;
  email: string | null;
  role: string | null;
  status: string | null;
  created_at: string;
  approved_at?: string | null;
  approved_by?: string | null;
}

export const UserManagement: React.FC = () => {
  const { isSuperAdmin, userRole } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [pendingUsers, setPendingUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [showAddUserDialog, setShowAddUserDialog] = useState(false);
  const [newUser, setNewUser] = useState({
    email: '',
    role: 'user',
    password: ''
  });
  
  // Filter states
  const [filters, setFilters] = useState({
    search: '',
    role: '',
    status: '',
    dateFrom: '',
    dateTo: ''
  });

  const fetchUsers = async () => {
    try {
      setError(null);
      const { data: allUsers, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const approved = allUsers?.filter(u => u.status === 'approved') || [];
      const pending = allUsers?.filter(u => u.status === 'pending') || [];
      
      setUsers(approved);
      setPendingUsers(pending);
    } catch (error: any) {
      console.error('Error fetching users:', error);
      setError(error.message || 'Failed to fetch users');
      toast.error('Failed to fetch users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Filter logic
  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      const matchesSearch = !filters.search || 
        (user.email?.toLowerCase().includes(filters.search.toLowerCase()));
      
      const matchesRole = !filters.role || user.role === filters.role;
      
      const matchesStatus = !filters.status || user.status === filters.status;
      
      const userDate = new Date(user.created_at);
      const matchesDateFrom = !filters.dateFrom || 
        userDate >= new Date(filters.dateFrom);
      const matchesDateTo = !filters.dateTo || 
        userDate <= new Date(filters.dateTo + 'T23:59:59');
      
      return matchesSearch && matchesRole && matchesStatus && matchesDateFrom && matchesDateTo;
    });
  }, [users, filters]);

  const filteredPendingUsers = useMemo(() => {
    return pendingUsers.filter(user => {
      const matchesSearch = !filters.search || 
        (user.email?.toLowerCase().includes(filters.search.toLowerCase()));
      
      const matchesRole = !filters.role || user.role === filters.role;
      
      const userDate = new Date(user.created_at);
      const matchesDateFrom = !filters.dateFrom || 
        userDate >= new Date(filters.dateFrom);
      const matchesDateTo = !filters.dateTo || 
        userDate <= new Date(filters.dateTo + 'T23:59:59');
      
      return matchesSearch && matchesRole && matchesDateFrom && matchesDateTo;
    });
  }, [pendingUsers, filters]);

  const filterOptions = [
    {
      key: 'search',
      label: 'Search',
      type: 'search' as const,
      placeholder: 'Search by email...'
    },
    {
      key: 'role',
      label: 'Role',
      type: 'select' as const,
      options: [
        { value: 'super_admin', label: 'Super Admin' },
        { value: 'admin', label: 'Admin' },
        { value: 'user', label: 'User' }
      ]
    },
    {
      key: 'status',
      label: 'Status',
      type: 'select' as const,
      options: [
        { value: 'approved', label: 'Approved' },
        { value: 'pending', label: 'Pending' }
      ]
    },
    {
      key: 'dateFrom',
      label: 'From Date',
      type: 'date' as const
    },
    {
      key: 'dateTo',
      label: 'To Date',
      type: 'date' as const
    }
  ];

  const activeFiltersCount = Object.values(filters).filter(value => value !== '').length;

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      role: '',
      status: '',
      dateFrom: '',
      dateTo: ''
    });
  };

  const updateUserRole = async (userId: string, newRole: string) => {
    try {
      setActionLoading(userId);
      
      // Call edge function for secure role update
      const { data, error } = await supabase.functions.invoke('update-user-role', {
        body: {
          userId: userId,
          newRole: newRole
        }
      });

      if (error) {
        throw new Error(error.message || 'Failed to update role');
      }

      if (data?.error) {
        throw new Error(data.error);
      }
      
      toast.success('User role updated successfully');
      fetchUsers();
    } catch (error: any) {
      console.error('Error updating user role:', error);
      toast.error(`Failed to update user role: ${error.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const canEditUser = (targetUser: Profile) => {
    // Super admin can edit everyone except other super admins (to prevent role conflicts)
    if (isSuperAdmin) {
      return targetUser.role !== 'super_admin';
    }
    
    // Admin can only edit regular users (not other admins or super admins)
    if (userRole === 'admin') {
      return targetUser.role === 'user' || !targetUser.role;
    }
    
    return false;
  };

  const approveUser = async (userId: string) => {
    try {
      setActionLoading(userId);
      const { error } = await supabase
        .from('profiles')
        .update({ 
          status: 'approved',
          approved_at: new Date().toISOString()
        })
        .eq('id', userId);

      if (error) throw error;
      
      toast.success('User approved successfully');
      fetchUsers();
    } catch (error: any) {
      console.error('Error approving user:', error);
      toast.error('Failed to approve user');
    } finally {
      setActionLoading(null);
    }
  };

  const rejectUser = async (userId: string) => {
    try {
      setActionLoading(userId);
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', userId);

      if (error) throw error;
      
      toast.success('User rejected and removed');
      await logAdminAction('user_rejected', 'profiles', userId);
      fetchUsers();
    } catch (error: any) {
      console.error('Error rejecting user:', error);
      toast.error('Failed to reject user');
    } finally {
      setActionLoading(null);
    }
  };

  const addNewUser = async () => {
    if (!newUser.email.trim() || !newUser.password.trim()) {
      toast.error('Email and password are required');
      return;
    }

    try {
      setActionLoading('add-user');
      
      // Call edge function to create user with admin privileges
      const { data, error } = await supabase.functions.invoke('create-user', {
        body: {
          email: newUser.email,
          password: newUser.password,
          role: newUser.role
        }
      });

      if (error) {
        throw new Error(error.message || 'Failed to create user');
      }

      if (data?.error) {
        throw new Error(data.error);
      }

      toast.success('User created successfully');
      setShowAddUserDialog(false);
      setNewUser({ email: '', role: 'user', password: '' });
      fetchUsers();
    } catch (error: any) {
      console.error('Error creating user:', error);
      toast.error(`Failed to create user: ${error.message}`);
    } finally {
      setActionLoading(null);
    }
  };

  const removeUser = async (userId: string, userEmail: string) => {
    if (!confirm(`Are you sure you want to permanently remove ${userEmail}? This action cannot be undone.`)) {
      return;
    }

    try {
      setActionLoading(userId);
      
      // Call the delete-user edge function to properly delete from both auth and profiles
      const { error } = await supabase.functions.invoke('delete-user', {
        body: { userId }
      });

      if (error) throw error;
      
      toast.success('User removed successfully');
      await logAdminAction('user_removed', 'auth_users', userId);
      fetchUsers();
    } catch (error: any) {
      console.error('Error removing user:', error);
      toast.error('Failed to remove user');
    } finally {
      setActionLoading(null);
    }
  };

  const logAdminAction = async (action: string, table: string, recordId: string) => {
    try {
      await supabase
        .from('admin_audit_log')
        .insert({
          action_type: action,
          resource_type: table,
          resource_id: recordId,
          new_values: { timestamp: new Date().toISOString() }
        });
    } catch (error) {
      console.error('Error logging admin action:', error);
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'super_admin': return 'destructive';
      case 'admin': return 'default';
      case 'user': return 'secondary';
      default: return 'outline';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'default';
      case 'pending': return 'secondary';
      default: return 'outline';
    }
  };

  const userColumns = [
    {
      key: 'email',
      header: 'Email',
      render: (user: Profile) => (
        <span className="font-medium">{user.email || 'N/A'}</span>
      )
    },
    {
      key: 'role',
      header: 'Role',
      render: (user: Profile) => (
        <Badge variant={getRoleColor(user.role || 'user')}>
          {user.role || 'user'}
        </Badge>
      )
    },
    {
      key: 'status',
      header: 'Status',
      render: (user: Profile) => (
        <Badge variant={getStatusColor(user.status || 'pending')}>
          {user.status || 'pending'}
        </Badge>
      )
    },
    {
      key: 'created_at',
      header: 'Joined',
      render: (user: Profile) => (
        new Date(user.created_at).toLocaleDateString()
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (user: Profile) => {
        const canEdit = canEditUser(user);
        
        if (!canEdit) {
          return (
            <div className="flex items-center gap-2">
              <Badge variant={getRoleColor(user.role || 'user')}>
                {user.role === 'super_admin' ? 'Super Admin' : 
                 user.role === 'admin' ? 'Admin' : 'User'}
              </Badge>
              <span className="text-xs text-muted-foreground">No permission</span>
            </div>
          );
        }
        
        // Super admin role cannot be changed through UI (must be unique)
        if (user.role === 'super_admin') {
          return (
            <div className="flex items-center gap-2">
              <Badge variant={getRoleColor('super_admin')}>
                Super Admin
              </Badge>
              <span className="text-xs text-muted-foreground">Protected role</span>
            </div>
          );
        }
        
        return (
          <div className="flex items-center gap-2">
            <Select
              value={user.role || 'user'}
              onValueChange={(value) => updateUserRole(user.id, value)}
              disabled={actionLoading === user.id}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="user">User</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => removeUser(user.id, user.email || 'Unknown')}
              disabled={actionLoading === user.id}
              className="text-destructive hover:text-destructive"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
            {actionLoading === user.id && (
              <LoadingSpinner size={16} text="" />
            )}
          </div>
        );
      }
    }
  ];

  const pendingColumns = [
    {
      key: 'email',
      header: 'Email',
      render: (user: Profile) => (
        <span className="font-medium">{user.email || 'N/A'}</span>
      )
    },
    {
      key: 'role',
      header: 'Role',
      render: (user: Profile) => (
        <Badge variant={getRoleColor(user.role || 'user')}>
          {user.role || 'user'}
        </Badge>
      )
    },
    {
      key: 'created_at',
      header: 'Requested',
      render: (user: Profile) => (
        new Date(user.created_at).toLocaleDateString()
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (user: Profile) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="default"
            onClick={() => approveUser(user.id)}
            disabled={actionLoading === user.id}
          >
            <Check className="w-4 h-4 mr-1" />
            Approve
          </Button>
          <Button
            size="sm"
            variant="destructive"
            onClick={() => rejectUser(user.id)}
            disabled={actionLoading === user.id}
          >
            <X className="w-4 h-4 mr-1" />
            Reject
          </Button>
          {actionLoading === user.id && (
            <LoadingSpinner size={16} text="" />
          )}
        </div>
      )
    }
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">User Management</h1>
          <p className="text-muted-foreground">
            Manage user accounts, roles, and permissions
          </p>
        </div>
        <LoadingSpinner size={32} text="Loading users..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">User Management</h1>
          <p className="text-muted-foreground">
            Manage user accounts, roles, and permissions
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={showAddUserDialog} onOpenChange={setShowAddUserDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add User
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New User</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="user@example.com"
                    value={newUser.email}
                    onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter password"
                    value={newUser.password}
                    onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <Select
                    value={newUser.role}
                    onValueChange={(value) => setNewUser(prev => ({ ...prev, role: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">User</SelectItem>
                      {isSuperAdmin && (
                        <SelectItem value="admin">Admin</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex gap-2 pt-4">
                  <Button
                    onClick={addNewUser}
                    disabled={actionLoading === 'add-user'}
                    className="flex-1"
                  >
                    {actionLoading === 'add-user' ? (
                      <>
                        <LoadingSpinner size={16} text="" />
                        Creating...
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4 mr-2" />
                        Create User
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowAddUserDialog(false)}
                    disabled={actionLoading === 'add-user'}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Button 
            variant="outline" 
            onClick={fetchUsers}
            disabled={loading}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <FilterBar
        filters={filters}
        onFilterChange={handleFilterChange}
        onClearFilters={clearFilters}
        filterOptions={filterOptions}
        activeFiltersCount={activeFiltersCount}
      />

      <div className="grid grid-cols-1 gap-6">
        {/* All Users */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              All Users ({filteredUsers.length})
              {activeFiltersCount > 0 && (
                <Badge variant="outline" className="ml-2">
                  Filtered from {users.length}
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              View and manage all approved user accounts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DataTable
              data={filteredUsers}
              columns={userColumns}
              emptyStateIcon={Users}
              emptyStateTitle={filteredUsers.length === 0 && users.length > 0 ? "No users match filters" : "No users found"}
              emptyStateDescription={filteredUsers.length === 0 && users.length > 0 ? "Try adjusting your search criteria or clear filters" : "User accounts will appear here once they are approved"}
            />
          </CardContent>
        </Card>

        {/* Pending Approvals */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserCheck className="h-5 w-5" />
              Pending Approvals ({filteredPendingUsers.length})
              {activeFiltersCount > 0 && (
                <Badge variant="outline" className="ml-2">
                  Filtered from {pendingUsers.length}
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              Review and approve user registration requests
            </CardDescription>
          </CardHeader>
          <CardContent>
            <DataTable
              data={filteredPendingUsers}
              columns={pendingColumns}
              emptyStateIcon={UserCheck}
              emptyStateTitle={filteredPendingUsers.length === 0 && pendingUsers.length > 0 ? "No pending users match filters" : "No pending approvals"}
              emptyStateDescription={filteredPendingUsers.length === 0 && pendingUsers.length > 0 ? "Try adjusting your search criteria" : "Approval requests will appear here when users register"}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

