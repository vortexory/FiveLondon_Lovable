import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Users, 
  FileText, 
  UserCheck, 
  TrendingUp,
  Activity,
  Clock
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface DashboardStats {
  totalModels: number;
  pendingApplications: number;
  publishedBlogs: number;
  totalUsers: number;
  recentActivity: any[];
}

export const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalModels: 0,
    pendingApplications: 0,
    publishedBlogs: 0,
    totalUsers: 0,
    recentActivity: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // Add error handling for each query to prevent dashboard failures
      const [modelsRes, applicationsRes, blogsRes, usersRes] = await Promise.allSettled([
        supabase.from('models').select('id'),
        supabase.from('model_applications').select('id').eq('status', 'pending'),
        supabase.from('blog_posts').select('id').eq('is_published', true),
        supabase.from('profiles').select('id')
      ]);

      setStats({
        totalModels: modelsRes.status === 'fulfilled' ? (modelsRes.value.data?.length || 0) : 0,
        pendingApplications: applicationsRes.status === 'fulfilled' ? (applicationsRes.value.data?.length || 0) : 0,
        publishedBlogs: blogsRes.status === 'fulfilled' ? (blogsRes.value.data?.length || 0) : 0,
        totalUsers: usersRes.status === 'fulfilled' ? (usersRes.value.data?.length || 0) : 0,
        recentActivity: []
      });

      // Log any errors without failing the entire dashboard
      [modelsRes, applicationsRes, blogsRes, usersRes].forEach((result, index) => {
        if (result.status === 'rejected') {
          const tableNames = ['models', 'model_applications', 'blog_posts', 'profiles'];
          console.warn(`Error loading ${tableNames[index]} data:`, result.reason);
        }
      });

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      // Set default values to prevent UI errors
      setStats({
        totalModels: 0,
        pendingApplications: 0,
        publishedBlogs: 0,
        totalUsers: 0,
        recentActivity: []
      });
    } finally {
      setLoading(false);
    }
  };

  const StatCard = ({ title, value, icon: Icon, description, color = "default" }: any) => (
    <Card className="transition-all hover:shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className={`h-4 w-4 ${
          color === 'success' ? 'text-green-600' :
          color === 'warning' ? 'text-yellow-600' :
          color === 'danger' ? 'text-red-600' :
          'text-muted-foreground'
        }`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground">
            {description}
          </p>
        )}
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome to the Five London admin panel. Manage your content, SEO, and users.
          </p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Models"
          value={stats.totalModels}
          icon={Users}
          description="Active models"
          color="default"
        />
        <StatCard
          title="Pending Applications"
          value={stats.pendingApplications}
          icon={Clock}
          description="Awaiting review"
          color={stats.pendingApplications > 0 ? "warning" : "success"}
        />
        <StatCard
          title="Published Blogs"
          value={stats.publishedBlogs}
          icon={FileText}
          description="Live blog posts"
          color="default"
        />
        <StatCard
          title="Total Users"
          value={stats.totalUsers}
          icon={UserCheck}
          description="Registered users"
          color="default"
        />
      </div>

      {/* Recent Activity & System Status */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Recent Activity
            </CardTitle>
            <CardDescription>
              Latest changes and updates
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 border rounded-lg">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">System Online</p>
                  <p className="text-xs text-muted-foreground">All services running normally</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 border rounded-lg">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Database Connected</p>
                  <p className="text-xs text-muted-foreground">Supabase connection active</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 border rounded-lg">
                <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Pending Applications</p>
                  <p className="text-xs text-muted-foreground">{stats.pendingApplications} applications awaiting review</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              System Status
            </CardTitle>
            <CardDescription>
              Current system health and performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Uptime</span>
                <span className="text-sm text-green-600 font-medium">99.9%</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Response Time</span>
                <span className="text-sm text-blue-600 font-medium">&lt; 200ms</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Last Backup</span>
                <span className="text-sm text-muted-foreground">2 hours ago</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Storage Used</span>
                <span className="text-sm text-muted-foreground">2.1 GB / 10 GB</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

