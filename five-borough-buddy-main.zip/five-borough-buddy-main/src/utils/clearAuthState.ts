import { supabase } from '@/integrations/supabase/client';

export const clearAllAuthState = async () => {
  try {
    // Sign out from Supabase
    await supabase.auth.signOut();
    
    // Clear all possible localStorage keys
    const keysToRemove = [
      'supabase.auth.token',
      'sb-jiegopvbwpyfohhfvmwo-auth-token',
      'sb-auth-token',
      'supabase-auth-token'
    ];
    
    keysToRemove.forEach(key => {
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
    });
    
    // Clear all supabase related items from localStorage
    Object.keys(localStorage).forEach(key => {
      if (key.includes('supabase') || key.includes('sb-')) {
        localStorage.removeItem(key);
      }
    });
    
    // Clear sessionStorage as well
    Object.keys(sessionStorage).forEach(key => {
      if (key.includes('supabase') || key.includes('sb-')) {
        sessionStorage.removeItem(key);
      }
    });
    
    // Force page reload to ensure clean state
    window.location.reload();
    
  } catch (error) {
    console.error('Error clearing auth state:', error);
    // Force reload anyway
    window.location.reload();
  }
};