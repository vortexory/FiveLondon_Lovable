import { supabase } from '@/integrations/supabase/client';

export interface CharacteristicSEO {
  name: string;
  seo_path: string | null;
  category: string | null;
}

/**
 * Get SEO paths for model characteristics
 * This connects model profiles to SEO-optimized characteristic pages
 */
export const getCharacteristicSEOPaths = async (characteristics: string[]): Promise<CharacteristicSEO[]> => {
  try {
    const { data, error } = await supabase
      .from('characteristics')
      .select('name, seo_path, category')
      .in('name', characteristics)
      .eq('is_active', true);

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching characteristic SEO paths:', error);
    return [];
  }
};

/**
 * Generate schema.org structured data for a model with characteristics
 * This helps search engines understand the content and improves SEO
 */
export const generateModelStructuredData = (model: any, characteristicSEO: CharacteristicSEO[]) => {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Person",
    "name": model.name,
    "description": model.description,
    "image": model.image,
    "offers": {
      "@type": "Offer",
      "description": model.services?.join(', '),
      "availability": model.availability,
      "priceRange": model.price
    },
    "knowsAbout": characteristicSEO.map(char => ({
      "@type": "Thing",
      "name": char.name,
      "url": char.seo_path ? `${window.location.origin}${char.seo_path}` : undefined
    })).filter(item => item.url)
  };

  return structuredData;
};

/**
 * Generate canonical URLs for model profiles based on characteristics
 */
export const generateCanonicalURL = (modelId: string, characteristics: string[]): string => {
  const baseUrl = window.location.origin;
  const primaryCharacteristic = characteristics[0]?.toLowerCase().replace(/[^a-z0-9]/g, '-');
  
  if (primaryCharacteristic) {
    return `${baseUrl}/models/${modelId}/${primaryCharacteristic}`;
  }
  
  return `${baseUrl}/models/${modelId}`;
};

/**
 * Get related characteristic pages for cross-linking
 * This helps with internal SEO linking structure
 */
export const getRelatedCharacteristics = async (currentCharacteristics: string[], category?: string): Promise<CharacteristicSEO[]> => {
  try {
    let query = supabase
      .from('characteristics')
      .select('name, seo_path, category')
      .eq('is_active', true)
      .not('name', 'in', `(${currentCharacteristics.map(c => `"${c}"`).join(',')})`)
      .limit(5);

    if (category) {
      query = query.eq('category', category);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching related characteristics:', error);
    return [];
  }
};

/**
 * Create SEO-friendly breadcrumbs for model pages
 */
export const generateBreadcrumbs = (model: any, characteristicSEO: CharacteristicSEO[]) => {
  const breadcrumbs = [
    { name: 'Home', url: '/' },
    { name: 'Models', url: '/models' }
  ];

  // Add primary characteristic breadcrumb
  const primaryChar = characteristicSEO[0];
  if (primaryChar?.seo_path) {
    breadcrumbs.push({
      name: primaryChar.name,
      url: primaryChar.seo_path
    });
  }

  // Add model name
  breadcrumbs.push({
    name: model.name,
    url: `/models/${model.id}`
  });

  return breadcrumbs;
};

/**
 * Generate SEO URLs for characteristics and locations
 */
export const generateCharacteristicSEOUrl = (seoPath: string): string => {
  return `https://exclusivefivelondon.com${seoPath}`;
};

export const generateLocationSEOUrl = (seoPath: string): string => {
  return `https://exclusivefivelondon.com/locations/escorts-in-${seoPath}`;
};

/**
 * Get SEO paths for model locations
 */
export interface LocationSEO {
  name: string;
  seo_path: string | null;
  description: string | null;
}

export const getLocationSEOPaths = async (locations: string[]): Promise<LocationSEO[]> => {
  try {
    const { data, error } = await supabase
      .from('locations')
      .select('name, seo_path, description')
      .in('name', locations)
      .eq('is_active', true);

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching location SEO paths:', error);
    return [];
  }
};

/**
 * Generate meta tags for model pages with characteristic and location-based SEO
 */
export const generateModelMetaTags = (model: any, characteristicSEO: CharacteristicSEO[], locationSEO?: LocationSEO) => {
  const characteristics = characteristicSEO.map(c => c.name).join(', ');
  const location = locationSEO?.name || model.location || 'London';
  
  return {
    title: `${model.name} - ${characteristics} Escort in ${location}`,
    description: `Meet ${model.name}, a ${characteristics.toLowerCase()} companion in ${location}. ${model.description || 'Premium escort services available.'} Contact us for bookings.`,
    keywords: [
      model.name,
      ...characteristicSEO.map(c => c.name.toLowerCase()),
      `${location} escort`,
      'companion services',
      'premium escorts'
    ].join(', '),
    canonical: generateCanonicalURL(model.id, characteristicSEO.map(c => c.name))
  };
};